
:mod:`matplotlib.backends.backend_gtkagg`
=========================================

**TODO** We'll add this later, importing the gtk backends requires an active
X-session, which is not compatible with cron jobs.

.. .. automodule:: matplotlib.backends.backend_gtkagg
..    :members:
..    :undoc-members:
..    :show-inheritance:
