***************
matplotlib axis
***************


:mod:`matplotlib.axis`
======================

.. automodule:: matplotlib.axis
   :members:
   :undoc-members:
   :show-inheritance:
