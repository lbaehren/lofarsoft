/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data EventHeader class                          *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_EVENT_HEADER_H
#define AERA_DATA_EVENT_HEADER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "DatafileBase.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

/* Header words for the event header */
#define EVENT_HDR_LENGTH          0
#define EVENT_HDR_RUNNR           2
#define EVENT_HDR_EVENTNR         4
#define EVENT_HDR_T3EVENTNR       6
#define EVENT_HDR_FIRST_LS        8
#define EVENT_HDR_EVENT_SEC      10
#define EVENT_HDR_EVENT_NSEC     12
#define EVENT_HDR_EVENT_TYPE     14
#define EVENT_HDR_AD1            16 //start of additional info to be defined
#define EVENT_HDR_AD2            18 //                    info to be defined
#define EVENT_HDR_AD3            20 //                    info to be defined

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  EventHeader
    //
    // ================================================================== Class

    /*!
      \class EventHeader

      \brief Header of an AERA event.

      \author Martin van den Akker

      \date 2010/11/16

      \test tEventHeader.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class EventHeader : DatafileBase { // Class EventHeader -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      EventHeader ();

      /*!
        \brief Destructor
      */
      virtual ~EventHeader ();


    private:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

    private:

      //! Header length of the event.
      int _eventLength;

      //! Run ID of the event.
      int _runID;

      //! Event ID.
      int _eventID;

      //! t3 ID of the event.
      int _t3eventID;

      //! ID of the First Local Station.
      int _firstLSID;

      //! Seconds part of the timestamp of the event.
      unsigned int _seconds;

      //! Nanosecond part of the timestamp of the event.
      unsigned int _nanoseconds;

      //! Type of event.
      int _eventType;


    public:

      /*!
        \brief Get the length of the event.

        \return length -- Length of the event.
      */
      inline int getEventLength() const {return _eventLength;};

      /*!
        \brief Get the ID of the run.

        \return runID -- ID of the run.
      */
      inline int getRunID() const {return _runID;};

      /*!
        \brief Get the ID of the event.

        \return eventID -- ID of the event.
      */
      inline int getEventID() const {return _eventID;};

      /*!
        \brief Get the t3 event ID.

        \return t3EventID -- t3 event ID.
      */
      inline int getT3eventID() const {return _t3eventID;};

      /*!
        \brief Get the ID of the first local station.

        \return firstLSID -- ID of the first local station.
      */
      inline int getFirstLSID() const {return _firstLSID;};

      /*!
        \brief Get the seconds part of the timestamp of the event.

        \return seconds -- Seconds part of the timestamp of the event.
      */
      inline unsigned int getSeconds() const {return _seconds;};

      /*!
        \brief Get the nanosecond part of the timestamp of the event.

        \return nanoSeconds -- Nanoseconds part of the timestamp of the event.
      */
      inline unsigned int getNanoSeconds() const {return _nanoseconds;};

      /*!
        \brief Get the type of the event.

        \return eventType -- Type of the event.
      */
      inline int getEventType() const {return _eventType;};


      // ======================================================================
      //  Methods
      // ======================================================================

    public:

      /*!
        \brief Read the event header information from file.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      bool read (unsigned short* evt_ptr);

      /*!
        \brief Summary of the event header.
      */
      void summary () const;


    private:


    }; // Class EventHeader -- end


  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_EVENT_HEADER_H */

