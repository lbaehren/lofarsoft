#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include "reader_org.h"

#define INTSIZE   4 //size of an integer
#define SHORTSIZE 2 //size of a short

int *filehdr=NULL;
unsigned short *event=NULL;

int aera_read_file_header(FILE *fp)
{
  int i,return_code;
  int isize;

  if( !fread(&isize,INTSIZE,1,fp)) {
    printf("Cannot read the header length\n");
    return(0);                                                       //cannot read the header length
  }
  printf("The header length is %d bytes \n",isize);
  if(isize < FILE_HDR_ADDITIONAL){
    printf("The file header is too short, only %d integers\n",isize);
    return(0);                                                       //file header too short
  }
  if(filehdr != NULL) free((void *)filehdr);                         //in case we run several files
  filehdr = (int *)malloc(isize+INTSIZE);                            //allocate memory for the file header
  if(filehdr == NULL){
    printf("Cannot allocate enough memory to save the file header!\n");
    return(0);                                                       //cannot allocate memory for file header
  }
  filehdr[0] = isize;                                                //put the size into the header
  if((return_code = fread(&(filehdr[1]),1,isize,fp)) !=(isize)) {
    printf("Cannot read the full header (%d)\n",return_code);
    return(0);                                                       //cannot read the full header
  }
  return(1);
}

void print_file_header()
{
  int i,additional_int;
  struct tm *mytime;

  additional_int = 1+(filehdr[FILE_HDR_LENGTH]/INTSIZE) - FILE_HDR_ADDITIONAL; //number of additional words in the header
  if(additional_int<0){
    printf("The header is too short!\n");
    return;
  }
  printf("Header Length is %d bytes\n",filehdr[FILE_HDR_LENGTH]);
  printf("Header Run Number is %d\n",filehdr[FILE_HDR_RUNNR]);
  printf("Header Run Mode is %d\n",filehdr[FILE_HDR_RUN_MODE]);
  printf("Header File Serial Number is %d\n",filehdr[FILE_HDR_SERIAL]);
  printf("Header First Event is %d\n",filehdr[FILE_HDR_FIRST_EVENT]);
  mytime = gmtime((const time_t *)(&filehdr[FILE_HDR_FIRST_EVENT_SEC]));
  printf("Header First Event Time is %s",asctime(mytime));
  printf("Header Last Event is %d\n",filehdr[FILE_HDR_LAST_EVENT]);
  mytime = gmtime((const time_t *)(&filehdr[FILE_HDR_LAST_EVENT_SEC]));
  printf("Header Last Event Time is %s",asctime(mytime));
  for(i=0;i<additional_int;i++){
    printf("HEADER Additional Word %d = %d\n",i,filehdr[i+FILE_HDR_ADDITIONAL]);
  }
}

int aera_read_event(FILE *fp)
{
  int isize,return_code;

  if( !fread(&isize,INTSIZE,1,fp)) {
    printf("Cannot read the Event length\n");
    return(0);                                                       //cannot read the header length
  }
  printf("The event length is %d bytes \n",isize);
  if(event != NULL) {
    if(event[0] != isize) {
      free((void *)event);                                           //free and alloc only if needed
      event = (unsigned short *)malloc(isize+INTSIZE);                          //allocate memory for the event
    }
  }
  else{
      event = (unsigned short *)malloc(isize+INTSIZE);                          //allocate memory for the event
  }
  if(event == NULL){
    printf("Cannot allocate enough memory to save the event!\n");
    return(0);                                                       //cannot allocate memory for event
  }
  event[0] = isize&0xffff;                                                  //put the size into the event
  event[1] = isize>>16;
  if((return_code = fread(&(event[2]),1,isize,fp)) !=(isize)) {
    printf("Cannot read the full event (%d)\n",return_code);
    return(0);                                                       //cannot read the full event
  }
  return(1);
}

void scope_evt_data(unsigned char *evt,int len, unsigned short *dat, int *retlen)
{
  int i,j,imax;

  j=MSG_DATA_ADC-MSG_OFFSET;                                      // start at the beginning of the ADC data
  imax = 2*(len-(MSG_DATA_ADC+1))/3;                   // calculate total number of ADC words (2 in 3 bytes!)
  *retlen = imax;                                      // the length to return = number of ADC words
  for (i=0;i<imax;i++) {                               // loop over all values
    if ((i&1)) {
      dat[i] = ((unsigned short)evt[j+1]<<4) | (evt[j]>>4);
      j+=2;
    }
    else {
      dat[i] = (((unsigned short)evt[j+1]&0xf)<<8) | evt[j];
      j++;
    }
  }
}

void print_aera_ls(EVENTBODY *ls)
{
  int htype;
  unsigned char *raw;
  unsigned short s;
  unsigned int i, j;
  unsigned short scope_val[10000];
  int scope_len;

  printf("LS length          = %d\n",ls->length);
  printf("LS event number    = %d\n",ls->event_nr);
  printf("LS id              = %d\n",ls->LS_id&0xff);
  htype = ((ls->LS_id>>8)&5);
  printf("Hardware           = %s  Version %d\n",hardware[htype-1],(ls->LS_id>>11)&0x1f);
  printf("LS header length   = %d\n",ls->header_length);
  printf("LS seconds         = %d\n",ls->GPSseconds);
  printf("LS nanosecond      = %d\n",ls->GPSnanoseconds);
  printf("LS triggerflag     = 0x%04x\n",ls->trigger_flag);
  printf("LS triggerposition = %d\n",ls->trigger_pos);
  printf("LS Sampling freq   = %d\n",ls->sampling_freq);
  printf("LS channel mask    = 0x%04x\n",ls->channel_mask);
  printf("LS ADC resolution  = %d\n",ls->ADC_resolution);
  printf("LS Tracelength     = %d\n",ls->tracelength);
  raw = (unsigned char *)ls->info_ADCbuffer;
  if(htype == LS_NL){ // I copied over the raw data, excluding the first word!
    printf("\t Message_id = 0x%x\n",raw[MSG_ID-MSG_OFFSET]);
    s= (raw[MSG_LEN - MSG_OFFSET]<<8)+(raw[MSG_LEN - MSG_OFFSET+1]&0xff);
    printf("\t Data Length = %d\n",s);
    printf("\t Channel Mask = 0x%x\n",raw[MSG_DATA_CH - MSG_OFFSET]);
    printf("\t Trigger Mask = 0x%x\n",raw[MSG_DATA_TRIG - MSG_OFFSET]);
    s= (raw[MSG_DATA_PRE - MSG_OFFSET]<<8)+(raw[MSG_DATA_PRE - MSG_OFFSET+1]&0xff);
    printf("\t Pre-trigger window = %d\n",s);
    s= (raw[MSG_DATA_COINC - MSG_OFFSET]<<8)+(raw[MSG_DATA_COINC - MSG_OFFSET+1]&0xff);
    printf("\t Coincidence window = %d\n",s);
    s= (raw[MSG_DATA_POST - MSG_OFFSET]<<8)+(raw[MSG_DATA_POST - MSG_OFFSET+1]&0xff);
    printf("\t Post-trigger window = %d\n",s);
    //don't worry about the GPS time
    i = (raw[MSG_DATA_CTD - MSG_OFFSET]<<24) + (raw[MSG_DATA_CTD - MSG_OFFSET + 1]<<16) +
      (raw[MSG_DATA_CTD - MSG_OFFSET+2]<<16) + raw[MSG_DATA_CTD - MSG_OFFSET + 3];
    printf("\t CTD = %d\n",i);
    for(i=0;i<4;i++){
        s= (raw[MSG_DATA_STHRES1 - MSG_OFFSET+2*i]<<8) +
            (raw[MSG_DATA_STHRES1 - MSG_OFFSET+2*i+1]&0xff);
        printf("\t Signal Threshold Channel %d = %d\n",i,s);
    }
    for(i=0;i<4;i++){
        s= (raw[MSG_DATA_NTHRES1 - MSG_OFFSET+2*i]<<8)+
            (raw[MSG_DATA_NTHRES1 - MSG_OFFSET+2*i+1]&0xff);
        printf("\t Noise Threshold Channel %d = %d\n",i,s);
    }
    s= (raw[MSG_LEN - MSG_OFFSET+1]<<8)+(raw[MSG_LEN - MSG_OFFSET]&0xff);
    scope_evt_data(raw,s,scope_val,&scope_len);    // calculate ADC values and put them in a buffer
    printf("Number of ADC Values = %d\n",scope_len);
    printf(" \t");
    int ch_len=scope_len/4;
    for(i=0; i < ch_len; ++i){
      for (j=0; j < 4; ++j) {
        printf("%4d   ",scope_val[j*ch_len+i]);
      }
      printf("\n \t");
    }
    printf("\n");
  }
}

void print_aera_event(){
  EVENTBODY *evls;
  int ils = EVENT_LS;                                                      //parameter indicating start of LS
  int ev_end = ((int)(event[EVENT_HDR_LENGTH+1]<<16)+(int)(event[EVENT_HDR_LENGTH]))/SHORTSIZE;

  printf("event Header Length = %d\n",(event[EVENT_HDR_LENGTH+1]<<16)+event[EVENT_HDR_LENGTH]);
  printf("event Run id        = %d\n",(event[EVENT_HDR_RUNNR+1]<<16)+event[EVENT_HDR_RUNNR]);
  printf("event Event id      = %d\n",(event[EVENT_HDR_EVENTNR+1]<<16)+event[EVENT_HDR_EVENTNR]);
  printf("event t3 Event id   = %d\n",(event[EVENT_HDR_T3EVENTNR+1]<<16)+event[EVENT_HDR_T3EVENTNR]);
  printf("event first LS id   = %d\n",(event[EVENT_HDR_FIRST_LS+1]<<16)+event[EVENT_HDR_FIRST_LS]);
  printf("event seconds       = %d\n",(event[EVENT_HDR_EVENT_SEC+1]<<16)+event[EVENT_HDR_EVENT_SEC]);
  printf("event nanoseconds   = %d\n",(event[EVENT_HDR_EVENT_NSEC+1]<<16)+event[EVENT_HDR_EVENT_NSEC]);
  printf("event Event type    = %d\n",(event[EVENT_HDR_EVENT_TYPE+1]<<16)+event[EVENT_HDR_EVENT_TYPE]);
  while(ils<ev_end){
    evls = (EVENTBODY *)(&event[ils]);
    printf("Local Station at position %d\n",ils);
    print_aera_ls(evls);
    ils +=(evls->length);
    printf("Next station starts at %d (%d)(but event ends at %d)\n",ils,evls->length,ev_end);
  }
}


main(int argc, char **argv)
{
  FILE *fp;
  int i;

  fp = fopen(argv[1],"r");
  if(fp == NULL) printf("Error opening  !!%s!!\n",argv[1]);

  if(aera_read_file_header(fp) ){ //lets read events
    print_file_header();
    /* for(i=filehdr[FILE_HDR_FIRST_EVENT];i<=filehdr[FILE_HDR_LAST_EVENT];i++){ */
      aera_read_event(fp);
      print_aera_event();
    /* } */
  }
  if (fp != NULL) fclose(fp); // close the file
}

