/*****************************************************************************
 *                                                                           *
 *  Implementation of the Event class for AERA data                          *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "Event.h"
#include "EventHeader.h"
#include "LocalStation.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Event
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                    Event

    Event::Event ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Event::init ()
    {
      _eventheader = new Data::EventHeader();
    }

    // ________________________________________________________________________
    //                                                                   ~Event

    Event::~Event ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Event::destroy ()
    {
      vector<Data::LocalStation*>::iterator localstation_it = _localstations.begin();

      delete (_eventheader);

      if ( _localstations.size() > 0 ) {
        while ( localstation_it != _localstations.end() ) {
          delete (*localstation_it);
          ++localstation_it;
        }
      }
    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    // ========================================================================
    //  Methods
    // ========================================================================

    bool Event::read (FILE* file_ptr)
    {
      bool status = false;
      unsigned short* evt_ptr = NULL;
      int eventLength = 0;
      int return_length = 0;

      int ls_idx = 0;
      int evt_end = 0;
      LocalStation* localstationdata = NULL;

      // GetEventLength
      if ( false == fread(&eventLength, INTSIZE, 1, file_ptr) ) {
        cerr << "Cannot readout event length" << endl;
        status = false;
        return status;
      }
      // Allocate memory for the event
      if ( NULL != evt_ptr ) {
        if ( evt_ptr[0] != eventLength ) {
          delete [] evt_ptr;
          evt_ptr = new unsigned short [eventLength + INTSIZE];
        }
      } else {
        evt_ptr = new unsigned short [eventLength + INTSIZE];
      }
      if ( NULL == evt_ptr ) {
        cerr << "Cannot allocate enough memory to save the event!" << endl;
        status = false;
        return status;
      }

      // Put the size into the event
      evt_ptr[0] = eventLength & 0xffff;
      evt_ptr[1] = eventLength >> 16;

      return_length = fread (&(evt_ptr[2]), 1, eventLength, file_ptr);
      if (return_length != eventLength) {
        cerr << "Cannot read the full event: " << return_length << endl;
        status = false;
        return status;
      }

      // Read the event header
      status = _eventheader->read (evt_ptr);
      if (false == status) {
        cerr << "Error: Unable to read event header" << endl;
        return status;
      }

      // Read local station data
      ls_idx = EVENT_LS;
      evt_end = eventLength/SHORTSIZE;
      // Loop over local station information.
      while (ls_idx < evt_end) {
        localstationdata = new LocalStation();
        status = localstationdata->read(&(evt_ptr[ls_idx]));
        if (true == status) {
          _localstations.push_back (localstationdata);
        } else {
          return status;
        }
        ls_idx += localstationdata->getLength();
      }

      _currentLocalStation_it = _localstations.begin();

      delete [] evt_ptr;

      status = true;

      return status;
    }


    void Event::summary () const
    {
      vector<LocalStation*>::const_iterator localstation_it = _localstations.begin();

      cout << "------------------------------------------------------------" << endl
           << "  Summary of event information" << endl
           << "------------------------------------------------------------" << endl
           << "  Number of local stations : " << nLocalStations() << endl;

      // Event header
      _eventheader->summary();

      // Local stations
      // if ( nLocalStations() > 0 ) {
      //   while ( localstation_it != _localstations.end() ) {
      //     (*localstation_it)->summary();
      //     ++localstation_it;
      //   }
      // }
    }


    LocalStation* Event::currentLocalStation () const
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        localStation_ptr = *_currentLocalStation_it;
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


    bool Event::isFirstLocalStation () const
    {
      bool status = false;

      if ( _localstations.begin() == _currentLocalStation_it ) {
        status = true;
      }

      return status;
    }


    LocalStation* Event::firstLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        _currentLocalStation_it = _localstations.begin();
        localStation_ptr = _localstations.front();
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


    LocalStation* Event::prevLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        if ( _currentLocalStation_it != _localstations.begin() ) {
          --_currentLocalStation_it;
        }
        localStation_ptr = *_currentLocalStation_it;
      } else {
        cerr << "No local stations available!" << endl;
      }
      return localStation_ptr;
    }


    LocalStation* Event::nextLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        if ( _currentLocalStation_it != (_localstations.end() - 1) ) {
          ++_currentLocalStation_it;
          localStation_ptr = *_currentLocalStation_it;
        }
      } else {
        cerr << "No local stations available!" << endl;
      }
      return localStation_ptr;
    }


    bool Event::isLastLocalStation () const
    {
      bool status = false;

      if ( _localstations.end() == _currentLocalStation_it ) {
        status = true;
      }

      return status;
    }


    LocalStation* Event::lastLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        _currentLocalStation_it = _localstations.end() - 1;
        localStation_ptr = _localstations.back();
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


  } // Namespace Data -- end

} // Namespace AERA -- end


