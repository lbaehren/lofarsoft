/*****************************************************************************
 *                                                                           *
 *  AERA Data Reader                                                         *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Include files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <iostream>
#include <string>
#include <vector>
#include <stdio.h>


// ________________________________________________________________________
//                                                    Project include files

#include "Datareader.h"
#include "Data/DatafileBase.h"
#include "Data/Header.h"
#include "Data/Event.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  // ========================================================================
  //
  //  Datareader
  //
  // ================================================================== Class


  // ========================================================================
  //  Contruction / Destruction
  // ========================================================================

  // ________________________________________________________________________
  //                                                               Datareader

  Datareader::Datareader ()
  {
    init();
  }


  Datareader::Datareader (const std::string filename)
  {
    init();

    _filename = filename;
  }

  // ________________________________________________________________________
  //                                                                     init

  void Datareader::init ()
  {
    _file_ptr = NULL;
    _filename = "";
    _header_ptr = NULL;
  }

  // ________________________________________________________________________
  //                                                              ~Datareader

  Datareader::~Datareader ()
  {
    destroy ();
  }

  // ________________________________________________________________________
  //                                                                  destroy

  void Datareader::destroy ()
  {
    vector<Data::Event*>::iterator event_it = _events.begin();

    close();

    // delete header
    delete (_header_ptr);

    // delete every event
    if ( _events.size() > 0 ) {
      while (event_it != _events.end()) {
        delete (*event_it);
        ++event_it;
      }
    }
  }


  // ========================================================================
  //  Attributes
  // ========================================================================


  // ========================================================================
  //  Methods
  // ========================================================================

  bool Datareader::open(const std::string filename)
  {
    bool status = false;

    // Check if a data file is already open.
    if (NULL != _file_ptr) {
      cout << "Warning: Closing file \"" << _filename << "\" "
           << "before opening \"" << filename << "\"."
           << endl;
      close();
    }

    FILE* a=0;
    // open the data file
    _file_ptr = fopen(filename.c_str(),"r");

    if (0 != _file_ptr) {
      _filename = filename;
      status = true;
    } else {
      cerr << "Error opening file " << filename << endl;
      status = false;
      return status;
    }

    return status;
  }


  bool Datareader::close()
  {
    bool status = false;

    if (NULL != _file_ptr) {
      // Close open file
      fclose(_file_ptr);
      status = true;
    } else {
      // No open file
      status = false;
    }

    _file_ptr = NULL;
    //_filename = "";

    return status;
  }


  bool Datareader::read()
  {
    bool status = false;
    int nEvents = 0;
    int firstEvent = 0;
    int lastEvent = 0;
    vector<Data::Event*>::iterator event_it = _events.begin();

    //cout << "[Datareader] Read()" << endl;
    if ( NULL != _file_ptr ) {
      // Read data header
      _header_ptr = new Data::Header();
      status = _header_ptr->read(_file_ptr);

      // Read events
      firstEvent = _header_ptr->getFirstEvent();
      lastEvent = _header_ptr->getLastEvent();
      nEvents = lastEvent - firstEvent + 1;
      _events.resize(nEvents);
      event_it = _events.begin();

      while (event_it != _events.end()) {
        *event_it = new Data::Event();
        if (NULL == *event_it) {
          status = false;
          cerr << "Unable to allocate memory for event !" << endl;
          return status;
        }

        status = (*event_it)->read(_file_ptr);
        if (false == status) {
          cerr << "Error when reading event " << endl;
          return status;
        }
        ++event_it;
      }

      _currentEvent_it = _events.begin();

    } else {
      cerr << "Error: Cannot read data from NULL pointer!" << endl;
      status = false;
      return status;
    }

    return status;
  }


  void Datareader::summary() const
  {
    vector<Data::Event*>::const_iterator event_it = _events.begin();

    cout << "------------------------------------------------------------" << endl
         << "  Summary of the data reader" << endl
         << "------------------------------------------------------------" << endl
         << "  File name        : " << _filename << endl
         << "  Number of events : " << nEvents() << endl;
    cout << "  File status      : ";
    if ( NULL == _file_ptr ) {
      cout << "Closed" << endl;
    } else {
      cout << "Open" << endl;
    }

    // Header summary
    if ( _header_ptr != NULL ) {
      _header_ptr->summary();
    }

  }


  Data::Event* Datareader::currentEvent () const
  {
    Data::Event* event_ptr = NULL;

    if ( _events.size() > 0 ) {
      event_ptr = *_currentEvent_it;
    } else {
      cerr << "No events available!" << endl;
    }

    return event_ptr;
  }


  bool Datareader::isFirstEvent () const
  {
    bool status = false;

    if ( _events.begin() == _currentEvent_it ) {
      status = true;
    }

    return status;
  }


  Data::Event* Datareader::firstEvent ()
  {
    Data::Event* event_ptr = NULL;

    if ( _events.size() > 0 ) {
      _currentEvent_it = _events.begin();
      event_ptr = _events.front();
    } else {
      cerr << "No events available!" << endl;
    }

    return event_ptr;
  }


  Data::Event* Datareader::prevEvent ()
  {
    Data::Event* event_ptr = NULL;

    if ( _events.size() > 0 ) {
      if ( _currentEvent_it != _events.begin() ) {
        --_currentEvent_it;
      }
      event_ptr = *_currentEvent_it;
    } else {
      cerr << "No events available!" << endl;
    }

    return event_ptr;
  }


  Data::Event* Datareader::nextEvent ()
  {
    Data::Event* event_ptr = NULL;

    if ( _events.size() > 0 ) {
      if ( _currentEvent_it < (_events.end() - 1) ) {
        ++_currentEvent_it;
        event_ptr = *_currentEvent_it;
      }
    } else {
      cerr << "No events available!" << endl;
    }

    return event_ptr;
  }


  bool Datareader::isLastEvent () const
  {
    bool status = false;

    if ( _events.end() == _currentEvent_it ) {
      status = true;
    }

    return status;
  }


  Data::Event* Datareader::lastEvent ()
  {
    Data::Event* event_ptr = NULL;

    if ( _events.size() > 0 ) {
      _currentEvent_it = _events.end() - 1;
      event_ptr = _events.back();
    } else {
      cerr << "No events available!" << endl;
    }

    return event_ptr;
  }


} // Namespace AERA -- end

