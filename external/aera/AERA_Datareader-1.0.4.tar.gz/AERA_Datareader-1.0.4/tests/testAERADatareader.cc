/*****************************************************************************
 *                                                                           *
 *  Test program for AERA Data Reader                                        *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                          System includes

#include <iostream>
#include <string>
#include <stdio.h>

// ________________________________________________________________________
//                                                         Project includes


// ________________________________________________________________________
//                                                           Local includes

#include "../src/Datareader.h"


// ========================================================================
//
//  Main
//
// ========================================================================

using namespace std;
using namespace AERA;

/*!
  \brief Main routine

  \return nofFailedTests  --  The number of failed tests.
 */
int main(int argc, char **argv)
{
  bool status = false;
  string filename;
  unsigned int nofFailedTests = 0;


  cout << "testAeraDataReader" << endl;

  Datareader dr;

  if (argc<2) {
    filename = "../../data/ad001037.f0001";
  } else {
    filename = argv[1];
  }

  // ___________________________________________________________________
  //                                                     Opening of file
  status = dr.open(filename);

  cout << "Opening of file: ";
  if (false == status) {
    cout << "Failed to open file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  // ___________________________________________________________________
  //                                                   Reopening of file
  status = dr.open(filename);

  cout << "Reopening of file: ";
  if (false == status) {
    cout << "Failed to reopen file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  // ___________________________________________________________________
  //                                  Getting a summary of the data file
  cout << "Get a summary of the data file" << endl;
  try {
    cout << "- Read the data first" << endl;
    status = dr.read();
    cout << "- Generating the summary" << endl;
    dr.summary();
  } catch (bool status) {
    ++nofFailedTests;
  }


  // ___________________________________________________________________
  //                                                     Closing of file
  status = dr.close();

  cout << "Closing of file: ";
  if (false == status) {
    cout << "Failed to close file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  cout << "Number of failed tests: " << nofFailedTests << endl;
  return nofFailedTests;
}
