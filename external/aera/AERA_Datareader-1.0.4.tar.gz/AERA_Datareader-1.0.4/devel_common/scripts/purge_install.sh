rm -rf $LOFARSOFT/release/lib/libAERADatareader.so*
rm -rf $LOFARSOFT/release/include/AERA
rm -rf $LOFARSOFT/release/bin/testAERADatareader
rm -rf $LOFARSOFT/build/external/aera