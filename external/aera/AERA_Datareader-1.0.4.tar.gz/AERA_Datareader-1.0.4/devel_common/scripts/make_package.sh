script_path=`pwd`
aera_version=1.0.4

# Go to package root directory
cd ../..

# Create the package
bzr export AERA_Datareader-$aera_version.tar.gz

# Copy package to LOFAR directory
cp AERA_Datareader-$aera_version.tar.gz $LOFARSOFT/external/aera/

# Return to script path
cd $script_path
