/*****************************************************************************
 *                                                                           *
 *  Implementation of the Local Station class for AERA data                  *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <iostream>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "LocalStation.h"

// ________________________________________________________________________
//                                                      Other include files


// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  LocalStation
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                LocalStation

    LocalStation::LocalStation ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void LocalStation::init ()
    {
      _length       = 0;
      _eventNumber  = 0;
      _LS_ID        = 0;
      _hardware     = "";
      _headerLength = 0;
      _seconds      = 0;
      _nanoseconds  = 0;
      _triggerFlag  = 0;
      _triggerPos   = 0;
      _samplingFreq = 0;
      _channelMask  = 0;
      _ADCResolution= 0;
      _traceLength  = 0;

      _messageID = 0;
      _preTriggerWindow = 0;
      _coincedenceWindow = 0;
      _postTriggerWindow = 0;

      _signalThresholds.resize(N_CHANNELS,0);
      _noiseThresholds.resize(N_CHANNELS,0);
    }

    // ________________________________________________________________________
    //                                                               ~LocalStation

    LocalStation::~LocalStation ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void LocalStation::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================

    unsigned short LocalStation::getSignalThreshold (const unsigned short channelNr) const
    {
      unsigned short signalThreshold = -1;

      if ( channelNr < N_CHANNELS ) {
        signalThreshold = _signalThresholds[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return signalThreshold;
    }

    unsigned short LocalStation::getNoiseThreshold (const unsigned short channelNr) const
    {
      unsigned short noiseThreshold = -1;

      if ( channelNr < N_CHANNELS ) {
        noiseThreshold = _noiseThresholds[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return noiseThreshold;
    }


    // ========================================================================
    //  Methods
    // ========================================================================

    bool LocalStation::read (unsigned short* evt_ptr)
    {
      bool status = false;
      LS_DATA* evt_container = (LS_DATA*)(evt_ptr);
      int htype;

      unsigned short rawSize = 0;
      unsigned char* rawADC_ptr = NULL;
      unsigned short* dataValue = NULL;
      int dataSize;
      int idx = 0;


      _length = evt_container->length;
      _eventNumber = evt_container->event_nr;
      _LS_ID = evt_container->LS_ID & 0xff;

      htype = ((evt_container->LS_ID>>8)&5);
      _hardware = hardware[htype-1] + " Version ...";// + string((evt_container->LS_ID>>11) & 0x1f);
      _headerLength = evt_container->header_length;
      _seconds      = evt_container->GPSseconds;
      _nanoseconds  = evt_container->GPSnanoseconds;
      _triggerFlag  = evt_container->trigger_flag;
      _triggerPos   = evt_container->trigger_pos;
      _samplingFreq = evt_container->sampling_freq;
      _channelMask  = evt_container->channel_mask;
      _ADCResolution= evt_container->ADC_resolution;
      _traceLength  = evt_container->tracelength;

      // Raw ADC data
      rawADC_ptr = (unsigned char*) evt_container->info_ADCbuffer;
      if ( htype == LS_NL ) {
        _messageID = rawADC_ptr[MSG_ID - MSG_OFFSET];
        // s= (raw[MSG_LEN - MSG_OFFSET]<<8)+(raw[MSG_LEN - MSG_OFFSET+1]&0xff);
        // printf("\t Data Length = %d\n",s);
        // printf("\t Channel Mask = 0x%x\n",raw[MSG_DATA_CH - MSG_OFFSET]);
        // printf("\t Trigger Mask = 0x%x\n",raw[MSG_DATA_TRIG - MSG_OFFSET]);

        _preTriggerWindow  = (rawADC_ptr[MSG_DATA_PRE - MSG_OFFSET]<<8)   + (rawADC_ptr[MSG_DATA_PRE - MSG_OFFSET+1]&0xff);
        _coincedenceWindow = (rawADC_ptr[MSG_DATA_COINC - MSG_OFFSET]<<8) + (rawADC_ptr[MSG_DATA_COINC - MSG_OFFSET+1]&0xff);
        _postTriggerWindow = (rawADC_ptr[MSG_DATA_POST - MSG_OFFSET]<<8)  + (rawADC_ptr[MSG_DATA_POST - MSG_OFFSET+1]&0xff);

        // //don't worry about the GPS time
        // i = (raw[MSG_DATA_CTD - MSG_OFFSET]<<24) + (raw[MSG_DATA_CTD - MSG_OFFSET + 1]<<16) +
        //   (raw[MSG_DATA_CTD - MSG_OFFSET+2]<<16) + raw[MSG_DATA_CTD - MSG_OFFSET + 3];
        // printf("\t CTD = %d\n",i);

        // Signal threshold
        for (idx=0; idx<N_CHANNELS; ++idx) {
          _signalThresholds[idx] = ((rawADC_ptr[MSG_DATA_STHRES1 - MSG_OFFSET+2*idx]<<8) +
                                   (rawADC_ptr[MSG_DATA_STHRES1 - MSG_OFFSET+2*idx+1]&0xff));
        }

        // Noise threshold
        for(idx=0; idx<N_CHANNELS; ++idx) {
          _noiseThresholds[idx] = ((rawADC_ptr[MSG_DATA_NTHRES1 - MSG_OFFSET+2*idx]<<8) +
                                  (rawADC_ptr[MSG_DATA_NTHRES1 - MSG_OFFSET+2*idx+1]&0xff));
        }

        // ADC data
        int mmm = (N_CHANNELS) * _traceLength;
        if (NULL != dataValue) {
          delete [] dataValue;
        }
        dataValue = new unsigned short[mmm];
        if ( NULL == dataValue ) {
          cerr << "Cannot allocate memory to read out ADC values!" << endl;
          status = false;
          return status;
        }
        rawSize = (rawADC_ptr[MSG_LEN - MSG_OFFSET+1]<<8)+(rawADC_ptr[MSG_LEN - MSG_OFFSET]&0xff);
        getADCDataBlock(rawADC_ptr, rawSize, dataValue, &dataSize);

        _adc_data.resize(N_CHANNELS, vector<int>(_traceLength));

        if (dataSize <= N_CHANNELS * _traceLength) {
          for (int i_chan = 0; i_chan < N_CHANNELS; ++i_chan) {
            for (idx = 0; idx < _traceLength; ++idx) {
              _adc_data[i_chan][idx] = dataValue[i_chan * _traceLength + idx];
            }
          }
        }
      }

      delete [] dataValue;

      status = true;

      return status;
    }

    std::vector<int> LocalStation::getADCData(const unsigned short channelNr) const
    {
      vector<int> channelData;

      if (channelNr < N_CHANNELS) {
        channelData = _adc_data[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return channelData;
    }

    void LocalStation::getADCDataBlock(const unsigned char* adcData,
                                    const int adcSize,
                                    unsigned short* dataValue,
                                    int* dataSize)
    {
      int i,j,imax;

      j = MSG_DATA_ADC - MSG_OFFSET;                  // start at the beginning of the ADC data
      imax = 2 * (adcSize - (MSG_DATA_ADC + 1)) / 3;  // calculate total number of ADC words (2 in 3 bytes!)
      *dataSize = imax;                               // the length to return = number of ADC words
      for (i=0; i < imax; ++i) {                      // loop over all values
        if ( (i&1) ) {
          dataValue[i] = ((unsigned short)adcData[j+1]<<4) | (adcData[j]>>4);
          j += 2;
        }
        else {
          dataValue[i] = (((unsigned short)adcData[j+1]&0xf)<<8) | adcData[j];
          ++j;
        }
      }
    }

    void LocalStation::summary () const
    {
      cout << "------------------------------------------------------------" << endl;
      cout << "  Summary of local station event information" << endl;
      cout << "------------------------------------------------------------" << endl;
      cout << "  Length             : " << getLength() << endl;
      cout << "  Event number       : " << getEventNumber() << endl;
      cout << "  ID                 : " << getLocalStationID() << endl;
      cout << "  Hardware           : " << getHardware() << endl;
      cout << "  Seconds            : " << getSeconds() << endl;
      cout << "  Nano seconds       : " << getNanoSeconds() << endl;
      cout << "  Trigger flag       : " << getTriggerFlag() << endl;
      cout << "  Trigger position   : " << getTriggerPosition() << endl;
      cout << "  Sampling frequency : " << getSamplingFrequency() << endl;
      cout << "  Channel mask       : " << getChannelMask() << endl;
      cout << "  ADC resolution     : " << getADCResolution() << endl;
      cout << "  Trace length       : " << getTraceLength() << endl;
      cout << "------------------------------------------------------------" << endl;

      // ADC data

      cout << "  ADC data" << endl;
      cout << "    Message ID               : " << getMessageID() << endl;
      cout << "    Pre-trigger window       : " << getPreTriggerWindow() << endl;
      cout << "    Coincedence window       : " << getCoincedenceWindow() << endl;
      cout << "    Post trigger window      : " << getPostTriggerWindow() << endl;
      for (int idx = 0; idx < N_CHANNELS; ++idx) {
        cout << "    Signal threshold (ch "<< idx <<")  : " << getSignalThreshold(idx) << endl;
      }
      for (int idx = 0; idx < N_CHANNELS; ++idx) {
        cout << "    Noise threshold (ch "<< idx <<")   : " << getNoiseThreshold(idx) << endl;
      }
    }


  } // Namespace Data -- end

} // Namespace AERA -- end


