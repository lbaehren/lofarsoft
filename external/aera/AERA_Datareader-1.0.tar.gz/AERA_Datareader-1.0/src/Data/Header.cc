/*****************************************************************************
 *                                                                           *
 *  Implementation of the Header class for AERA data                         *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <time.h>

// ________________________________________________________________________
//                                                    Project include files

#include "Header.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Header
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                   Header

    Header::Header ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Header::init ()
    {
      _runNumber = 0;
      _runMode = 0;
      _fileSerialNumber = 0;
      _firstEvent = 0;
      _firstEventTime = "Not defined";
      _lastEvent = 0;
      _lastEventTime = "Not defined";
    }

    // ________________________________________________________________________
    //                                                                  ~Header

    Header::~Header ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Header::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================

    int Header::getAdditionalWord (const int idx) const
    {
      int additionalWord = 0;

      if ((idx >= 0) && (idx < _additionalWords.size())) {
        additionalWord = _additionalWords[idx];
      } else {
        cerr << "Incorrect index value" << endl;
      }

      return additionalWord;
    }

    // ========================================================================
    //  Methods
    // ========================================================================

    bool Header::read(FILE* file_ptr)
    {
      bool status = false;
      int* hdr_ptr = NULL;
      int return_code = 0;
      struct tm* tmp_time;

      // ___________________________________________________________________
      //                                    Read data header block from file

      // Read header length
      if ( !fread(&_headerLength, INTSIZE, 1, file_ptr) ) {
        cerr << "Cannot read the header length" << endl;
        status = false;
        return status;
      }

      // Check header length
      if ( _headerLength < FILE_HDR_ADDITIONAL ) {
        cerr << "The file header is too short, only " << _headerLength << " integers" << endl;
        status = false;
        return status;
      }

      // Allocate memory for the file header
      if ( hdr_ptr != NULL ) {
        delete [] hdr_ptr;
      }
      hdr_ptr = new int [_headerLength + INTSIZE];
      if ( hdr_ptr == NULL ) {
        cerr << "Cannot allocate enough memory to save the file header!" << endl;
        status = false;
        return status;
      }

      // Put the size into the header
      hdr_ptr[0] = _headerLength;
      return_code = fread( &(hdr_ptr[1]), 1, _headerLength, file_ptr);
      if( return_code != _headerLength ) {
        cerr << "Cannot read the full header: " << return_code << endl;
        status = false;
        return status;
      }

      // ___________________________________________________________________
      //                                  Extract data from the header block

      // The header run number.
      _runNumber = hdr_ptr[FILE_HDR_RUNNR];

      // The header run mode.
      _runMode = hdr_ptr[FILE_HDR_RUN_MODE];

      // The serial number of the file.
      _fileSerialNumber = hdr_ptr[FILE_HDR_SERIAL];

      // number of the first event.
      _firstEvent = hdr_ptr[FILE_HDR_FIRST_EVENT];

      // Timestamp of the first event.
      tmp_time = gmtime((const time_t*) (hdr_ptr+FILE_HDR_FIRST_EVENT_SEC));
      _firstEventTime = asctime(tmp_time);

      // Number of the last event.
      _lastEvent = hdr_ptr[FILE_HDR_LAST_EVENT];

      // Timestamp of the last event.
      tmp_time = gmtime((const time_t*) (hdr_ptr+FILE_HDR_LAST_EVENT_SEC));
      _lastEventTime = asctime(tmp_time);

      // TODO: Additional fields
      int additionalWordLength = 1 + (hdr_ptr[FILE_HDR_LENGTH]/INTSIZE) - FILE_HDR_ADDITIONAL;
      _additionalWords.resize(additionalWordLength);
      for (int idx=0; idx < additionalWordLength; ++idx) {
        _additionalWords[idx] = hdr_ptr[idx + FILE_HDR_ADDITIONAL];
      }

      // Clean up temporary header block
      if ( hdr_ptr != NULL )
        delete [] hdr_ptr;
      status = true;

      return status;
    }

    void Header::summary() const
    {
      cout << "------------------------------------------------------------" << endl;
      cout << "  Summary of the data header information" << endl;
      cout << "------------------------------------------------------------" << endl;
      cout << "  Run number          : " << _runNumber << endl;
      cout << "  Run mode            : " << _runMode << endl;
      cout << "  File serial number  : " << _fileSerialNumber << endl;
      cout << "  First event number  : " << _firstEvent << endl;
      cout << "  Time of first event : " << _firstEventTime; // << endl;
      cout << "  Last event number   : " << _lastEvent << endl;
      cout << "  Time of last event  : " << _lastEventTime; // << endl;
      if (_additionalWords.size() > 0) {
        cout << "  Additional words" << endl;
        for (int idx=0; idx < _additionalWords.size(); ++idx) {
          cout << "    Words " << idx << "         : " << _additionalWords[idx] <<endl;
        }
      }
      cout << "------------------------------------------------------------" << endl;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


