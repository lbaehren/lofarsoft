/*****************************************************************************
 *                                                                           *
 *  Implementation of the Local Station class for AERA data                  *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <iostream>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "LocalStation.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files


// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  LocalStation
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                LocalStation

    LocalStation::LocalStation ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void LocalStation::init ()
    {
      _length       = 0;
      _eventNumber  = 0;
      _LS_ID        = 0;
      _hardware     = "";
      _headerLength = 0;
      _seconds      = 0;
      _nanoseconds  = 0;
      _triggerFlag  = 0;
      _triggerPos   = 0;
      _samplingFreq = 0;
      _channelMask  = 0;
      _ADCResolution= 0;
      _traceLength  = 0;
      _version      = 0;
      _messageID    = 0;
      _preTriggerWindow  = 0;
      _coincedenceWindow = 0;
      _postTriggerWindow = 0;

      _signalThresholds.resize(nChannels(), 0);
      _noiseThresholds.resize(nChannels(), 0);
    }

    // ________________________________________________________________________
    //                                                               ~LocalStation

    LocalStation::~LocalStation ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void LocalStation::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================

    unsigned short LocalStation::getSignalThreshold (const unsigned short channelNr) const
    {
      unsigned short signalThreshold = 0;

      if ( channelNr < nChannels() ) {
        signalThreshold = _signalThresholds[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return signalThreshold;
    }

    unsigned short LocalStation::getNoiseThreshold (const unsigned short channelNr) const
    {
      unsigned short noiseThreshold = 0;

      if ( channelNr < nChannels() ) {
        noiseThreshold = _noiseThresholds[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return noiseThreshold;
    }

    std::vector<int> LocalStation::getADCData(const unsigned short channelNr) const
    {
      vector<int> channelData;

      if (channelNr < nChannels()) {
        channelData = _adc_data[channelNr];
      } else {
        cerr << "Invalid channel number " << endl;
      }

      return channelData;
    }


    // ========================================================================
    //  Methods
    // ========================================================================

    // ________________________________________________________________________
    //                                                                  summary

    void LocalStation::summary () const
    {
      cout << "------------------------------------------------------------" << endl;
      cout << "  Summary of local station event information" << endl;
      cout << "------------------------------------------------------------" << endl;
      cout << "  Length             : " << getLength() << endl;
      cout << "  Event number       : " << getEventNumber() << endl;
      cout << "  ID                 : " << getLocalStationID() << endl;
      cout << "  Hardware           : " << getHardware() << endl;
      cout << "  Seconds            : " << getSeconds() << endl;
      cout << "  Nano seconds       : " << getNanoSeconds() << endl;
      cout << "  Trigger flag       : 0x" << hex << setw(4) << setfill('0') << getTriggerFlag() << dec << endl;
      cout << "  Trigger position   : " << getTriggerPosition() << endl;
      cout << "  Sampling frequency : " << getSamplingFrequency() << endl;
      cout << "  Channel mask       : 0x" << hex << setw(4) << setfill('0') << getChannelMask() << dec << endl;
      cout << "  ADC resolution     : " << getADCResolution() << endl;
      cout << "  Trace length       : " << getTraceLength() << endl;
      cout << "  Version            : " << getVersion() << endl;
      cout << "------------------------------------------------------------" << endl;


      // // ADC data

      // cout << "    Message ID               : " << getMessageID() << endl;
      // cout << "    Pre-trigger window       : " << getPreTriggerWindow() << endl;
      // cout << "    Coincedence window       : " << getCoincedenceWindow() << endl;
      // cout << "    Post trigger window      : " << getPostTriggerWindow() << endl;
      // cout << "  ADC data" << endl;
      // for (int idx = 0; idx < N_CHANNELS; ++idx) {
      //   cout << "    Signal threshold (ch "<< idx <<")  : " << getSignalThreshold(idx) << endl;
      // }
      // for (int idx = 0; idx < N_CHANNELS; ++idx) {
      //   cout << "    Noise threshold (ch "<< idx <<")   : " << getNoiseThreshold(idx) << endl;
      // }
    }


  } // Namespace Data -- end

} // Namespace AERA -- end


