/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data Event class using data format version 2    *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_V2_DATA_EVENT_H
#define AERA_V2_DATA_EVENT_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <vector>
#include <string>

// ________________________________________________________________________
//                                                    Project include files

#include "Event.h"
#include "EventHeader_v2.h"
#include "LocalStation_v2.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

#define AERA_V2_EVENT_LS                 22 // Start position of local station information.

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Event_v2
    //
    // ================================================================== Class

    /*!
      \class Event_v2

      \brief Event of an AERA data file

      \author Martin van den Akker

      \date 2011/09/08

      \test tEvent_v2.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class Event_v2 : public Event { // Class Event_v2 -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      Event_v2 ();

      /*!
        \brief Destructor
      */
      virtual ~Event_v2 ();


    protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

    protected:


    public:


      // ======================================================================
      //  Methods
      // ======================================================================

    public:

      /*!
        \brief Read event information from file.

        \param file_ptr -- Pointer to datafile.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      bool read (FILE* file_ptr);

    protected:


    }; // Class Event_v2 -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_V2_DATA_EVENT_H */

