/*****************************************************************************
 *                                                                           *
 *  Implementation of the Local Station class for AERA data format version 2 *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <iostream>
#include <vector>
#include <string>
#include <sstream>
// ________________________________________________________________________
//                                                    Project include files

#include "LocalStation_v2.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files


// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  LocalStation_v2
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                          LocalStation_v2

    LocalStation_v2::LocalStation_v2 ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void LocalStation_v2::init ()
    {
      _length       = 0;
      _eventNumber  = 0;
      _LS_ID        = 0;
      _hardware     = "";
      _headerLength = 0;
      _seconds      = 0;
      _nanoseconds  = 0;
      _triggerFlag  = 0;
      _triggerPos   = 0;
      _samplingFreq = 0;
      _channelMask  = 0;
      _ADCResolution= 0;
      _traceLength  = 0;
      _version      = 0;

      _messageID = 0;
      _dataLength = 0;
      _channelMask = 0;
      _triggerMask = 0;
      _CTD = 0;
      _preTriggerWindow = 0;
      _coincedenceWindow = 0;
      _postTriggerWindow = 0;

      _signalThresholds.resize(nChannels(), 0);
      _noiseThresholds.resize(nChannels(), 0);

      _nACDValues = 0;
    }

    // ________________________________________________________________________
    //                                                         ~LocalStation_v2

    LocalStation_v2::~LocalStation_v2 ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void LocalStation_v2::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================

    void LocalStation_v2::getADCDataBlock(const unsigned char* adcData,
                                          const int adcSize,
                                          unsigned short* dataValue,
                                          int* dataSize)
    {
      int i,j,imax;

      j = AERA_V2_MSG_DATA_ADC - AERA_V2_MSG_OFFSET; // start at the beginning of the ADC data
      imax = 2 * (adcSize - (AERA_V2_MSG_DATA_ADC + 1)) / 3;  // calculate total number of ADC words (2 in 3 bytes!)
      *dataSize = imax;                               // the length to return = number of ADC words
      for (i=0; i < imax; ++i) {                      // loop over all values
        if ( (i&1) ) {
          dataValue[i] = ((unsigned short)adcData[j+1]<<4) | (adcData[j]>>4);
          j += 2;
        }
        else {
          dataValue[i] = (((unsigned short)adcData[j+1]&0xf)<<8) | adcData[j];
          ++j;
        }
      }
    }


    // ========================================================================
    //  Methods
    // ========================================================================

    // ________________________________________________________________________
    //                                                                     read

    bool LocalStation_v2::read (unsigned short* evt_ptr)
    {
      bool status = false;
      AERA_V2_LS_DATA* evt_container = (AERA_V2_LS_DATA*)(evt_ptr);
      int htype;
      int hversion;
      stringstream hversion_ss;//create a stringstream

      unsigned short rawSize = 0;
      unsigned short s = 0;
      unsigned char* rawADC_ptr = NULL;
      unsigned short* dataValue = NULL;
      int dataSize;
      int idx = 0;


      _length = evt_container->length;
      _eventNumber = evt_container->event_nr;
      _LS_ID = evt_container->LS_ID & 0xff;

      htype = ((evt_container->LS_ID>>8)&5);
      hversion = (evt_container->LS_ID>>11) & 0x1f;
      hversion_ss << hversion;//add number to the stream

      _hardware = hardware[htype-1] + " Version " + hversion_ss.str();
      _headerLength = evt_container->header_length;
      _seconds      = evt_container->GPSseconds;
      _nanoseconds  = evt_container->GPSnanoseconds;
      _triggerFlag  = evt_container->trigger_flag;
      _triggerPos   = evt_container->trigger_pos;
      _samplingFreq = evt_container->sampling_freq;
      _channelMask  = evt_container->channel_mask;
      _ADCResolution= evt_container->ADC_resolution;
      _traceLength  = evt_container->tracelength;
      _version      = evt_container->version;

      // Raw ADC data
      rawADC_ptr = (unsigned char*) evt_container->info_ADCbuffer;
      if ( htype == AERA_V2_LS_NL ) {
        _messageID = rawADC_ptr[AERA_V2_MSG_ID - AERA_V2_MSG_OFFSET];

        _dataLength = (rawADC_ptr[AERA_V2_MSG_LEN - AERA_V2_MSG_OFFSET]<<8) + (rawADC_ptr[AERA_V2_MSG_LEN - AERA_V2_MSG_OFFSET+1]&0xff);

        _channelMask = rawADC_ptr[AERA_V2_MSG_DATA_CH - AERA_V2_MSG_OFFSET];

        _triggerMask = rawADC_ptr[AERA_V2_MSG_DATA_TRIG - AERA_V2_MSG_OFFSET];

        _preTriggerWindow  = (rawADC_ptr[AERA_V2_MSG_DATA_PRE - AERA_V2_MSG_OFFSET]<<8)   + (rawADC_ptr[AERA_V2_MSG_DATA_PRE - AERA_V2_MSG_OFFSET+1]&0xff);

        _coincedenceWindow = (rawADC_ptr[AERA_V2_MSG_DATA_COINC - AERA_V2_MSG_OFFSET]<<8) + (rawADC_ptr[AERA_V2_MSG_DATA_COINC - AERA_V2_MSG_OFFSET+1]&0xff);

        _postTriggerWindow = (rawADC_ptr[AERA_V2_MSG_DATA_POST - AERA_V2_MSG_OFFSET]<<8)  + (rawADC_ptr[AERA_V2_MSG_DATA_POST - AERA_V2_MSG_OFFSET+1]&0xff);

        // //don't worry about the GPS time
        _CTD = ((rawADC_ptr[AERA_V2_MSG_DATA_CTD - AERA_V2_MSG_OFFSET]<<24) +
                (rawADC_ptr[AERA_V2_MSG_DATA_CTD - AERA_V2_MSG_OFFSET + 1]<<16) +
                (rawADC_ptr[AERA_V2_MSG_DATA_CTD - AERA_V2_MSG_OFFSET + 2]<<16) +
                (rawADC_ptr[AERA_V2_MSG_DATA_CTD - AERA_V2_MSG_OFFSET + 3]));

        // Signal threshold
        for (idx=0; idx<nChannels(); ++idx) {
          _signalThresholds[idx] = ((rawADC_ptr[AERA_V2_MSG_DATA_STHRES1 - AERA_V2_MSG_OFFSET+2*idx]<<8) +
                                    (rawADC_ptr[AERA_V2_MSG_DATA_STHRES1 - AERA_V2_MSG_OFFSET+2*idx+1]&0xff));
        }

        // Noise threshold
        for(idx=0; idx<nChannels(); ++idx) {
          _noiseThresholds[idx] = ((rawADC_ptr[AERA_V2_MSG_DATA_NTHRES1 - AERA_V2_MSG_OFFSET+2*idx]<<8) +
                                   (rawADC_ptr[AERA_V2_MSG_DATA_NTHRES1 - AERA_V2_MSG_OFFSET+2*idx+1]&0xff));
        }

        // ADC data
        int mmm = (nChannels()) * _traceLength;
        if (NULL != dataValue) {
          delete [] dataValue;
        }
        dataValue = new unsigned short[mmm];
        if ( NULL == dataValue ) {
          cerr << "Cannot allocate memory to read out ADC values!" << endl;
          status = false;
          return status;
        }
        rawSize = ((rawADC_ptr[AERA_V2_MSG_LEN - AERA_V2_MSG_OFFSET + 1]<<8) +
                   (rawADC_ptr[AERA_V2_MSG_LEN - AERA_V2_MSG_OFFSET]&0xff));
        getADCDataBlock(rawADC_ptr, rawSize, dataValue, &dataSize);

        // Number of ADC values
        _nACDValues = dataSize;

        _adc_data.resize(nChannels(), vector<int>(_traceLength));

        if (dataSize <= nChannels() * _traceLength) {
          for (int i_chan = 0; i_chan < nChannels(); ++i_chan) {
            for (idx = 0; idx < _traceLength; ++idx) {
              _adc_data[i_chan][idx] = dataValue[i_chan * _traceLength + idx];
            }
          }
        }
      }

      delete [] dataValue;

      status = true;

      return status;
    }

    // ________________________________________________________________________
    //                                                                  summary

    void LocalStation_v2::summary () const
    {
      LocalStation::summary();

      // ADC data

      cout << "  ADC data" << endl;
      cout << "    Message ID               : 0x" << hex << setw(2) << setfill('0') << getMessageID() << dec << endl;
      cout << "    Data length              : " << getDataLength() << endl;
      cout << "    Channel mask             : 0x" << hex << setw(2) << setfill('0') << getChannelMask() << dec << endl;
      cout << "    Trigger mask             : 0x" << hex << setw(2) << setfill('0') << getTriggerMask() << dec << endl;
      cout << "    Pre-trigger window       : " << getPreTriggerWindow() << endl;
      cout << "    Coincidence window       : " << getCoincedenceWindow() << endl;
      cout << "    Post trigger window      : " << getPostTriggerWindow() << endl;
      cout << "    CTD                      : " << getCTD() << endl;
      for (int idx = 0; idx < nChannels(); ++idx) {
        cout << "    Signal threshold (ch "<< idx <<")  : " << getSignalThreshold(idx) << endl;
      }
      for (int idx = 0; idx < nChannels(); ++idx) {
        cout << "    Noise threshold (ch "<< idx <<")   : " << getNoiseThreshold(idx) << endl;
      }
      cout << "    Number of ADC values     : " << nADCValues() << endl;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


