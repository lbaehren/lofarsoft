/*****************************************************************************
 *                                                                           *
 *  Implementation of the Header class for AERA data format version 2        *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <time.h>

// ________________________________________________________________________
//                                                    Project include files

#include "Constants_v2.h"
#include "Header_v2.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Header_v2
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                Header_v2

    Header_v2::Header_v2 ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Header_v2::init ()
    {
      _headerLength = 0;
      _runNumber = 0;
      _runMode = 0;
      _fileSerialNumber = 0;
      _firstEvent = 0;
      _firstEventTime = "Not defined\n";
      _lastEvent = 0;
      _lastEventTime = "Not defined\n";
    }

    // ________________________________________________________________________
    //                                                               ~Header_v2

    Header_v2::~Header_v2 ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Header_v2::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    // ========================================================================
    //  Methods
    // ========================================================================

    bool Header_v2::read(FILE* file_ptr)
    {
      bool status = false;
      int* hdr_ptr = NULL;
      int return_code = 0;

      unsigned int raw_timestamp = 0;

      // ___________________________________________________________________
      //                                    Read data header block from file

      // Read header length
      if ( !fread(&_headerLength, INTSIZE, 1, file_ptr) ) {
        cerr << "Cannot read the header length" << endl;
        status = false;
        return status;
      }

      // Check header length
      if ( _headerLength < AERA_V2_FILE_HDR_ADDITIONAL ) {
        cerr << "The file header is too short, only " << _headerLength << " integers" << endl;
        status = false;
        return status;
      }

      // Allocate memory for the file header
      if ( hdr_ptr != NULL ) {
        delete [] hdr_ptr;
      }
      hdr_ptr = new int [_headerLength + INTSIZE];
      if ( hdr_ptr == NULL ) {
        cerr << "Cannot allocate enough memory to save the file header!" << endl;
        status = false;
        return status;
      }

      // Put the size into the header
      hdr_ptr[0] = _headerLength;
      return_code = fread( &(hdr_ptr[1]), 1, _headerLength, file_ptr);
      if( return_code != _headerLength ) {
        cerr << "Cannot read the full header: " << return_code << endl;
        status = false;
        return status;
      }

      // ___________________________________________________________________
      //                                  Extract data from the header block

      // The header run number.
      _runNumber = hdr_ptr[AERA_V2_FILE_HDR_RUNNR];

      // The header run mode.
      _runMode = hdr_ptr[AERA_V2_FILE_HDR_RUN_MODE];

      // The serial number of the file.
      _fileSerialNumber = hdr_ptr[AERA_V2_FILE_HDR_SERIAL];

      // number of the first event.
      _firstEvent = hdr_ptr[AERA_V2_FILE_HDR_FIRST_EVENT];


      // Timestamp of the first event (switched from UTC (in v1) to GPS (in v2)).
      raw_timestamp = *((unsigned int*) &hdr_ptr[AERA_V2_FILE_HDR_FIRST_EVENT_SEC]);
      _firstEventTime = timestamp_raw2string(raw_timestamp);

      // Number of the last event.
      _lastEvent = hdr_ptr[AERA_V2_FILE_HDR_LAST_EVENT];

      // Timestamp of the last event (switched from UTC (in v1) to GPS (in v2)).
      raw_timestamp = *((unsigned int*) &hdr_ptr[AERA_V2_FILE_HDR_LAST_EVENT_SEC]);
      _lastEventTime = timestamp_raw2string(raw_timestamp);

      // Additional fields
      int additionalWordLength = 1 + (hdr_ptr[AERA_V2_FILE_HDR_LENGTH]/INTSIZE) - AERA_V2_FILE_HDR_ADDITIONAL;
      if (additionalWordLength < 0) {
        cerr << "The header is too short!" << endl;
        if (hdr_ptr != NULL) {
          delete [] hdr_ptr;
        }
        status = false;
        return status;
      }
      _additionalWords.resize(additionalWordLength);
      for (int idx=0; idx < additionalWordLength; ++idx) {
        _additionalWords[idx] = hdr_ptr[idx + AERA_V2_FILE_HDR_ADDITIONAL];
      }

      // Clean up temporary header block
      if ( hdr_ptr != NULL )
        delete [] hdr_ptr;
      status = true;

      return status;
    }


    unsigned int Header_v2::gps2utc(const unsigned int gps_time)
    {
      unsigned int result = 0;

      result = gps_time + GPS_EPOCH - LEAP_SEC;

      return result;
    }

    string Header_v2::timestamp_raw2string(const unsigned int rawtimestamp)
    {
      string result = "";

      unsigned int raw_timestamp = rawtimestamp;
      time_t sec_timestamp = 0;
      struct tm* utc_timestamp;

      if ( raw_timestamp < AERA_V2_START_UNIX ) {
        raw_timestamp = gps2utc(raw_timestamp);
      }
      sec_timestamp = (time_t) raw_timestamp;
      utc_timestamp = gmtime(&sec_timestamp);

      result = TimeString(utc_timestamp);

      return result;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


