/*****************************************************************************
 *                                                                           *
 *  Header file for the factory for AERA Data Events                         *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_EVENT_FACTORY_H
#define AERA_DATA_EVENT_FACTORY_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "Event.h"
#include "Event_v1.h"
#include "Event_v2.h"


// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  EventFactory
    //
    // ================================================================== Class

    /*!
      \class EventFactory

      \brief Create event objects for a specific version number of the data format

      \author Martin van den Akker

      \date 2011/09/08

      \test tEventFactory.cc

      <h3>Prerequisite</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>
    */
    class EventFactory { // Class EventFactory -- begin

      // _________________________________________________________________________
      //                                                                   Methods

     public:

      /*!
        \brief Create an event object for a specific data format version.

        \param dataformatversion -- Version number of the data format.

        \return event_ptr -- Pointer to the event object that is created.
      */
      Data::Event* create(const int dataformatversion);

    }; // Class EventFactory -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_EVENT_FACTORY_H */

