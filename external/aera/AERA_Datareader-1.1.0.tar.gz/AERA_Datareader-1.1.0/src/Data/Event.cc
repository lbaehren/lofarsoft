/*****************************************************************************
 *                                                                           *
 *  Implementation of the Event class for AERA data                          *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "Event.h"
#include "EventHeader.h"
#include "LocalStation.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Event
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                    Event

    Event::Event ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Event::init ()
    {
      _eventheader = NULL;
    }

    // ________________________________________________________________________
    //                                                                   ~Event

    Event::~Event ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Event::destroy ()
    {
    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    // ========================================================================
    //  Methods
    // ========================================================================


    void Event::summary () const
    {
      vector<LocalStation*>::const_iterator localstation_it = _localstations.begin();

      cout << "------------------------------------------------------------" << endl
           << "  Summary of event information" << endl
           << "------------------------------------------------------------" << endl
           << "  Number of local stations : " << nLocalStations() << endl;

      // Event header
      _eventheader->summary();

      // Local stations
      if ( nLocalStations() > 0 ) {
        while ( localstation_it != _localstations.end() ) {
          (*localstation_it)->summary();
          ++localstation_it;
        }
      }
    }


    LocalStation* Event::currentLocalStation () const
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        localStation_ptr = *_currentLocalStation_it;
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


    bool Event::isFirstLocalStation () const
    {
      bool status = false;

      if ( _localstations.begin() == _currentLocalStation_it ) {
        status = true;
      }

      return status;
    }


    LocalStation* Event::firstLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        _currentLocalStation_it = _localstations.begin();
        localStation_ptr = _localstations.front();
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


    LocalStation* Event::prevLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        if ( _currentLocalStation_it != _localstations.begin() ) {
          --_currentLocalStation_it;
        }
        localStation_ptr = *_currentLocalStation_it;
      } else {
        cerr << "No local stations available!" << endl;
      }
      return localStation_ptr;
    }


    LocalStation* Event::nextLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        if ( _currentLocalStation_it != (_localstations.end() - 1) ) {
          ++_currentLocalStation_it;
          localStation_ptr = *_currentLocalStation_it;
        }
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }


    bool Event::isLastLocalStation () const
    {
      bool status = false;

      if ( _localstations.end() == _currentLocalStation_it ) {
        status = true;
      }

      return status;
    }


    LocalStation* Event::lastLocalStation ()
    {
      LocalStation* localStation_ptr = NULL;

      if ( _localstations.size() > 0 ) {
        _currentLocalStation_it = _localstations.end() - 1;
        localStation_ptr = _localstations.back();
      } else {
        cerr << "No local stations available!" << endl;
      }

      return localStation_ptr;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


