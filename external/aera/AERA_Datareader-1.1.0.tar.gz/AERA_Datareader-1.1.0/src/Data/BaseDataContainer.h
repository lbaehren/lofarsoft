/*****************************************************************************
 *                                                                           *
 *  Base class for AERA data file objects                                    *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_BASE_DATA_CONTAINER_H
#define AERA_BASE_DATA_CONTAINER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <string>
#include <iomanip>

// ________________________________________________________________________
//                                                    Project include files


// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

#define UINT16 unsigned short
#define INTSIZE   4 //size of an integer
#define SHORTSIZE 2 //size of a short


namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  BaseDataContainer
    //
    // ================================================================== Class

    /*!
      \class BaseDataContainer

      \brief General components and functionality for AERA data file objects.

      \author Martin van den Akker

      \date 2010/11/16

      \test tBaseDataContainer.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class BaseDataContainer { // Class BaseDataContainer -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      inline BaseDataContainer () {
        //_file_ptr = NULL;
        _classname = "";
      };

      /*!
        \brief Destructor
      */
      virtual ~BaseDataContainer () {};


    private:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

    protected:

      //! File pointer to data file
      //FILE* _file_ptr;

      //! Name of the class
      std::string _classname;

      // ======================================================================
      //  Methods
      // ======================================================================

    public:

      //virtual bool read(FILE* file_ptr) {};

      virtual void summary() const {};

      inline std::string getClassname() const
      {
        return _classname;
      }

    private:


    }; // Class BaseDataContainer -- end


  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_BASE_DATA_CONTAINER_H */

