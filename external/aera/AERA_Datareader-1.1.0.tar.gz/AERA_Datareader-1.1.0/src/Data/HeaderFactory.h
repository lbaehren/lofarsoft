/*****************************************************************************
 *                                                                           *
 *  Header for the factory of AERA data headers.                             *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_HEADER_FACTORY_H
#define AERA_DATA_HEADER_FACTORY_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "Header.h"
#include "Header_v1.h"
#include "Header_v2.h"


// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    /*!
      \class HeaderFactory

      \brief Create header objects for a specific version number of the data format.

      \author Martin van den Akker

      \date 2011/09/08

      \test tHeaderFactory.cc

      <h3>Prerequisite</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>
    */
    class HeaderFactory { // Class HeaderFactory -- begin

      // _________________________________________________________________________
      //                                                                   Methods

     public:

      Data::Header* create(const int dataformatversion);

    }; // Class HeaderFactory -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_HEADER_FACTORY_H */

