/*****************************************************************************
 *                                                                           *
 *  Implementation of the Event class for AERA data format version 2         *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "Event_v2.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Event_v2
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                 Event_v2

    Event_v2::Event_v2 ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Event_v2::init ()
    {
      Event::init();

      _eventheader = new EventHeader_v2();
    }

    // ________________________________________________________________________
    //                                                                ~Event_v2

    Event_v2::~Event_v2 ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Event_v2::destroy ()
    {
      vector<Data::LocalStation*>::iterator localstation_it = _localstations.begin();

      delete (_eventheader);

      if ( _localstations.size() > 0 ) {
        while ( localstation_it != _localstations.end() ) {
          delete (*localstation_it);
          ++localstation_it;
        }
      }
    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    // ========================================================================
    //  Methods
    // ========================================================================

    bool Event_v2::read (FILE* file_ptr)
    {
      bool status = false;
      unsigned short* evt_ptr = NULL;
      int eventLength = 0;
      int return_length = 0;

      int ls_idx = 0;
      int evt_end = 0;
      LocalStation* localstationdata = NULL;

      // GetEventLength
      if ( false == fread(&eventLength, INTSIZE, 1, file_ptr) ) {
        cerr << "Cannot readout event length" << endl;
        status = false;
        return status;
      }
      // Allocate memory for the event
      if ( NULL != evt_ptr ) {
        if ( evt_ptr[0] != eventLength ) {
          delete [] evt_ptr;
          evt_ptr = new unsigned short [eventLength + INTSIZE];
        }
      } else {
        evt_ptr = new unsigned short [eventLength + INTSIZE];
      }
      if ( NULL == evt_ptr ) {
        cerr << "Cannot allocate enough memory to save the event!" << endl;
        status = false;
        delete [] evt_ptr;
        return status;
      }

      // Put the size into the event
      evt_ptr[0] = eventLength & 0xffff;
      evt_ptr[1] = eventLength >> 16;

      return_length = fread (&(evt_ptr[2]), 1, eventLength, file_ptr);
      if (return_length != eventLength) {
        cerr << "Cannot read the full event: " << return_length << endl;
        status = false;
        delete [] evt_ptr;
        return status;
      }

      // Read the event header
      status = _eventheader->read (evt_ptr);
      if (false == status) {
        cerr << "Error: Unable to read event header" << endl;
        delete [] evt_ptr;
        return status;
      }

      // Read local station data
      ls_idx = AERA_V2_EVENT_LS;
      evt_end = eventLength/SHORTSIZE;
      // Loop over local station information.
      while (ls_idx < evt_end) {
        localstationdata = new LocalStation_v2();
        status = localstationdata->read(&(evt_ptr[ls_idx]));
        if (true == status) {
          _localstations.push_back (localstationdata);
        } else {
          delete [] evt_ptr;
          return status;
        }
        ls_idx += localstationdata->getLength();
      }

      _currentLocalStation_it = _localstations.begin();

      delete [] evt_ptr;

      status = true;

      return status;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


