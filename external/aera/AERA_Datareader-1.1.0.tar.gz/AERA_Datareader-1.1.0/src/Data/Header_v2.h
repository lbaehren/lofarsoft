/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data Header class using data format version 2   *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_V2_DATA_HEADER_H
#define AERA_V2_DATA_HEADER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <string>

// ________________________________________________________________________
//                                                    Project include files

#include "Constants_v2.h"
#include "Header.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

/* First define the header words */
#define AERA_V2_FILE_HDR_LENGTH          0
#define AERA_V2_FILE_HDR_RUNNR           1
#define AERA_V2_FILE_HDR_RUN_MODE        2
#define AERA_V2_FILE_HDR_SERIAL          3
#define AERA_V2_FILE_HDR_FIRST_EVENT     4
#define AERA_V2_FILE_HDR_FIRST_EVENT_SEC 5
#define AERA_V2_FILE_HDR_LAST_EVENT      6
#define AERA_V2_FILE_HDR_LAST_EVENT_SEC  7
#define AERA_V2_FILE_HDR_ADDITIONAL      8 //start of additional info to be defined

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Header_v2
    //
    // ================================================================== Class

    /*!
      \class Header_v2

      \brief Header_v2 of an AERA data file

      \author Martin van den Akker

      \date 2011/09/08

      \test tHeader_v2.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class Header_v2: public Header { // Class Header_v2 -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

     public:

      /*!
        \brief Default constructor
      */
      Header_v2 ();

      /*!
        \brief Destructor
      */
      virtual ~Header_v2 ();


     protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

     private:


     public:


      // ======================================================================
      //  Methods
      // ======================================================================

     public:

      /*!
        \brief Read the data header information from file.

        \param file_ptr -- Pointer to the datafile.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      bool read(FILE* file_ptr);

     private:

      /*!
        \brief Convert  GPS time to UTC time

        \param gps_time -- GPS time

        \return utc_time -- The calculated UTC time.
      */
      unsigned int gps2utc(const unsigned int gps_time);


      /*!
        \brief Convert a raw timestamp to a human readable string.

        \param rawtimestamp -- Raw timestamp.

        \return stringtimestamp -- Human readable timestamp.
      */
      std::string timestamp_raw2string(const unsigned int rawtimestamp);

    }; // Class Header_v2 -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_V2_DATA_HEADER_H */

