/*****************************************************************************
 *                                                                           *
 *  Header file of the AERA LocalStation class for data format version 2     *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_V2_DATA_EVENT_BODY_H
#define AERA_V2_DATA_EVENT_BODY_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "LocalStation.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

typedef struct{
  UINT16 length;
  UINT16 event_nr;
  UINT16 LS_ID;
  UINT16 header_length;
  unsigned int GPSseconds;
  unsigned int GPSnanoseconds;
  UINT16 trigger_flag;
  UINT16 trigger_pos;
  UINT16 sampling_freq;
  UINT16 channel_mask;
  UINT16 ADC_resolution;
  UINT16 tracelength;
  UINT16 version;
  UINT16 info_ADCbuffer[];
} AERA_V2_LS_DATA;

/* Next part copied from scope.h */
#define AERA_V2_MSG_ID          1
#define AERA_V2_MSG_LEN         2    // Only for FADC->PC messages
#define AERA_V2_MSG_DATA_CH     4
#define AERA_V2_MSG_DATA_TRIG   5
#define AERA_V2_MSG_DATA_PRE    6
#define AERA_V2_MSG_DATA_COINC  8
#define AERA_V2_MSG_DATA_POST  10
#define AERA_V2_MSG_DATA_TIME  12
#define AERA_V2_MSG_DATA_CTD   19
#define AERA_V2_MSG_DATA_STHRES1 23
#define AERA_V2_MSG_DATA_STHRES2 25
#define AERA_V2_MSG_DATA_STHRES3 27
#define AERA_V2_MSG_DATA_STHRES4 29
#define AERA_V2_MSG_DATA_NTHRES1 31
#define AERA_V2_MSG_DATA_NTHRES2 33
#define AERA_V2_MSG_DATA_NTHRES3 35
#define AERA_V2_MSG_DATA_NTHRES4 37
#define AERA_V2_MSG_DATA_ADC   39

#define AERA_V2_MSG_OFFSET 1 /* I did not copy the first word! */

#define AERA_V2_N_CHANNELS 4

#define AERA_V2_LS_NL AERA_LS_NL
#define AERA_V2_LS_FR AERA_LS_FR
#define AERA_V2_LS_GE AERA_LS_GE


namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  LocalStation_v2
    //
    // ================================================================== Class

    /*!
      \class LocalStation_v2

      \brief Event data for AERA from a single local station.

      \author Martin van den Akker

      \date 2011/09/08

      \test tLocalStation_v2.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class LocalStation_v2 : public LocalStation { // Class LocalStation_v2 -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

     public:

      /*!
        \brief Default constructor
      */
      LocalStation_v2 ();

      /*!
        \brief Destructor
      */
      virtual ~LocalStation_v2 ();


     protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

     protected:

      //! Data length.
      unsigned short _dataLength;

      //! Channel mask.
      unsigned short _channelMask;

      //! Trigger mask.
      unsigned short _triggerMask;

      //! CTD value.
      unsigned int _CTD;

      //! Number of ADC values.
      int _nACDValues;

     public:

      /*!
        \brief Get the data length.

        \return dataLength -- Length of the data.
      */
      inline unsigned short getDataLength() const {return _dataLength;};

      /*!
        \brief Get the channel mask.

        \return channelmask -- Channel mask.
      */
      inline unsigned short getChannelMask() const {return _channelMask;};

      /*!
        \brief Get the trigger mask.

        \return triggerMask -- Trigger mask.
      */
      inline unsigned short getTriggerMask() const {return _triggerMask;};

      /*!
        \brief Get the CTD.

        \return CTD -- CTD.
      */
      inline unsigned int getCTD() const {return _CTD;};

      /*!
        \brief Get the number of ADC values

        \return nACDvalues -- Number of ADC values.
      */
      inline int nADCValues() const {return _nACDValues;};

      /*!
        \brief Get the number of channels per station.

        \return nChannels -- Number of channels per station.
      */
      inline UINT16 nChannels () const {return AERA_V2_N_CHANNELS;};


      // ======================================================================
      //  Methods
      // ======================================================================

     public:

      /*!
        \brief Read local station event information from file.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      bool read (unsigned short* evt_ptr);

      /*!
        \brief Get a summary of the local station event information.
      */
      void summary () const;


     protected:

      /*!
        \brief  Extract an ADC data values from the raw ADC memory block.

        \param rawData   -- Raw ADC data.
        \param rawSize   -- Total size of the ADC data.
        \param dataValue -- Location to store the data values.
        \param dataSize  -- Size of the data value storage.
      */
      void getADCDataBlock (const unsigned char* rawData,
                            const int rawSize,
                            unsigned short* dataValue,
                            int* dataSize);

    }; // Class LocalStation_v2 -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_V2_DATA_EVENT_BODY_H */

