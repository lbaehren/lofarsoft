/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data EventHeader class version 1                *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_V1_DATA_EVENT_HEADER_H
#define AERA_V1_DATA_EVENT_HEADER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "EventHeader.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

/* Header words for the event header */
#define AERA_V1_EVENT_HDR_LENGTH          0
#define AERA_V1_EVENT_HDR_RUNNR           2
#define AERA_V1_EVENT_HDR_EVENTNR         4
#define AERA_V1_EVENT_HDR_T3EVENTNR       6
#define AERA_V1_EVENT_HDR_FIRST_LS        8
#define AERA_V1_EVENT_HDR_EVENT_SEC      10
#define AERA_V1_EVENT_HDR_EVENT_NSEC     12
#define AERA_V1_EVENT_HDR_EVENT_TYPE     14

#define AERA_V1_EVENT_HDR_AD1            16 //start of additional info to be defined
#define AERA_V1_EVENT_HDR_AD2            18 //                    info to be defined
#define AERA_V1_EVENT_HDR_AD3            20 //                    info to be defined

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  EventHeader_v1
    //
    // ================================================================== Class

    /*!
      \class EventHeader_v1

      \brief Header of an AERA event for data format version 1.

      \author Martin van den Akker

      \date 2011/09/08

      \test tEventHeader_v1.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class EventHeader_v1 : public EventHeader { // Class EventHeader_v1 -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      EventHeader_v1 ();

      /*!
        \brief Destructor
      */
      virtual ~EventHeader_v1 ();


    private:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

     protected:



     public:



      // ======================================================================
      //  Methods
      // ======================================================================

     public:

      /*!
        \brief Read the event header information from file.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      bool read (unsigned short* evt_ptr);


    protected:


    }; // Class EventHeader_v1 -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_V1_DATA_EVENT_HEADER_H */

