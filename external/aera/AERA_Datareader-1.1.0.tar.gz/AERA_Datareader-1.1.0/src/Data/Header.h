/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data Header class                               *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_HEADER_H
#define AERA_DATA_HEADER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "BaseDataContainer.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================


namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Header
    //
    // ================================================================== Class

    /*!
      \class Header

      \brief Header of an AERA data file

      \author Martin van den Akker

      \date 2010/11/16

      \test tHeader.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class Header: public BaseDataContainer { // Class Header -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      Header ();

      /*!
        \brief Destructor
      */
      virtual ~Header ();


    protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

     protected:


      //! Length of the header in bytes.
      int _headerLength;

      //! The header run number.
      int _runNumber;

      //! The header run mode.
      int _runMode;

      //! The serial number of the file.
      int _fileSerialNumber;

      //! number of the first event.
      int _firstEvent;

      //! Timestamp of the first event.
      std::string _firstEventTime;

      //! Number of the last event
      int _lastEvent;

      //! Timestamp of the last event.
      std::string _lastEventTime;

      //! Additional words.
      std::vector<int> _additionalWords;


     public:

      /*!
        \brief Get the length of the header.

        \return length -- Length of the header.
      */
      inline int getHeaderLength() const {return _headerLength;};

      /*!
        \brief Get the run number of the file.

        \return runNumber -- Run number of the file.
      */
      inline int getRunNumber() const {return _runNumber;};

      /*!
        \brief Get the run mode of the file.

        \return runMode -- Run mode of the file.
      */
      inline int getRunMode() const {return _runMode;};

      /*!
        \brief Get the serial number of the file.

        \return serialNumber -- Serial number of the file.
      */
      inline int getFileSerialNumber() const {return _fileSerialNumber;};

      /*!
        \brief Get the ID of the first event.

        \return ID -- ID of the first event.
      */
      inline int getFirstEvent() const {return _firstEvent;};

      /*!
        \brief Get the time of the first event.

        \return time -- String containing the time of the first event.
      */
      inline std::string getFirstEventTime() const {return _firstEventTime;};

      /*!
        \brief Get the ID of the last event.

        \return ID -- ID of the last event.
      */
      inline int getLastEvent() const {return _lastEvent;};

      /*!
        \brief Get the time of the last event.

        \return time -- String containing the time of the last event.
      */
      inline std::string getLastEventTime() const {return _lastEventTime;};

      /*!
        \brief Get a vector of additional words.

        \return additionalWords -- Vector of additional words.
      */
      inline std::vector<int> getAdditionalWords () const { return _additionalWords;};

      /*!
        \brief get a specific additional word.

        \param index -- Index of the additional word which should be returned.

        \return additionalWord -- Additional word.
      */
      int getAdditionalWord (const int idx) const;


      // ======================================================================
      //  Methods
      // ======================================================================

    public:

      /*!
        \brief Read the data header information from file.

        \param file_ptr -- Pointer to the datafile.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      virtual bool read(FILE* file_ptr) = 0;


      /*!
        \brief Get a summary of the file header.
      */
      void summary() const;


    }; // Class Header -- end


  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_HEADER_H */

