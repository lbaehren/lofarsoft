/*****************************************************************************
 *                                                                           *
 *  Implementation of the EventHeader class for AERA data format version 2   *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <iostream>
#include <string>

// ________________________________________________________________________
//                                                    Project include files

#include "EventHeader_v2.h"
#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files


// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  EventHeader_v2
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                           EventHeader_v2

    EventHeader_v2::EventHeader_v2 ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void EventHeader_v2::init ()
    {
      EventHeader::init();

      _eventVersion = 2;
    }

    // ________________________________________________________________________
    //                                                          ~EventHeader_v2

    EventHeader_v2::~EventHeader_v2 ()
    {
      destroy ();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void EventHeader_v2::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    // ========================================================================
    //  Methods
    // ========================================================================

    bool EventHeader_v2::read (unsigned short* evt_ptr)
    {
      bool status = false;

      // Event length.
      _eventLength = (evt_ptr[AERA_V2_EVENT_HDR_LENGTH+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_LENGTH];

      // Run ID of the event.
      _runID = (evt_ptr[AERA_V2_EVENT_HDR_RUNNR+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_RUNNR];

      // Event ID.
      _eventID = (evt_ptr[AERA_V2_EVENT_HDR_EVENTNR+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_EVENTNR];

      // T3 ID of the event.
      _t3eventID = (evt_ptr[AERA_V2_EVENT_HDR_T3EVENTNR+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_T3EVENTNR];

      // ID of the First Local Station.
      _firstLSID = (evt_ptr[AERA_V2_EVENT_HDR_FIRST_LS+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_FIRST_LS];

      // Seconds part of the timestamp of the event.
      _seconds = (evt_ptr[AERA_V2_EVENT_HDR_EVENT_SEC+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_EVENT_SEC];

      // Nanosecond part of the timestamp of the event.
      _nanoseconds = (evt_ptr[AERA_V2_EVENT_HDR_EVENT_NSEC+1]<<16) + evt_ptr[AERA_V2_EVENT_HDR_EVENT_NSEC];

      // Type of event.
      _eventType = evt_ptr[AERA_V2_EVENT_HDR_EVENT_TYPE];

      // Event version.
      _eventVersion = evt_ptr[AERA_V2_EVENT_HDR_EVENT_VERS];

      status = true;

      return status;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


