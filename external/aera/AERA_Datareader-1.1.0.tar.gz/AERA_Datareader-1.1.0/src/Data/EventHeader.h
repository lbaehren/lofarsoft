/*****************************************************************************
 *                                                                           *
 *  Header file for the AERA Data EventHeader class                          *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_EVENT_HEADER_H
#define AERA_DATA_EVENT_HEADER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "BaseDataContainer.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  EventHeader
    //
    // ================================================================== Class

    /*!
      \class EventHeader

      \brief Header of an AERA event.

      \author Martin van den Akker

      \date 2010/11/16

      \test tEventHeader.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class EventHeader : public BaseDataContainer { // Class EventHeader -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

    public:

      /*!
        \brief Default constructor
      */
      EventHeader ();

      /*!
        \brief Destructor
      */
      virtual ~EventHeader ();


    protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

    protected:

      //! Header length of the event.
      int _eventLength;

      //! Run ID of the event.
      int _runID;

      //! Event ID.
      int _eventID;

      //! t3 ID of the event.
      int _t3eventID;

      //! ID of the First Local Station.
      int _firstLSID;

      //! Seconds part of the timestamp of the event.
      unsigned int _seconds;

      //! Nanosecond part of the timestamp of the event.
      unsigned int _nanoseconds;

      //! Type of event.
      int _eventType;

      //! Version of the event.
      int _eventVersion;


    public:

      /*!
        \brief Get the length of the event.

        \return length -- Length of the event.
      */
      inline int getEventLength() const {return _eventLength;};

      /*!
        \brief Get the ID of the run.

        \return runID -- ID of the run.
      */
      inline int getRunID() const {return _runID;};

      /*!
        \brief Get the ID of the event.

        \return eventID -- ID of the event.
      */
      inline int getEventID() const {return _eventID;};

      /*!
        \brief Get the t3 event ID.

        \return t3EventID -- t3 event ID.
      */
      inline int getT3eventID() const {return _t3eventID;};

      /*!
        \brief Get the ID of the first local station.

        \return firstLSID -- ID of the first local station.
      */
      inline int getFirstLSID() const {return _firstLSID;};

      /*!
        \brief Get the seconds part of the timestamp of the event.

        \return seconds -- Seconds part of the timestamp of the event.
      */
      inline unsigned int getSeconds() const {return _seconds;};

      /*!
        \brief Get the nanosecond part of the timestamp of the event.

        \return nanoSeconds -- Nanoseconds part of the timestamp of the event.
      */
      inline unsigned int getNanoSeconds() const {return _nanoseconds;};

      /*!
        \brief Get the type of the event.

        \return eventType -- Type of the event.
      */
      inline int getEventType() const {return _eventType;};

      /*!
        \brief Get the version of the event.

        \return eventVersion -- Version of the event.
      */
      inline int getEventVersion() const {return _eventVersion;};


      // ======================================================================
      //  Methods
      // ======================================================================

    public:

      /*!
        \brief Read the event header information from file.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      virtual bool read (unsigned short* evt_ptr) = 0;

      /*!
        \brief Summary of the event header.
      */
      void summary () const;

    }; // Class EventHeader -- end


  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_EVENT_HEADER_H */

