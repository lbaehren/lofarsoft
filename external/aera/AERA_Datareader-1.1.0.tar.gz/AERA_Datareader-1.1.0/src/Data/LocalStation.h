/*****************************************************************************
 *                                                                           *
 *  Header file of the AERA LocalStation class                                  *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_EVENT_BODY_H
#define AERA_DATA_EVENT_BODY_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "BaseDataContainer.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================


#define AERA_N_CHANNELS 4

#define AERA_LS_NL 1
#define AERA_LS_FR 1
#define AERA_LS_GE 1


namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    static std::string hardware[3] = {"Dutch", "French", "German"};

    // ========================================================================
    //
    //  LocalStation
    //
    // ================================================================== Class

    /*!
      \class LocalStation

      \brief Event data for AERA from a single local station.

      \author Martin van den Akker

      \date 2010/11/16

      \test tLocalStation.cc

      <h3>Prerequisites</h3>

      <h3>Synopsis</h3>

      <h3>Example(s)</h3>

    */
    class LocalStation : public BaseDataContainer { // Class LocalStation -- begin

      // ======================================================================
      //  Construction / Destruction
      // ======================================================================

     public:

      /*!
        \brief Default constructor
      */
      LocalStation ();

      /*!
        \brief Destructor
      */
      virtual ~LocalStation ();


     protected:

      /*!
        \brief Attribute initialisation
      */
      void init ();

      /*!
        \brief Unconditional destruction
      */
      void destroy ();


      // ======================================================================
      //  Attributes
      // ======================================================================

     protected:

      //! Length of the event body
      UINT16 _length;

      //! Event number
      UINT16 _eventNumber;

      //! Local Station ID
      UINT16 _LS_ID;

      //! Hardware description
      std::string _hardware;

      //! Header length
      UINT16 _headerLength;

      //! GPS seconds
      unsigned int _seconds;

      //! GPS nanoseconds
      unsigned int _nanoseconds;

      //! Trigger flag
      UINT16 _triggerFlag;

      //! Trigger position
      UINT16 _triggerPos;

      //! Sampling frequency
      UINT16 _samplingFreq;

      //! Channel mask
      UINT16 _channelMask;

      //! ADC resolution
      UINT16 _ADCResolution;

      //! Trace length
      UINT16 _traceLength;

      //! Version number
      UINT16 _version;

      //! ADC data buffer
      UINT16 _dataADCBuffer[]; // may be splitted up

      //! Message ID
      unsigned short _messageID;

      //! Pre-trigger window
      unsigned short _preTriggerWindow;

      //! Coincedence window
      unsigned short _coincedenceWindow;

      //! Post-trigger window
      unsigned short _postTriggerWindow;

      //! Signal threshold
      std::vector<unsigned short> _signalThresholds;

      //! Noise threshold
      std::vector<unsigned short> _noiseThresholds;

      //! Array with ADC data
      std::vector< std::vector<int> > _adc_data;


     public:

      /*!
        \brief Get the number of channels per station.

        \return nChannels -- Number of channels per station.
      */
      inline UINT16 nChannels () const {return AERA_N_CHANNELS;};

      /*!
        \brief Get the length of the event body.

        \return length -- Length of the event body.
      */
      inline UINT16 getLength () const {return _length;};

      /*!
        \brief Get the event number.

        \return eventNumber -- Number of the event.
      */
      inline UINT16 getEventNumber () const {return _eventNumber;};

      /*!
        \brief Get local station ID.

        \return LS_ID -- Local station ID.
      */
      inline UINT16 getLocalStationID () const {return _LS_ID;};

      /*!
        \brief Get hardware description.

        \return hardware -- Description of the hardware.
      */
      inline std::string getHardware () const {return _hardware;};

      /*!
        \brief Get the header length.

        \return headerlength -- Length of the header.
      */
      inline UINT16 getHeaderLength () const {return _headerLength;};

      /*!
        \brief Get the GPS time in seconds.

        \return seconds -- GPS time in seconds.
      */
      inline unsigned int getSeconds () const {return _seconds;};

      /*!
        \brief Get the nanoseconds part of the GPS time.

        \return nanoseconds -- Nanosecond part of the GPS time.
      */
      inline unsigned int getNanoSeconds () const {return _nanoseconds;};

      /*!
        \brief Get the trigger flag.

        \return triggerFlag -- Trigger flag.
      */
      inline UINT16 getTriggerFlag () const {return _triggerFlag;};

      /*!
        \brief get the trigger position.

        \return triggerPosition -- Trigger position.
      */
      inline UINT16 getTriggerPosition () const {return _triggerPos;};

      /*!
        \brief Get the sampling frequency.

        \return samplingFrequency -- Sampling frequency.
      */
      inline UINT16 getSamplingFrequency () const {return _samplingFreq;};

      /*!
        \brief Get the  channel mask.

        \return channelMask -- Channel mask.
      */
      inline UINT16 getChannelMask () const {return _channelMask;};

      /*!
        \brief Get the ADC resolution

        \return ADCResolution -- ADC resolution.
      */
      inline UINT16 getADCResolution () const {return _ADCResolution;};

      /*!
        \brief Get the trace length.

        \return traceLength -- Trace length.
      */
      inline UINT16 getTraceLength () const {return _traceLength;};

      /*!
        \brief Get the data version of the event.

        \return version -- Data version of the event.
      */
      inline UINT16 getVersion () const {return _version;};

      /*!
        \brief Get the message ID.

        \return messageID -- Message ID.
      */
      inline unsigned short getMessageID () const {return _messageID;};

      /*!
        \brief Get the pre-trigger window.

        \return preTriggerWindow -- pre-trigger window.
      */
      inline unsigned short getPreTriggerWindow () const {return _preTriggerWindow;};

      /*!
        \brief Get the pre-trigger window.

        \return preTriggerWindow -- pre-trigger window.
      */
      inline unsigned short getCoincedenceWindow () const {return _coincedenceWindow;};

      /*!
        \brief Get the pre-trigger window.

        \return preTriggerWindow -- pre-trigger window.
      */
      inline unsigned short getPostTriggerWindow () const {return _postTriggerWindow;};

      /*!
        \brief Get signal thresholds.

        \return signalThresholds -- Vector of signal thresholds.
      */
      inline std::vector<unsigned short> getSignalThresholds () const {return _signalThresholds;};

      /*!
        \brief Get the signal threshold for a specified channel

        \param channelNr -- Channel number.

        \return signalThreshold -- Signal threshold for the specied channel.
      */
      unsigned short getSignalThreshold(const unsigned short channelNr) const;

      /*!
        \brief Get noise thresholds.

        \return noiseThresholds -- Vector of noise thresholds.
      */
      inline std::vector<unsigned short> getNoiseThresholds () const {return _noiseThresholds;};

      /*!
        \brief Get the noise threshold for a specified channel.

        \param channelNr -- Channel number.

        \return noiseThreshold -- Noise threshold for the specified channel.
      */
      unsigned short getNoiseThreshold (const unsigned short channelNr) const;

      /*!
        \brief Get the time series data for a specified channel.

        \param channelNr -- Channel number.

        \return channelData -- time series data for the specified channel.
      */
      std::vector<int> getADCData (const unsigned short channelNr) const;




      // ======================================================================
      //  Methods
      // ======================================================================

     public:

      /*!
        \brief Read local station event information from file.

        \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
      */
      virtual bool read (unsigned short* evt_ptr) = 0;

      /*!
        \brief Get a summary of the local station event information.
      */
      void summary () const;


     protected:

      /*!
        \brief  Extract an ADC data values from the raw ADC memory block.

        \param rawData   -- Raw ADC data.
        \param rawSize   -- Total size of the ADC data.
        \param dataValue -- Location to store the data values.
        \param dataSize  -- Size of the data value storage.
      */
      virtual void getADCDataBlock (const unsigned char* rawData,
                                    const int rawSize,
                                    unsigned short* dataValue,
                                    int* dataSize) = 0;

    }; // Class LocalStation -- end

  } // Namespace Data -- end

} // Namespace AERA -- end

#endif /* AERA_DATA_EVENT_BODY_H */

