/*****************************************************************************
 *                                                                           *
 *  Implementation of the Header class for AERA data                         *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <time.h>

// ________________________________________________________________________
//                                                    Project include files

#include "Timestamp.h"
#include "Header.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

using namespace std;

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ========================================================================
    //
    //  Header
    //
    // ================================================================== Class


    // ========================================================================
    //  Construction / Destruction
    // ========================================================================

    // ________________________________________________________________________
    //                                                                   Header

    Header::Header ()
    {
      init();
    }

    // ________________________________________________________________________
    //                                                                     init

    void Header::init ()
    {
      _headerLength = 0;
      _runNumber = 0;
      _runMode = 0;
      _fileSerialNumber = 0;
      _firstEvent = 0;
      _firstEventTime = "Not defined\n";
      _lastEvent = 0;
      _lastEventTime = "Not defined\n";
    }

    // ________________________________________________________________________
    //                                                                  ~Header

    Header::~Header ()
    {
      destroy();
    }

    // ________________________________________________________________________
    //                                                                  destroy

    void Header::destroy ()
    {

    }


    // ========================================================================
    //  Attributes
    // ========================================================================


    int Header::getAdditionalWord (const int idx) const
    {
      int additionalWord = 0;

      if ((idx >= 0) && (idx < _additionalWords.size())) {
        additionalWord = _additionalWords[idx];
      } else {
        cerr << "Incorrect index value" << endl;
      }

      return additionalWord;
    }


    // ========================================================================
    //  Methods
    // ========================================================================

    void Header::summary() const
    {
      cout << "------------------------------------------------------------" << endl;
      cout << "  Summary of the data header information" << endl;
      cout << "------------------------------------------------------------" << endl;
      cout << "  Run number          : " << getRunNumber() << endl;
      cout << "  Run mode            : " << getRunMode() << endl;
      cout << "  File serial number  : " << getFileSerialNumber() << endl;
      cout << "  First event number  : " << getFirstEvent() << endl;
      cout << "  Time of first event : " << getFirstEventTime();// << endl;
      cout << "  Last event number   : " << getLastEvent() << endl;
      cout << "  Time of last event  : " << getLastEventTime();// << endl;
      if (_additionalWords.size() > 0) {
        cout << "  Additional words" << endl;
        for (int idx=0; idx < _additionalWords.size(); ++idx) {
          cout << "    Word " << idx << "           : " << getAdditionalWord(idx) << endl;
        }
      }
      cout << "------------------------------------------------------------" << endl;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


