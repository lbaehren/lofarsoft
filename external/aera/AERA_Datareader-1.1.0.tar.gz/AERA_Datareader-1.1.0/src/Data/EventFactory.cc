/*****************************************************************************
 *                                                                           *
 *  EventFactory class for AERA event data                                   *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files


// ________________________________________________________________________
//                                                    Project include files

#include "EventFactory.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  namespace Data { // Namespace Data -- begin

    // ______________________________________________________________________
    //                                                                 create

    Data::Event* EventFactory::create (const int dataformatversion) {

      switch (dataformatversion) {
        case 1:
          return new Data::Event_v1();
          break;
        case 2:
          return new Data::Event_v2();
          break;
      };

      return NULL;
    }

  } // Namespace Data -- end

} // Namespace AERA -- end


