/*****************************************************************************
 *                                                                           *
 *  Implementation of the Timestamp functionality for AERA data              *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <string>
#include <time.h>

// ________________________________________________________________________
//                                                    Project include files

#include "Timestamp.h"

// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Implementation
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  std::string TimeString(const struct tm* timestamp)
  {
    std::string timestring = "Illegal timestamp\n";
    long int year = timestamp->tm_year;

    // Only accept timestamps between 1900 and 2100
    if ((year > 0) && (year < 200)) {
      timestring = asctime(timestamp);
    }

    return timestring;
  }

} // Namespace AERA -- end

