/*****************************************************************************
 *                                                                           *
 *  Header file for the Timestamp functionality for AERA data                *
 *                                                                           *
 *  Copyright (c) 2011                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_TIMESTAMP_H
#define AERA_DATA_TIMESTAMP_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <string>
#include <time.h>

// ________________________________________________________________________
//                                                    Project include files


// ________________________________________________________________________
//                                                      Other include files



// ========================================================================
//
//  Header definition
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  /*!
    \brief Return a human readable string containing a timestamp

    \param timestamp -- Timestamp of tm data type

    \return timestring -- Human readable version of the time.
  */
  std::string TimeString(const struct tm* timestamp);

} // Namespace AERA -- end

#endif /* AERA_DATA_TIMESTAMP_H */

