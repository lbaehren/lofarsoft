/*****************************************************************************
 *                                                                           *
 *  Header of AERA data file reader                                          *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

#ifndef AERA_DATA_READER_H
#define AERA_DATA_READER_H

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                     System include files

#include <string>
#include <vector>

// ________________________________________________________________________
//                                                    Project include files

#include "Datareader_config.h"
#include "Data/BaseDataContainer.h"
#include "Data/Header.h"
#include "Data/Event.h"

// ________________________________________________________________________
//                                                      Other include files


// ========================================================================
//
//  Package information
//
// ========================================================================



// ========================================================================
//
//  Header definition
//
// ========================================================================

namespace AERA { // Namespace AERA -- begin

  // ========================================================================
  //
  //  Datareader
  //
  // ================================================================== Class

  /*!
    \class Datareader

    \brief Data reader for AERA data files

    \author Martin van den Akker
  */
  class Datareader { // Class Datareader -- begin

    // ======================================================================
    //  Construction / Destruction
    // ======================================================================

   public:

    /*!
      \brief Default constructor
    */
    Datareader ();

    /*!
      \brief Constructor

      \param dataformatversion  -- Version of the data format.
    */
    Datareader (const int dataformatversion);

    /*!
      \brief Constructor

      \param dataformatversion  -- Version of the data format.
      \param filename -- Name of the data file to be opened.
    */
    Datareader (const int dataformatversion, const std::string filename);

    /*!
      \brief Destructor
    */
    virtual ~Datareader ();


   private:

    /*!
      \brief Attribute initialisation
    */
    void init ();

    /*!
      \brief Unconditional destruction
    */
    void destroy ();


    // ======================================================================
    //  Attributes
    // ======================================================================

   private:

    //! File pointer
    FILE* _file_ptr;

    //! File name of the data file
    std::string _filename;

    //! Version of the datafile format
    int _dataformatversion;

    //! Data header
    Data::Header* _header_ptr;

    //! Data events
    std::vector<Data::Event*> _events;

    //! Iterator pointing to the current event
    std::vector<Data::Event*>::iterator _currentEvent_it;

   public:

    /*!
      \brief Get the file name of the data file.

      \return filename -- File name of the data file.
    */
    inline std::string getFileName() const {return _filename;};

    /*!
      \brief Set the file name of the data file.
    */
    inline void setFileName(const std::string filename) {_filename = filename;};

    /*!
      \brief Get the version number of the data format.

      \return dataformatversion -- Version of the data format.
    */
    inline int getDataFormatVersion() const {return _dataformatversion;};

    /*!
      \brief Set the version number of the data format.
    */
    inline void setDataFormatVersion(const int dataformatversion) {_dataformatversion = dataformatversion;};

    /*!
      \brief Get the number of events.

      \return nEvents -- Number of events.
    */
    inline int nEvents () const {return _events.size();};

    // ======================================================================
    //  Methods
    // ======================================================================

   public:

    /*!
      \brief Open an AERA data file

      \param filename -- Name of the file to open.

      \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
    */
    bool open(const std::string filename);

    /*!
      \brief Find the version of the data format for a specific datafile.

      \param filename -- Name of the file to find the dataformat for.

      \return dataformatversion -- Version of the data format for the supplied datafile.
    */
    int getDataFormatVersion(const std::string filename);

    /*!
      \brief Close the AERA data file

      \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
    */
    bool close();

    /*!
      \brief Read data file information from file.

      \return status -- Status of the operation; returns <tt>false</tt> in case an error occurred.
    */
    bool read();

    /*!
      \brief Get a pointer to the file header

      \return headerPtr -- Pointer to the file header.
    */
    inline Data::Header* header() const {return _header_ptr;};

    /*!
      \brief Get a pointer to the current event.

      \return currentEventPtr -- Pointer to the current event.
    */
    Data::Event* currentEvent () const;

    /*!
      \brief Check if current event is first event

      \return isFirstEvent -- Return true if event is first event, flase otherwise.
    */
    bool isFirstEvent () const;

    /*!
      \brief Set event pointer to first event.

      \return firstEvent -- Pointer to previous event.
    */
    Data::Event* firstEvent ();

    /*!
      \brief Set event pointer to previous event.

      \return prevEvent -- Pointer to previous event.
    */
    Data::Event* prevEvent ();

    /*!
      \brief Set event pointer to next event.

      \return nextEvent -- Pointer to next event.
    */
    Data::Event* nextEvent ();

    /*!
      \brief Check if current event is last event

      \return isLastEvent -- Return true if event is last event, flase otherwise.
    */
    bool isLastEvent () const;

    /*!
      \brief Set event pointer to last event.

      \return lastEvent -- Pointer to last event.
    */
    Data::Event* lastEvent ();

    /*!
      \brief Get a summary of the opened file.
    */
    void summary() const;


   private:


  }; // Class Datareader -- end


} // Namespace AERA -- end


#endif /* AERA_DATA_READER_H */

