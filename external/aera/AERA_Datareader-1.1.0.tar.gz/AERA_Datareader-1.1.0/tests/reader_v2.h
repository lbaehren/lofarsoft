#define INTSIZE   4 //size of an integer
#define SHORTSIZE 2 //size of a short

#define DECPRINT  1 //print ADC values in decimal 

// GPS epoch start in UNIX time
#define GPS_EPOCH 315957600

// Current number of leap seconds since the GPS epoch
#define LEAP_SEC 15

// Earliest possible UNIX time of AERA data (otherwise timestamp is GPS)
#define AERA_START_UNIX 1280000000

// 2/2011: Event version added to AERA event definition 
#define USE_EVENT_VERSION    1

/* First define the header words */
#define FILE_HDR_LENGTH          0
#define FILE_HDR_RUNNR           1
#define FILE_HDR_RUN_MODE        2 
#define FILE_HDR_SERIAL          3
#define FILE_HDR_FIRST_EVENT     4
#define FILE_HDR_FIRST_EVENT_SEC 5
#define FILE_HDR_LAST_EVENT      6
#define FILE_HDR_LAST_EVENT_SEC  7
#define FILE_HDR_ADDITIONAL      8 //start of additional info to be defined

#define EVENT_HDR_LENGTH          0
#define EVENT_HDR_RUNNR           2
#define EVENT_HDR_EVENTNR         4 
#define EVENT_HDR_T3EVENTNR       6
#define EVENT_HDR_FIRST_LS        8
#define EVENT_HDR_EVENT_SEC      10
#define EVENT_HDR_EVENT_NSEC     12
#define EVENT_HDR_EVENT_TYPE     14
#ifdef USE_EVENT_VERSION
#define EVENT_HDR_EVENT_VERS     15
#endif
#define EVENT_HDR_AD1            16 //start of additional info to be defined
#define EVENT_HDR_AD2            18 //                    info to be defined
#define EVENT_HDR_AD3            20 //                    info to be defined
#define EVENT_LS                 22

/* Next part copied from scope.h */
#define MSG_ID          1
#define MSG_LEN         2    // Only for FADC->PC messages
#define MSG_DATA_CH     4
#define MSG_DATA_TRIG   5
#define MSG_DATA_PRE    6
#define MSG_DATA_COINC  8
#define MSG_DATA_POST  10
#define MSG_DATA_TIME  12
#define MSG_DATA_CTD   19
#define MSG_DATA_STHRES1 23
#define MSG_DATA_STHRES2 25
#define MSG_DATA_STHRES3 27
#define MSG_DATA_STHRES4 29
#define MSG_DATA_NTHRES1 31
#define MSG_DATA_NTHRES2 33
#define MSG_DATA_NTHRES3 35
#define MSG_DATA_NTHRES4 37
#define MSG_DATA_ADC   39

#define MSG_OFFSET 1 /* I did not copy the first word! */

#define UINT16 unsigned short

typedef struct{
  UINT16 length;
  UINT16 event_nr;
  UINT16 LS_id;
  UINT16 header_length;
  unsigned int GPSseconds;
  unsigned int GPSnanoseconds;
  UINT16 trigger_flag;
  UINT16 trigger_pos;
  UINT16 sampling_freq;
  UINT16 channel_mask;
  UINT16 ADC_resolution;
  UINT16 tracelength;
#ifdef USE_EVENT_VERSION
  UINT16 version;
#endif
  UINT16 info_ADCbuffer[];
}EVENTBODY;

#define LS_NL 1
#define LS_FR 1
#define LS_GE 1
char *hardware[3]={"Dutch","French","German"};
