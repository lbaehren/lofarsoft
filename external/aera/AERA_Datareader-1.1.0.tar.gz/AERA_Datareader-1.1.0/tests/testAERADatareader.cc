/*****************************************************************************
 *                                                                           *
 *  Test program for AERA Data Reader                                        *
 *                                                                           *
 *  Copyright (c) 2010                                                       *
 *                                                                           *
 *  Martin van den Akker <martinva@astro.ru.nl>                              *
 *                                                                           *
 *  This library is free software: you can redistribute it and/or modify it  *
 *  under the terms of the GNU General Public License as published by the    *
 *  Free Software Foundation, either version 3 of the License, or (at your   *
 *  option) any later version.                                               *
 *                                                                           *
 *  This library is distributed in the hope that it will be useful, but      *
 *  WITHOUT ANY WARRANTY; without even the implied warranty of               *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU        *
 *  General Public License for more details.                                 *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License along  *
 *  with this library. If not, see <http://www.gnu.org/licenses/>.           *
 *                                                                           *
 *****************************************************************************/

// ========================================================================
//
//  Included header files
//
// ========================================================================

// ________________________________________________________________________
//                                                          System includes

#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>

// ________________________________________________________________________
//                                                         Project includes


// ________________________________________________________________________
//                                                           Local includes

#include "../src/Datareader.h"


// ========================================================================
//
//  Main
//
// ========================================================================

using namespace std;
using namespace AERA;

/*!
  \brief Testing of version 1 of the data format.
*/
int testDataFormat_v1(string filename) {
  int result = 0;

  bool status = false;
  unsigned int nofFailedTests = 0;

  cout << "testReadDataFile version 1" << endl;

  // TODO: Add implementation

  return result;
}

int testDataFormat_v2(string filename) {
  int result = 0;

  bool status = false;
  unsigned int nofFailedTests = 0;

  cout << "testReadDataFile version 2" << endl;

  // TODO: Add implementation

  return result;
}

/*!
  \brief Main routine

  \return nofFailedTests  --  The number of failed tests.
 */
int main(int argc, char **argv)
{
  bool status = false;
  int dataversion = -1;
  string filename = "";
  unsigned int nofFailedTests = 0;


  cout << "testAeraDataReader" << endl;

  Datareader dr;

  if (argc < 3) {
    dataversion = -1;
    filename = "../../data/ad001037.f0001";
  } else {
    dataversion = atoi(argv[2]);
    filename = argv[1];
  }

  // ___________________________________________________________________
  //                                                     Opening of file
  status = false;

  cout << "Opening of file: ";

  status = dr.open(filename);

  if (false == status) {
    cout << "Failed to open file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  // ___________________________________________________________________
  //                                                   Reopening of file
  status  = false;

  cout << "Reopening of file: ";

  status = dr.open(filename);

  if (false == status) {
    cout << "Failed to reopen file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  // ___________________________________________________________________
  //                                  Getting a summary of the data file
  status = false;

  cout << "Get a summary of the data file" << endl;

  try {
    cout << "- Read the data first" << endl;
    status = dr.read();
    cout << "- Generating the summary" << endl;
    dr.summary();
  } catch (bool status) {
    ++nofFailedTests;
  }


  // ___________________________________________________________________
  //                                                     Closing of file
  status = false;

  cout << "Closing of file: ";

  status = dr.close();

  if (false == status) {
    cout << "Failed to close file" << endl;
    ++nofFailedTests;
  } else {
    cout << "OK" << endl;
  }

  cout << "Number of failed tests: " << nofFailedTests << endl;
  return nofFailedTests;
}
