************
Numpy basics
************

.. note::

   XXX: there is overlap between this text extracted from ``numpy.doc``
   and "Guide to Numpy" chapter 2. Needs combining?

.. toctree::
   :maxdepth: 2

   basics.types
   basics.creation
   basics.io
   basics.indexing
   basics.broadcasting
   basics.byteswapping
   basics.rec
   basics.subclassing
