********
Glossary
********

.. toctree::

.. glossary::

   .. automodule:: numpy.doc.glossary

Jargon
------

.. automodule:: numpy.doc.jargon
