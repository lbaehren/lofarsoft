#!/usr/bin/env python
#
#	x17c.c

# The C demo doesn't work yet, and even if it did it probably could
# not be converted to pure Python since it seems to require the Tcl/Tk
# driver.
