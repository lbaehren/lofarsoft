#!/usr/bin/env python
#
#	x15c.c
#
#	Shade plot demo.
#
#	Maurice LeBrun
#	IFS, University of Texas at Austin
#	31 Aug 1993

# This demo could not be converted to Python because it uses a part of
# the plplot API that has not yet been implemented in Python.
