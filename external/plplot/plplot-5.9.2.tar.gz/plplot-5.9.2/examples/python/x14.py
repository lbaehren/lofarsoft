#!/usr/bin/env python
#
#	x14c.c
#
#	Demo of multiple stream/window capability (requires Tk or Tcl-DP).
#
#	Maurice LeBrun
#	IFS, University of Texas at Austin

# This demo could not be converted to Python because it uses a part of
# the plplot API that has not yet been implemented in Python.
