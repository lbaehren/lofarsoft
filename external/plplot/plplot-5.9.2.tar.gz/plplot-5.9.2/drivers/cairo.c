/* June 2, 2007

   Graphics drivers that are based on the Cairo / Pango Libraries.
    
   Copyright (C) 2008 Hazen Babcock

   This file is part of PLplot.

   PLplot is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Library Public License as published
   by the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   PLplot is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Library General Public License for more details.

   You should have received a copy of the GNU Library General Public License
   along with PLplot; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
   	
*/

/*---------------------------------------------------------------------
  Header files 
  ---------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <math.h>

#include <cairo.h>
#include <pango/pangocairo.h>

/* PLplot header files (must occur before driver-dependent includes) */

#include "plplotP.h"
#include "drivers.h"

/* Driver-dependent includes */
#if defined(PLD_xcairo)
#include <cairo-xlib.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h> 
#include <X11/cursorfont.h>
#include <X11/keysym.h>
#endif
#if defined(PLD_pdfcairo)
#include <cairo-pdf.h>
#endif
#if defined(PLD_pscairo)
#include <cairo-ps.h>
#endif
#if defined(PLD_svgcairo)
#include <cairo-svg.h>
#endif


/*---------------------------------------------------------------------
  Constants & global (to this file) variables 
 ---------------------------------------------------------------------*/

#define DPI 72
#define PLCAIRO_DEFAULT_X 720
#define PLCAIRO_DEFAULT_Y 540

#define MAX_STRING_LEN 500
#define MAX_MARKUP_LEN MAX_STRING_LEN * 10

static int text_clipping;
static int text_anti_aliasing;
static int graphics_anti_aliasing;
static int external_drawable;
static DrvOpt cairo_options[] = {{"text_clipping", DRV_INT, &text_clipping, "Use text clipping (text_clipping=0|1)"},
				 {"text_anti_aliasing", DRV_INT, &text_anti_aliasing, "Set desired text anti-aliasing (text_anti_aliasing=0|1|2|3). The numbers are in the same order as the cairo_antialias_t enumeration documented at http://cairographics.org/manual/cairo-cairo-t.html#cairo-antialias-t)"},
				 {"graphics_anti_aliasing", DRV_INT, &graphics_anti_aliasing, "Set desired graphics anti-aliasing (graphics_anti_aliasing=0|1|2|3). The numbers are in the same order as the cairo_antialias_t enumeration documented at http://cairographics.org/manual/cairo-cairo-t.html#cairo-antialias-t"},
				 {"external_drawable", DRV_INT, &external_drawable, "Plot to external X drawable"},
                                 {NULL, DRV_INT, NULL, NULL}};

typedef struct {
  cairo_surface_t *cairoSurface;
  cairo_t *cairoContext;
  short text_clipping;
  short text_anti_aliasing;
  short graphics_anti_aliasing;
  PLFLT downscale;
#if defined(PLD_xcairo)
  short exit_event_loop;
  Display *XDisplay;
  Window XWindow;
  unsigned int xdrawable_mode;
#endif
#if defined(PLD_memcairo)
  unsigned char *memory;
  unsigned char *cairo_format_memory;
  char bigendian;
#endif
} PLCairo;

PLDLLIMPEXP_DRIVER const char* plD_DEVICE_INFO_cairo = 
#if defined(PLD_xcairo)
  "xcairo:Cairo X Windows Driver:1:cairo:59:xcairo\n"
#endif
#if defined(PLD_pdfcairo)
  "pdfcairo:Cairo PDF Driver:0:cairo:60:pdfcairo\n"
#endif
#if defined(PLD_pscairo)
  "pscairo:Cairo PS Driver:0:cairo:61:pscairo\n"
#endif
#if defined(PLD_svgcairo)
  "svgcairo:Cairo SVG Driver:0:cairo:62:svgcairo\n"
#endif
#if defined(PLD_pngcairo)
  "pngcairo:Cairo PNG Driver:0:cairo:63:pngcairo\n"
#endif
#if defined(PLD_memcairo)
  "memcairo:Cairo Memory Driver:0:cairo:64:memcairo\n"
#endif
#if defined(PLD_extcairo)
  "extcairo:Cairo External Context Driver:0:cairo:65:extcairo\n"
#endif
;

/* 
 * Structure for passing external drawables to xcairo devices via
 * the PLESC_DEVINIT escape function.
 */
#if defined(PLD_xcairo)
typedef struct {
  Display *display;
  Drawable drawable;
} PLXcairoDrawableInfo;
#endif

/*---------------------------------------------------------------------
  Font style and weight lookup tables (copied
  from the psttf driver).
  ---------------------------------------------------------------------*/

#define NPANGOLOOKUP 5

const char *defaultFamilyLookup[NPANGOLOOKUP] = {
  "sans",
  "serif",
  "monospace",
  "sans,serif",
  "sans,serif"
};

const char *envFamilyLookup[NPANGOLOOKUP] = {
  "PLPLOT_FREETYPE_SANS_FAMILY",
  "PLPLOT_FREETYPE_SERIF_FAMILY",
  "PLPLOT_FREETYPE_MONO_FAMILY",
  "PLPLOT_FREETYPE_SCRIPT_FAMILY",
  "PLPLOT_FREETYPE_SYMBOL_FAMILY"
};

char familyLookup[NPANGOLOOKUP][1024];

const char *weightLookup[2] = {
  "normal",
  "bold"
};

const char *styleLookup[3] = {
  "normal",
  "italic",
  "oblique"
};


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is common to all the Cairo Drivers
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

/*---------------------------------------------------------------------
  function declarations
  ---------------------------------------------------------------------*/

/* General */

PLCairo *stream_and_font_setup(PLStream *, int);
cairo_status_t write_to_stream(void *, unsigned char *, unsigned int);

/* String processing */

static void proc_str(PLStream *, EscText *);
static char *ucs4_to_pango_markup_format(PLUNICODE *, int, float);
static void open_span_tag(char *, PLUNICODE, float, int);
static void close_span_tag(char *, int);

/* Graphics */

static void set_current_context(PLStream *);
static void poly_line(PLStream *, short *, short *, PLINT);
static void filled_polygon(PLStream *pls, short *xa, short *ya, PLINT npts);
static void rotate_cairo_surface(PLStream *, float, float, float, float, float, float);

/* PLplot interface functions */

/* general */
void plD_bop_cairo               (PLStream *);
void plD_eop_cairo               (PLStream *);
void plD_state_cairo             (PLStream *, PLINT);
void plD_esc_cairo               (PLStream *, PLINT, void *);
void plD_tidy_cairo              (PLStream *);
void plD_line_cairo              (PLStream *, short, short, short, short);
void plD_polyline_cairo          (PLStream *, short *, short *, PLINT);

/*----------------------------------------------------------------------
  plD_bop_cairo()
  
  Set up for the next page.
  ----------------------------------------------------------------------*/

void plD_bop_cairo(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  /* Some Cairo devices support delayed device setup (eg: xcairo with
     external drawable and extcairo with an external context). */
  if (aStream->cairoContext == NULL)
    return;

  /* Fill in the window with the background color. */
  cairo_rectangle(aStream->cairoContext, 0.0, 0.0, pls->xlength, pls->ylength);
  cairo_set_source_rgb(aStream->cairoContext,
		       (double)pls->cmap0[0].r/255.0,
		       (double)pls->cmap0[0].g/255.0,
		       (double)pls->cmap0[0].b/255.0);
  cairo_fill(aStream->cairoContext);  
}

/*---------------------------------------------------------------------
  plD_line_cairo()
  
  Draw a line in the current color from (x1,y1) to (x2,y2).
  ----------------------------------------------------------------------*/

void plD_line_cairo(PLStream *pls, short x1a, short y1a, short x2a, short y2a)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  set_current_context(pls);

  cairo_move_to(aStream->cairoContext, aStream->downscale * (double) x1a, aStream->downscale * (double) y1a);
  cairo_line_to(aStream->cairoContext, aStream->downscale * (double) x2a, aStream->downscale * (double) y2a);
  cairo_stroke(aStream->cairoContext);
}

/*---------------------------------------------------------------------
  plD_polyline_cairo()
  
  Draw a polyline in the current color.
  ---------------------------------------------------------------------*/

void plD_polyline_cairo(PLStream *pls, short *xa, short *ya, PLINT npts)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  poly_line(pls, xa, ya, npts);
  cairo_stroke(aStream->cairoContext);
}

/*---------------------------------------------------------------------
  plD_eop_cairo()
  
  Generic end of page.
  ---------------------------------------------------------------------*/

void plD_eop_cairo(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;
  cairo_show_page(aStream->cairoContext);
}

/*---------------------------------------------------------------------
  plD_tidy_cairo()
  
  General: Close graphics file or otherwise clean up.
  ---------------------------------------------------------------------*/

void plD_tidy_cairo(PLStream *pls)
{
  PLCairo *aStream;
  
  aStream = (PLCairo *)pls->dev;

  /* Free the cairo context and surface. */
  cairo_destroy(aStream->cairoContext);
  cairo_surface_destroy(aStream->cairoSurface);

  if (pls->OutFile)
    fclose(pls->OutFile);
}

/*---------------------------------------------------------------------
  plD_state_cairo()
  
  Handle change in PLStream state (color, pen width, fill attribute, etc).
  
  Nothing is done here because these attributes are acquired from 
  PLStream for each element that is drawn.
  ---------------------------------------------------------------------*/

void plD_state_cairo(PLStream *pls, PLINT op)
{
}

/*---------------------------------------------------------------------
  plD_esc_cairo()
  
  Generic escape function.
  ---------------------------------------------------------------------*/

void plD_esc_cairo(PLStream *pls, PLINT op, void *ptr)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  switch(op)
    {
    case PLESC_FILL:     /* filled polygon */
      filled_polygon(pls, pls->dev_x, pls->dev_y, pls->dev_npts);
      break;
    case PLESC_HAS_TEXT: /* render rext */
      proc_str(pls, (EscText *) ptr);
      break;
    }
}

/*---------------------------------------------------------------------
  proc_str()
  
  Processes strings for display.
  ---------------------------------------------------------------------*/

void proc_str(PLStream *pls, EscText *args)
{
  int i;
  float fontSize;
  int textXExtent, textYExtent;
  char *textWithPangoMarkup;
  PLFLT rotation, shear, stride, cos_rot, sin_rot, cos_shear, sin_shear;
  cairo_matrix_t *cairoTransformMatrix;
  cairo_font_options_t *cairoFontOptions;
  PangoContext *context;
  PangoLayout *layout;
  PangoFontDescription *fontDescription;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  set_current_context(pls);

  /* Check that we got unicode, warning message and return if not */
  if(args->unicode_array_len == 0){
    printf("Non unicode string passed to a cairo driver, ignoring\n");
    return;
  }
	
  /* Check that unicode string isn't longer then the max we allow */
  if(args->unicode_array_len >= MAX_STRING_LEN){
    printf("Sorry, the cairo drivers only handles strings of length < %d\n", MAX_STRING_LEN);
    return;
  }

  /* Calculate the font size (in pixels) */
  fontSize = pls->chrht * DPI/25.4;

  /* Convert the escape characters into the appropriate Pango markup */
  textWithPangoMarkup = ucs4_to_pango_markup_format(args->unicode_array, args->unicode_array_len, fontSize);

  /* Create the Pango text layout so we can figure out how big it is */
  layout = pango_cairo_create_layout(aStream->cairoContext);
  pango_layout_set_markup(layout, textWithPangoMarkup, -1);
  pango_layout_get_pixel_size(layout, &textXExtent, &textYExtent);

  /* Set font aliasing */
  context = pango_layout_get_context(layout);
  cairoFontOptions = cairo_font_options_create();
  cairo_font_options_set_antialias(cairoFontOptions, aStream->text_anti_aliasing);
  pango_cairo_context_set_font_options(context, cairoFontOptions);
  pango_layout_context_changed(layout);
  cairo_font_options_destroy(cairoFontOptions);

  /* Save current transform matrix & clipping region */
  cairo_save(aStream->cairoContext);

  /* Set up the clipping region if we are doing text clipping */
  if(aStream->text_clipping){
    cairo_rectangle(aStream->cairoContext, aStream->downscale * pls->clpxmi, aStream->downscale * pls->clpymi, aStream->downscale * (pls->clpxma - pls->clpxmi), aStream->downscale * (pls->clpyma - pls->clpymi));
    cairo_clip(aStream->cairoContext);
  }

  /* Move to the string reference point */
  cairo_move_to(aStream->cairoContext, aStream->downscale * (double) args->x, aStream->downscale * (double) args->y);

  /* Invert the coordinate system so that the text is drawn right side up */
  cairoTransformMatrix = (cairo_matrix_t *) malloc (sizeof(cairo_matrix_t));
  cairo_matrix_init(cairoTransformMatrix, 1.0, 0.0, 0.0, -1.0, 0.0, 0.0);
  cairo_transform(aStream->cairoContext, cairoTransformMatrix);

  /* Extract rotation angle and shear from the PLplot tranformation matrix.
     Compute sines and cosines of the angles as an optimization. */
  plRotationShear(args->xform, &rotation, &shear, &stride);
  rotation -= pls->diorot * 3.14159 / 2.0;
  cos_rot = cos(rotation);
  sin_rot = sin(rotation);
  cos_shear = cos(shear);
  sin_shear = sin(shear);

  /* Apply the transform matrix */
  cairo_matrix_init(cairoTransformMatrix,             
		    cos_rot * stride,
		    -sin_rot * stride,
		    cos_rot * sin_shear + sin_rot * cos_shear,
		    -sin_rot * sin_shear + cos_rot * cos_shear,
		    0,0);
  cairo_transform(aStream->cairoContext, cairoTransformMatrix);
  free(cairoTransformMatrix);
  
  /* Move to the text starting point */
  cairo_rel_move_to(aStream->cairoContext, 
		    (double)(-1.0 * args->just * (double)textXExtent), 
		    (double)(-0.5 * textYExtent));

  /* Render the text */
  pango_cairo_show_layout(aStream->cairoContext, layout);

  /* Restore the transform matrix to its state prior to the text transform. */
  cairo_restore(aStream->cairoContext);
  
  /* Free the layout object and the markup string. */
  g_object_unref(layout);
  free(textWithPangoMarkup);
}

/*---------------------------------------------------------------------
  ucs4_to_pango_markup_format()
  
  Converts the plplot string (in ucs4) to a utf8 string that includes
  pango markup.
  
  http://developer.gnome.org/doc/API/2.0/pango/PangoMarkupFormat.html
  ---------------------------------------------------------------------*/

char *ucs4_to_pango_markup_format(PLUNICODE *ucs4, int ucs4Len, float fontSize)
{
  char plplotEsc;
  int i;
  int upDown = 0;
  PLUNICODE fci;
  char utf8[5];
  char *pangoMarkupString;

  /* Will this be big enough? We might have lots of markup. */
  pangoMarkupString = (char *) malloc (sizeof(char) * MAX_MARKUP_LEN);
  for(i = 0; i < MAX_MARKUP_LEN; i++){
    pangoMarkupString[i] = 0;
  }

  /* Get PLplot escape character */
  plgesc(&plplotEsc);

  /* Get the curent font and open the first span tag */
  plgfci(&fci);
  open_span_tag(pangoMarkupString, fci, fontSize, 0);

  /* Parse the string to generate the tags */
  i = 0;
  while (i < ucs4Len){
    /* Try to avoid going off the end of the string */
    if(strlen(pangoMarkupString) > (MAX_MARKUP_LEN - 50)){
      continue;
    }
    if (ucs4[i] < PL_FCI_MARK){	/* not a font change */
      if (ucs4[i] != (PLUNICODE)plplotEsc) {  /* a character to display */
	/* we have to handle "<", ">" and "&" separately since they throw off the XML */
	switch(ucs4[i])
	  {
	  case 38:
	    strcat(pangoMarkupString, "&#38;");
	    break;
	  case 60:
	    strcat(pangoMarkupString, "&#60;");
	    break;
	  case 62:
	    strcat(pangoMarkupString, "&#62;");
	    break;
	  default:
	    ucs4_to_utf8(ucs4[i],utf8);
	    strcat(pangoMarkupString, utf8);
	    break;
	  }
	i++;
	continue;
      }
      i++;
      if (ucs4[i] == (PLUNICODE)plplotEsc){   /* a escape character to display */
	ucs4_to_utf8(ucs4[i],utf8);
	strcat(pangoMarkupString, utf8);
	i++;
	continue;
      }
      else {
	if(ucs4[i] == (PLUNICODE)'u'){	/* Superscript */
	  if(upDown < 0){
	    strcat(pangoMarkupString, "</sub>");
	  } else {
	    strcat(pangoMarkupString, "<sup>");
	  }
	  upDown++;
	}
	if(ucs4[i] == (PLUNICODE)'d'){	/* Subscript */
	  if(upDown > 0){
	    strcat(pangoMarkupString, "</sup>");
	  } else {
	    strcat(pangoMarkupString, "<sub>");
	  }
	  upDown--;
	}
	i++;
      }
    }
    else { /* a font change */
      close_span_tag(pangoMarkupString, upDown);
      open_span_tag(pangoMarkupString, ucs4[i], fontSize, upDown);
      i++;
    }
  }

  /* Close the last span tag. */
  close_span_tag(pangoMarkupString, upDown);

  /* printf("%s\n", pangoMarkupString); */

  return pangoMarkupString;
}

/*---------------------------------------------------------------------
  open_span_tag
  
  1. Opens a span tag with the appropriate font description given the
     current fci.
  2. Add the appropriate number of <sub> or <sup> tags to bring us
     back to our current sub/super-script level.
  ---------------------------------------------------------------------*/

void open_span_tag(char *pangoMarkupString, PLUNICODE fci, float fontSize, int upDown)
{
  int i;
  unsigned char fontFamily, fontStyle, fontWeight;
  char openTag[200];

  /* Generate the font info for the open tag & concatenate this
     onto the markup string. */
  plP_fci2hex(fci, &fontFamily, PL_FCI_FAMILY);
  plP_fci2hex(fci, &fontStyle, PL_FCI_STYLE);
  plP_fci2hex(fci, &fontWeight, PL_FCI_WEIGHT);
  sprintf(openTag, "<span font_desc=\"%s %.2f\" ", familyLookup[fontFamily], fontSize);
  strcat(pangoMarkupString, openTag);

  sprintf(openTag, "style=\"%s\" ", styleLookup[fontStyle]);
  strcat(pangoMarkupString, openTag);

  sprintf(openTag, "weight=\"%s\">", weightLookup[fontWeight]);
  strcat(pangoMarkupString, openTag);

  /* Move to the right sub/super-script level */
  if(upDown > 0){
    while(upDown > 0){
      strcat(pangoMarkupString, "<sup>");
      upDown--;
    }
  }
  if(upDown < 0){
    while(upDown < 0){
      strcat(pangoMarkupString, "<sub>");
      upDown++;
    }
  }
}

/*---------------------------------------------------------------------
  close_span_tag
  
  Close a span tag & brings us down to zero sub/super-script level.
  ---------------------------------------------------------------------*/

void close_span_tag(char *pangoMarkupString, int upDown)
{
  if(upDown > 0){
    while(upDown > 0){
      strcat(pangoMarkupString, "</sup>");
      upDown--;
    }
  }
  if(upDown < 0){
    while(upDown < 0){
      strcat(pangoMarkupString, "</sub>");
      upDown++;
    }
  }

  strcat(pangoMarkupString, "</span>");
}

/*---------------------------------------------------------------------
  write_to_stream()
  
  Writes data to a open file stream. This function is passed to the
  Cairo file IO devices.
  ---------------------------------------------------------------------*/

cairo_status_t write_to_stream(void *filePointer, unsigned char *data, unsigned int length)
{
  int bytes_written;

  bytes_written = fwrite(data, 1, length, (FILE*) filePointer);
  if(bytes_written == length){
    return CAIRO_STATUS_SUCCESS;
  }
  else{
    return CAIRO_STATUS_WRITE_ERROR;
  }
}

/*---------------------------------------------------------------------
  stream_and_font_setup()
  
  Initializes the PLStream structure for the cairo devices.
  Initializes the font lookup table.
  Checks for cairo specific user options.
  Returns a new PLCairo structure.
  ---------------------------------------------------------------------*/

PLCairo *stream_and_font_setup(PLStream *pls, int interactive)
{
  int i;
  char *a;
  PLCairo *aStream;
  PLFLT downscale;
  downscale = 0.0;

  /* Stream setup */
  pls->termin = interactive; /* Interactive device */
  pls->dev_flush = 1;        /* Handles flushes */
  pls->color = 1;            /* Supports color */
  pls->dev_text = 1;         /* Handles text */
  pls->dev_unicode = 1;      /* Wants unicode text */
  pls->page = 0;
  pls->dev_fill0 = 1;        /* Supports hardware solid fills */
  pls->plbuf_write = 1;      /* Activate plot buffer */
  
  
  if (pls->xlength <= 0 || pls->ylength <= 0){
    pls->xlength = PLCAIRO_DEFAULT_X;
    pls->ylength = PLCAIRO_DEFAULT_Y;
  }
  /* Calculate ratio of (smaller) external coordinates used for cairo
     devices to (larger) internal PLplot coordinates. */
  if (pls->xlength > pls->ylength)
    downscale = (PLFLT)pls->xlength/(PLFLT)(PIXELS_X-1);
  else
    downscale = (PLFLT)pls->ylength/(PLFLT)PIXELS_Y;
  plP_setphy((PLINT) 0, (PLINT) (pls->xlength / downscale), (PLINT) 0, (PLINT) (pls->ylength / downscale));
  plP_setpxl(DPI/25.4/downscale, DPI/25.4/downscale);

  /* Initialize font table with either enviroment variables or defaults.
     This was copied from the psttf driver. */
  for(i=0;i<NPANGOLOOKUP;i++){
    if((a = getenv(envFamilyLookup[i])) != NULL){
      strcpy(familyLookup[i],a);
    }
    else {
      strcpy(familyLookup[i],defaultFamilyLookup[i]);
    }
  }

  /* Allocate a cairo stream structure */
  aStream = malloc(sizeof(PLCairo));
#if defined(PLD_xcairo)
  aStream->XDisplay = NULL;
  aStream->XWindow = -1;
#endif
  aStream->cairoSurface = NULL;
  aStream->cairoContext = NULL;
  aStream->downscale = downscale;

  /* Set text clipping off as this makes the driver pretty slow */
  aStream->text_clipping = 0;
  text_clipping = 0;
  text_anti_aliasing = 0;     // use 'default' text aliasing by default
  graphics_anti_aliasing = 0; // use 'default' graphics aliasing by default

  /* Check for cairo specific options */
  plParseDrvOpts(cairo_options);

  /* Turn on text clipping if the user desires this */
  if(text_clipping){
    aStream->text_clipping = 1;
  }

  /* Record users desired text and graphics aliasing */
  aStream->text_anti_aliasing = text_anti_aliasing;
  aStream->graphics_anti_aliasing = graphics_anti_aliasing;

  return aStream;
}

/*---------------------------------------------------------------------
  set_current_context()
  
  Updates the cairo graphics context with the current values in
  PLStream.
  ---------------------------------------------------------------------*/

void set_current_context(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;
  cairo_set_source_rgba(aStream->cairoContext,
			(double)pls->curcolor.r/255.0, 
			(double)pls->curcolor.g/255.0,
			(double)pls->curcolor.b/255.0,
			(double)pls->curcolor.a);
  /* In Cairo, zero width lines are not hairlines, they are completely invisible. */
  if(pls->width < 1){
    cairo_set_line_width(aStream->cairoContext, 1.0);
  } else{
    cairo_set_line_width(aStream->cairoContext, (double) pls->width);
  }
}

/*---------------------------------------------------------------------
  poly_line()
  
  Draws a multi-segmented line. It is then up to the calling function
  to decide whether to just draw the line, or fill in the area
  enclosed by the line.
  ---------------------------------------------------------------------*/

void poly_line(PLStream *pls, short *xa, short *ya, PLINT npts)
{
  int i;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  set_current_context(pls);
  
  cairo_move_to(aStream->cairoContext, aStream->downscale * (double) xa[0], aStream->downscale * (double) ya[0]);
  for(i=1;i<npts;i++){
    cairo_line_to(aStream->cairoContext, aStream->downscale * (double) xa[i], aStream->downscale * (double) ya[i]);
  }
}

/*---------------------------------------------------------------------
  filled_polygon()
  
  Draws a filled polygon.
  ---------------------------------------------------------------------*/

void filled_polygon(PLStream *pls, short *xa, short *ya, PLINT npts)
{
  int i;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  cairo_move_to(aStream->cairoContext, aStream->downscale * (double) xa[0], aStream->downscale * (double) ya[0]);
  for(i=1;i<npts;i++)
    cairo_line_to(aStream->cairoContext, aStream->downscale * (double) xa[i], aStream->downscale * (double) ya[i]);
  cairo_set_source_rgba(aStream->cairoContext,
      (double)pls->curcolor.r/255.0, 
      (double)pls->curcolor.g/255.0,
      (double)pls->curcolor.b/255.0,
      (double)pls->curcolor.a);
  cairo_set_line_width(aStream->cairoContext, 1.0);
  if(pls->curcolor.a>0.99) {
    cairo_fill_preserve(aStream->cairoContext);
    cairo_stroke(aStream->cairoContext);
  } else
    cairo_fill(aStream->cairoContext);
}

/*---------------------------------------------------------------------
  rotate_cairo_surface()
  
  Rotates the cairo surface to the appropriate orientation.
  ---------------------------------------------------------------------*/

void rotate_cairo_surface(PLStream *pls, float x11, float x12, float x21, float x22, float x0, float y0)
{
  cairo_matrix_t *matrix;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  matrix = (cairo_matrix_t *) malloc (sizeof(cairo_matrix_t));
  cairo_matrix_init(matrix, x11, x12, x21, x22, x0, y0);
  cairo_transform(aStream->cairoContext, matrix);
  free(matrix);
}

/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is common to all familying Cairo Drivers
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/
#if defined(PLD_pngcairo) || defined(PLD_svgcairo)

void plD_bop_famcairo            (PLStream *);
/*----------------------------------------------------------------------
  plD_bop_famcairo()
  
  Familying Devices: Set up for the next page.
  ----------------------------------------------------------------------*/

void plD_bop_famcairo(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  /* Plot familying stuff. Not really understood, just copying gd.c */
  plGetFam(pls);
  pls->famadv = 1;
  pls->page++;

  /* Fill in the window with the background color. */
  cairo_rectangle(aStream->cairoContext, 0.0, 0.0, pls->xlength, pls->ylength);
  cairo_set_source_rgb(aStream->cairoContext,
		       (double)pls->cmap0[0].r/255.0,
		       (double)pls->cmap0[0].g/255.0,
		       (double)pls->cmap0[0].b/255.0);
  cairo_fill(aStream->cairoContext);
}

#endif
/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the xcairo driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_xcairo)

static int XScreen;
static Window rootWindow;

void plD_dispatch_init_xcairo    (PLDispatchTable *pdt);
void plD_init_xcairo             (PLStream *);
void plD_eop_xcairo              (PLStream *);
void plD_tidy_xcairo             (PLStream *);
void plD_esc_xcairo              (PLStream *, PLINT, void *);
static void xcairo_get_cursor    (PLStream *, PLGraphicsIn *);

/*---------------------------------------------------------------------
  plD_dispatch_init_xcairo()
  
  xcairo dispatch table initialization.
  ----------------------------------------------------------------------*/

void plD_dispatch_init_xcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo X Windows Driver";
   pdt->pl_DevName  = "xcairo";
#endif
   pdt->pl_type     = plDevType_Interactive;
   pdt->pl_seq      = 59;
   pdt->pl_init     = (plD_init_fp)     plD_init_xcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_xcairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_cairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_xcairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_xcairo;
}

/*---------------------------------------------------------------------
  xcairo_init_cairo()
  
  Configures Cairo to use whichever X Drawable is set up in the given
  stream.  This is called by plD_init_xcairo() in the event we are 
  drawing into a plplot-managed window, and plD_esc_xcairo() if
  we are using an external X Drawable.
  
  A return value of 0 indicates success.  Currently this function only
  returns 0.
  ----------------------------------------------------------------------*/

static signed int xcairo_init_cairo(PLStream *pls)
{
  PLCairo *aStream;
  Visual *defaultVisual;

  aStream = (PLCairo *)pls->dev;

  /* Create an cairo surface & context that are associated with the X window. */
  defaultVisual = DefaultVisual(aStream->XDisplay, 0);
  /* Dimension units are pixels from cairo documentation. */
  aStream->cairoSurface = cairo_xlib_surface_create(aStream->XDisplay, aStream->XWindow, defaultVisual, pls->xlength, pls->ylength);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Invert the surface so that the graphs are drawn right side up. */
  rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

  /* Set graphics aliasing */
  cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);

  return 0;
}

/*---------------------------------------------------------------------
  plD_init_xcairo()
  
  Initialize Cairo X Windows device.
  ----------------------------------------------------------------------*/

void plD_init_xcairo(PLStream *pls)
{
  char plotTitle[40];
  XGCValues values;
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table. */
  aStream = stream_and_font_setup(pls, 1);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

  /* Create a X Window if required. */
  if (external_drawable != 0) {
    aStream->xdrawable_mode = 1;
  } else {
    /* Initialize plot title */
    sprintf(plotTitle, "PLplot");

    /* X Windows setup */
    aStream->XDisplay = NULL;
    aStream->XDisplay = XOpenDisplay(NULL);
    if(aStream->XDisplay == NULL){
      printf("Failed to open X Windows display\n");
      /* some sort of error here */
    }
    XScreen = DefaultScreen(aStream->XDisplay);
    rootWindow = RootWindow(aStream->XDisplay, XScreen);

    aStream->XWindow = XCreateSimpleWindow(aStream->XDisplay, rootWindow, 0, 0, pls->xlength, pls->ylength, 
					    1, BlackPixel(aStream->XDisplay, XScreen), BlackPixel(aStream->XDisplay, XScreen));
    XStoreName(aStream->XDisplay, aStream->XWindow, plotTitle);
    XSelectInput(aStream->XDisplay, aStream->XWindow, NoEventMask);
    XMapWindow(aStream->XDisplay, aStream->XWindow);
    aStream->xdrawable_mode = 0;

    xcairo_init_cairo(pls);
  }

  aStream->exit_event_loop = 0;

}

/*---------------------------------------------------------------------
  plD_eop_xcairo()
  
  X Windows specific end of page.
  ---------------------------------------------------------------------*/

void plD_eop_xcairo(PLStream *pls)
{
  int number_chars;
  long event_mask;
  char event_string[10];
  KeySym keysym;
  XComposeStatus cs;
  XEvent event;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  if (aStream->xdrawable_mode)
    return;

  XFlush(aStream->XDisplay);

  /* Loop, handling selected events, till the user elects to close the plot. */
  printf("Click on the plot and key <Return> to exit.\n");
  event_mask = ButtonPressMask | KeyPressMask | ExposureMask;
  XSelectInput(aStream->XDisplay, aStream->XWindow, event_mask);
  while(!aStream->exit_event_loop){
    XWindowEvent(aStream->XDisplay, aStream->XWindow, event_mask, &event);
    switch(event.type){
    case KeyPress:
      number_chars = XLookupString((XKeyEvent *)&event, event_string, 10, &keysym, &cs);
      event_string[number_chars] = '\0';
      if(keysym == XK_Return){
	aStream->exit_event_loop = 1;
      }
      break;
    case Expose:
      plD_bop_cairo(pls);
      plRemakePlot(pls);
      XFlush(aStream->XDisplay);
      break;
    }
  }
  aStream->exit_event_loop = 0;

  /*  printf("Key <Return> to finish\n"); */
  /* getc(stdin); */
}

/*---------------------------------------------------------------------
  plD_tidy_xcairo()
  
  X Windows: close graphics file or otherwise clean up.
  ---------------------------------------------------------------------*/

void plD_tidy_xcairo(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  plD_tidy_cairo(pls);

  if (aStream->xdrawable_mode)
    return;

  /* Close the window and the display. */
  XFlush(aStream->XDisplay);

  XDestroyWindow(aStream->XDisplay, aStream->XWindow);

  XCloseDisplay(aStream->XDisplay);
}

/*---------------------------------------------------------------------
  plD_esc_xcairo()
  
  Escape function, specialized for the xcairo driver
  ---------------------------------------------------------------------*/

void plD_esc_xcairo(PLStream *pls, PLINT op, void *ptr)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  switch(op)
    {
    case PLESC_FILL:     /* filled polygon */
      filled_polygon(pls, pls->dev_x, pls->dev_y, pls->dev_npts);
      break;
    case PLESC_HAS_TEXT: /* render rext */
      proc_str(pls, (EscText *) ptr);
      break;
    case PLESC_FLUSH:    /* forced update of the window */
      XFlush(aStream->XDisplay);
      break;
    case PLESC_GETC:     /* get cursor position */
      XFlush(aStream->XDisplay);
      xcairo_get_cursor(pls, (PLGraphicsIn*)ptr);
      break;
    case PLESC_DEVINIT: { /* Set external drawable */
        Window rootwin;
        PLXcairoDrawableInfo *xinfo = (PLXcairoDrawableInfo *)ptr;
        signed int x, y;
        unsigned int w, h, b, d;
        if (xinfo == NULL) {
          printf("xcairo: PLESC_DEVINIT ignored, no drawable info provided\n");
          return;
        }
        if (aStream->xdrawable_mode == 0) {
          printf("xcairo: PLESC_DEVINIT called with drawable but stream not in xdrawable mode\n");
          return;
        }
        aStream->XDisplay = xinfo->display;
        aStream->XWindow = xinfo->drawable;

        /* Ensure plplot knows the real dimensions of the drawable */
        XGetGeometry(aStream->XDisplay, aStream->XWindow, &rootwin,
          &x, &y, &w, &h, &b, &d);
        pls->xlength = w;
        pls->ylength = h;
        plP_setphy((PLINT) 0, (PLINT) (pls->xlength / aStream->downscale), (PLINT) 0, 
          (PLINT) (pls->ylength / aStream->downscale));
  
        /* Associate cairo with the supplied drawable */
        xcairo_init_cairo(pls);

        /* Recalculate dimensions and the like now that the drawable is known */
        plbop();

        break;
      }
    }
}

/*---------------------------------------------------------------------
  xcairo_get_cursor()
  
  X Windows: returns the location of the next mouse click or key press.
  ---------------------------------------------------------------------*/

void xcairo_get_cursor(PLStream *pls, PLGraphicsIn *gin)
{
  int number_chars;
  KeySym keysym;
  XComposeStatus cs;
  XEvent event;
  XButtonEvent *xButtonEvent;
  Cursor xHairCursor;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  /* Initialize PLplot mouse event structure */
  plGinInit(gin);

  /* Create cross hair cursor & switch to using it */
  xHairCursor = XCreateFontCursor(aStream->XDisplay, XC_crosshair);
  XDefineCursor(aStream->XDisplay, aStream->XWindow, xHairCursor);

  /* Get the next mouse button release or key press event */
  XSelectInput(aStream->XDisplay, aStream->XWindow, ButtonReleaseMask | KeyPressMask);
  XMaskEvent(aStream->XDisplay, ButtonReleaseMask | KeyPressMask, &event);
  XSelectInput(aStream->XDisplay, aStream->XWindow, NoEventMask);

  /* Get key pressed (if any) */
  if(event.type == KeyPress){
    number_chars = XLookupString((XKeyEvent *)&event, gin->string, 10, &keysym, &cs);
    gin->string[number_chars] = '\0';
    switch (keysym){
    case XK_BackSpace:
    case XK_Tab:
    case XK_Linefeed:
    case XK_Return:
    case XK_Escape:
    case XK_Delete:
      gin->keysym = 0xFF & keysym;
      break;
    default:
      gin->keysym = keysym;
    }
  }
  else {
    gin->string[0] = '\0';
    gin->keysym = 0x20;
  }

  /* Update PLplot's mouse event structure */
  xButtonEvent = (XButtonEvent *)&event;
  gin->state = xButtonEvent->state;
  gin->button = xButtonEvent->button;
  gin->pX = event.xbutton.x;
  gin->pY = event.xbutton.y;
  gin->dX = (PLFLT)event.xbutton.x/((PLFLT)(pls->xlength));
  gin->dY = (PLFLT)event.xbutton.y/((PLFLT)(pls->ylength));

  /* Switch back to normal cursor */
  XUndefineCursor(aStream->XDisplay, aStream->XWindow);
  XFlush(aStream->XDisplay);
}

#endif


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo PDF driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_pdfcairo)

void plD_dispatch_init_pdfcairo  (PLDispatchTable *pdt);
void plD_init_pdfcairo           (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* pdfcairo */
void plD_dispatch_init_pdfcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo PDF Driver";
   pdt->pl_DevName  = "pdfcairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 60;
   pdt->pl_init     = (plD_init_fp)     plD_init_pdfcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_cairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_cairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_cairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_cairo;
}

/*---------------------------------------------------------------------
  plD_init_pdfcairo()
  
  Initialize Cairo PDF device
  ----------------------------------------------------------------------*/

void plD_init_pdfcairo(PLStream *pls)
{
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table */
  aStream = stream_and_font_setup(pls, 0);

  /* Prompt for a file name if not already set. */
  plOpenFile(pls);

  /* Create an cairo surface & context for PDF file. */
  /* Dimension units are pts = 1/72 inches from cairo documentation. */
  aStream->cairoSurface = cairo_pdf_surface_create_for_stream((cairo_write_func_t)write_to_stream, pls->OutFile, (double)pls->xlength, (double)pls->ylength);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

  /* Invert the surface so that the graphs are drawn right side up. */
  rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

  /* Set graphics aliasing */
  cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);
}

#endif


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo PS driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_pscairo)

void plD_dispatch_init_pscairo  (PLDispatchTable *pdt);
void plD_init_pscairo           (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* pscairo */
void plD_dispatch_init_pscairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo PS Driver";
   pdt->pl_DevName  = "pscairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 61;
   pdt->pl_init     = (plD_init_fp)     plD_init_pscairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_cairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_cairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_cairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_cairo;
}

/*---------------------------------------------------------------------
  plD_init_pscairo()
  
  Initialize Cairo PS device
  ----------------------------------------------------------------------*/

void plD_init_pscairo(PLStream *pls)
{
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table */
  aStream = stream_and_font_setup(pls, 0);

  /* Prompt for a file name if not already set. */
  plOpenFile(pls);

  /* Create an cairo surface & context for PS file. */
  /* Dimension units are pts = 1/72 inches from cairo documentation. */
  aStream->cairoSurface = cairo_ps_surface_create_for_stream((cairo_write_func_t)write_to_stream, pls->OutFile, (double)pls->ylength, (double)pls->xlength);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

  /* Handle portrait or landscape */
  if(pls->portrait){
    plsdiori(1);
    pls->freeaspect = 1;
  }
  rotate_cairo_surface(pls, 0.0, -1.0, -1.0, 0.0, pls->ylength, pls->xlength);
}


#endif


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo SVG driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_svgcairo)

void plD_dispatch_init_svgcairo  (PLDispatchTable *pdt);
void plD_init_svgcairo           (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* svgcairo */
void plD_dispatch_init_svgcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo SVG Driver";
   pdt->pl_DevName  = "svgcairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 62;
   pdt->pl_init     = (plD_init_fp)     plD_init_svgcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_cairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_famcairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_cairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_cairo;
}

/*---------------------------------------------------------------------
  plD_init_svgcairo()
  
  Initialize Cairo SVG device
  ----------------------------------------------------------------------*/

void plD_init_svgcairo(PLStream *pls)
{
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table and allocate a cairo 
     stream structure.
     
     NOTE: The check below is necessary since, in family mode, this function
      will be called multiple times. While you might think that it is
      sufficient to update what *should* be the only pointer to the contents
      of pls->dev, i.e. the pointer pls->dev itself, it appears that
      something else somewhere else is also pointing to pls->dev. If you
      change what pls->dev points to then you will get a "bus error", from
      which I infer the existence of said bad stale pointer.
  */
  if(pls->dev == NULL){
    aStream = stream_and_font_setup(pls, 0);
  } else {
    stream_and_font_setup(pls, 0);
    aStream = pls->dev;
  }

  /* Initialize family file info */
  plFamInit(pls);

  /* Prompt for a file name if not already set. */
  plOpenFile(pls);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

  /* Create an cairo surface & context for SVG file. */
  /* Dimension units are pts = 1/72 inches from cairo documentation. */
  aStream->cairoSurface = cairo_svg_surface_create_for_stream((cairo_write_func_t)write_to_stream, pls->OutFile, (double)pls->xlength, (double)pls->ylength);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Invert the surface so that the graphs are drawn right side up. */
  rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

  /* Set graphics aliasing */
  cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);
}

#endif


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo PNG driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_pngcairo)

void plD_dispatch_init_pngcairo  (PLDispatchTable *pdt);
void plD_init_pngcairo           (PLStream *);
void plD_eop_pngcairo            (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* pngcairo */
void plD_dispatch_init_pngcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo PNG Driver";
   pdt->pl_DevName  = "pngcairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 63;
   pdt->pl_init     = (plD_init_fp)     plD_init_pngcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_pngcairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_famcairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_cairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_cairo;
}

/*---------------------------------------------------------------------
  plD_init_pngcairo()
  
  Initialize Cairo PNG device
  ----------------------------------------------------------------------*/

void plD_init_pngcairo(PLStream *pls)
{
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table and allocate a cairo 
     stream structure.
     
     NOTE: The check below is necessary since, in family mode, this function
      will be called multiple times. While you might think that it is
      sufficient to update what *should* be the only pointer to the contents
      of pls->dev, i.e. the pointer pls->dev itself, it appears that
      something else somewhere else is also pointing to pls->dev. If you
      change what pls->dev points to then you will get a "bus error", from
      which I infer the existence of said bad stale pointer.
  */
  if(pls->dev == NULL){
    aStream = stream_and_font_setup(pls, 0);
  } else {
    stream_and_font_setup(pls, 0);
    aStream = pls->dev;
  }

  /* Initialize family file info */
  plFamInit(pls);

  /* Prompt for a file name if not already set. */
  plOpenFile(pls);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

  /* Create a new cairo surface & context for PNG file. */
  /* Dimension units are pixels from cairo documentation. */
  aStream->cairoSurface = cairo_image_surface_create(CAIRO_FORMAT_RGB24, (double)pls->xlength, (double)pls->ylength);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Invert the surface so that the graphs are drawn right side up. */
  rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

  /* Set graphics aliasing */
  cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);
}

/*---------------------------------------------------------------------
  plD_eop_pngcairo()
  
  PNG: End of page.
  ---------------------------------------------------------------------*/

void plD_eop_pngcairo(PLStream *pls)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;
  cairo_surface_write_to_png_stream(aStream->cairoSurface, (cairo_write_func_t)write_to_stream, pls->OutFile);
}

#endif


/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo memory driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_memcairo)

void plD_dispatch_init_memcairo  (PLDispatchTable *pdt);
void plD_init_memcairo           (PLStream *);
void plD_eop_memcairo            (PLStream *);
void plD_bop_memcairo            (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* memcairo */
void plD_dispatch_init_memcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo memory driver";
   pdt->pl_DevName  = "memcairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 64;
   pdt->pl_init     = (plD_init_fp)     plD_init_memcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_memcairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_memcairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_cairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_cairo;
}

/*----------------------------------------------------------------------
  plD_bop_memcairo()
  
  Set up for the next page.
  ----------------------------------------------------------------------*/

void plD_bop_memcairo(PLStream *pls)
{
  /* nothing to do here (we want to preserve the memory as it is) */
}

/*---------------------------------------------------------------------
  plD_init_memcairo()
  
  Initialize Cairo memory device
  ----------------------------------------------------------------------*/

void plD_init_memcairo(PLStream *pls)
{
  PLCairo *aStream;
  int stride, i;
  unsigned char *cairo_mem;
  unsigned char *input_mem;

  /* used for checking byte order */
  union {
    int testWord;
    char testByte[sizeof(int)];
  } endianTest;
  endianTest.testWord = 1;
    
  /* Set the plot size to the memory buffer size, on the off chance
     that they are different. */
  pls->xlength = pls->phyxma;
  pls->ylength = pls->phyyma;
  
  /* Setup the PLStream and the font lookup table */
  aStream = stream_and_font_setup(pls, 0);

  /* Test byte order */
  if (endianTest.testByte[0] == 1) aStream->bigendian = 0;
  else                             aStream->bigendian = 1;

  /* Check that user supplied us with some memory to draw in */
  if(pls->dev == NULL){
    plexit("Must call plsmem first to set user plotting area!");
  }
  
  /* Save a pointer to the memory. */
  aStream->memory = pls->dev;

  /* Create a cairo surface & context.  Copy data in from the input memory area */

  /* Malloc memory the way cairo likes it.  Aligned on the stride computed by cairo_format_stride_for_width
     and in the RGB24 format (from http://cairographics.org/manual/cairo-Image-Surfaces.html):
     Each pixel is a 32-bit quantity, with the upper 8 bits unused. 
     Red, Green, and Blue are stored in the remaining 24 bits in that order */
  stride = pls->xlength * 4;
  /* stride = cairo_format_stride_for_width (CAIRO_FORMAT_RGB24, pls->xlength);  This function missing from version 1.4 :-( */
  aStream->cairo_format_memory = (unsigned char *)calloc (stride * pls->ylength, 1);

  /* Copy the input data into the Cairo data format */
  cairo_mem = aStream->cairo_format_memory;
  input_mem = aStream->memory;

  /* 32 bit word order
     cairo mem:  Big endian:  0=A, 1=R, 2=G, 3=B
                 Little endian:  3=A, 2=R, 1=G, 0=B */
  if (aStream->bigendian) {
    for(i = 0;i < (pls->xlength * pls->ylength); i++){
      cairo_mem[1] = input_mem[0]; /* R */
      cairo_mem[2] = input_mem[1]; /* G */
      cairo_mem[3] = input_mem[2]; /* B */
      input_mem += 3;
      cairo_mem += 4;
    }
  } else {
    for(i = 0;i < (pls->xlength * pls->ylength); i++){
      cairo_mem[2] = input_mem[0]; /* R */
      cairo_mem[1] = input_mem[1]; /* G */
      cairo_mem[0] = input_mem[2]; /* B */
      input_mem += 3;
      cairo_mem += 4;
    }
  }

  /* Create a Cairo drawing surface from the input data */
  aStream->cairoSurface = 
  /* Dimension units are width, height of buffer image from cairo 
     documentation. */
    cairo_image_surface_create_for_data (aStream->cairo_format_memory, CAIRO_FORMAT_RGB24, pls->xlength, pls->ylength, stride);
  aStream->cairoContext = cairo_create(aStream->cairoSurface);

  /* Save the pointer to the structure in the PLplot stream.
     Note that this wipes out the direct pointer to the memory buffer. */
  pls->dev = aStream;

  /* Invert the surface so that the graphs are drawn right side up. */
  rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

  /* Set graphics aliasing */
  cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);
}
      
/*---------------------------------------------------------------------
  plD_eop_memcairo()
  
  Memory device specific end of page. This copies the contents
  of the cairo surface into the user supplied memory buffer.
  ---------------------------------------------------------------------*/

void plD_eop_memcairo(PLStream *pls)
{
  int i;
  unsigned char *memory;
  unsigned char *cairo_surface_data;
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;
  memory = aStream->memory;
  cairo_surface_data = cairo_image_surface_get_data(aStream->cairoSurface);
  /* 32 bit word order
     cairo mem:  Big endian:  0=A, 1=R, 2=G, 3=B
                 Little endian:  3=A, 2=R, 1=G, 0=B */
  if (aStream->bigendian) {
    for(i = 0;i < (pls->xlength * pls->ylength); i++){
      memory[0] = cairo_surface_data[1]; /* R */
      memory[1] = cairo_surface_data[2]; /* G */
      memory[2] = cairo_surface_data[3]; /* B */
      memory += 3;
      cairo_surface_data += 4;
    }
  } else {
    for(i = 0;i < (pls->xlength * pls->ylength); i++){
      memory[0] = cairo_surface_data[2]; /* R */
      memory[1] = cairo_surface_data[1]; /* G */
      memory[2] = cairo_surface_data[0]; /* B */
      memory += 3;
      cairo_surface_data += 4;
    }
  }

  /* Free up the temporary memory malloc'ed in plD_init_memcairo */
  free (aStream->cairo_format_memory);

}

#endif

/*---------------------------------------------------------------------
  ---------------------------------------------------------------------
  
  That which is specific to the cairo external context driver.
  
  ---------------------------------------------------------------------
  ---------------------------------------------------------------------*/

#if defined(PLD_extcairo)

void plD_dispatch_init_extcairo (PLDispatchTable *pdt);
void plD_init_extcairo          (PLStream *);
void plD_bop_extcairo           (PLStream *);
void plD_eop_extcairo           (PLStream *);
void plD_esc_extcairo           (PLStream *, PLINT, void *);
void plD_tidy_extcairo          (PLStream *);

/*---------------------------------------------------------------------
  dispatch_init_init()
  
  Initialize device dispatch table
  ----------------------------------------------------------------------*/

/* extcairo */
void plD_dispatch_init_extcairo(PLDispatchTable *pdt)
{
#ifndef ENABLE_DYNDRIVERS
   pdt->pl_MenuStr  = "Cairo external context driver";
   pdt->pl_DevName  = "extcairo";
#endif
   pdt->pl_type     = plDevType_FileOriented;
   pdt->pl_seq      = 65;
   pdt->pl_init     = (plD_init_fp)     plD_init_extcairo;
   pdt->pl_line     = (plD_line_fp)     plD_line_cairo;
   pdt->pl_polyline = (plD_polyline_fp) plD_polyline_cairo;
   pdt->pl_bop      = (plD_bop_fp)      plD_bop_extcairo;
   pdt->pl_eop      = (plD_eop_fp)      plD_eop_extcairo;
   pdt->pl_tidy     = (plD_tidy_fp)     plD_tidy_extcairo;
   pdt->pl_state    = (plD_state_fp)    plD_state_cairo;
   pdt->pl_esc      = (plD_esc_fp)      plD_esc_extcairo;
}

/*---------------------------------------------------------------------
  plD_init_extcairo()
  
  Initialize Cairo external context driver.
  ----------------------------------------------------------------------*/

void plD_init_extcairo (PLStream *pls)
{
  PLCairo *aStream;

  /* Setup the PLStream and the font lookup table */
  aStream = stream_and_font_setup(pls, 0);

  /* Save the pointer to the structure in the PLplot stream */
  pls->dev = aStream;

}

/*----------------------------------------------------------------------
  plD_bop_extcairo()
  
  Set up for the next page.
  ----------------------------------------------------------------------*/

void plD_bop_extcairo(PLStream *pls)
{
/* nothing to do here, we want to preserve the Cairo context as it is. */
}

/*----------------------------------------------------------------------
  plD_eop_extcairo()
  
  End of page.
  ----------------------------------------------------------------------*/

void plD_eop_extcairo(PLStream *pls)
{
  /* nothing to do here, we leave it to the calling program to display
     (or not) the update cairo context. */
}

/*---------------------------------------------------------------------
  plD_esc_extcairo()
  
  The generic escape function, extended so that user can pass in
  an external Cairo context to use for rendering.
  ---------------------------------------------------------------------*/

void plD_esc_extcairo(PLStream *pls, PLINT op, void *ptr)
{
  PLCairo *aStream;

  aStream = (PLCairo *)pls->dev;

  switch(op)
    {
    case PLESC_FILL:     /* filled polygon */
      filled_polygon(pls, pls->dev_x, pls->dev_y, pls->dev_npts);
      break;
    case PLESC_HAS_TEXT: /* render text */
      proc_str(pls, (EscText *) ptr);
      break;
    case PLESC_DEVINIT: /* Set external context */
      aStream->cairoContext = (cairo_t *)ptr;
      /* Set graphics aliasing */
      cairo_set_antialias(aStream->cairoContext, aStream->graphics_anti_aliasing);

      /* Invert the surface so that the graphs are drawn right side up. */
      rotate_cairo_surface(pls, 1.0, 0.0, 0.0, -1.0, 0.0, pls->ylength);

      /* Should adjust plot size to fit in the given cairo context?
         Cairo does not provide a way to query the dimensions of a context? */

      break;
    }
}

/*---------------------------------------------------------------------
  plD_tidy_extcairo()

  This is nop, it is up to the calling program to clean up the Cairo
  context, etc...
  ---------------------------------------------------------------------*/

void plD_tidy_extcairo(PLStream *pls)
{
}

#endif

