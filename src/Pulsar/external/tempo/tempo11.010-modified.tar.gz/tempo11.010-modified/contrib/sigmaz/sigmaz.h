      character*100 infile,outroot
      integer*4 npt,nusewt,nxunits,ntunits,nformat,nwriteres,nbintype
     . ,npt1last,npt2last,ncubic,ncubics,ntau,linfile,indx(90000),ndim
     . ,loutroot
      real*8 data(90000),utjd(90000),taumin,sigmai(90000),permax,root2
     . ,utjd1,utjd2,tmin,tmax,xmin,xmax,utjdlast,tausec,taumax,tauday
     . ,prtl(4),utmean,secyear,taulog,addvar,tauyear,tauensure,tdiffmin
      common/c100/infile,outroot
      common/i4/npt,nusewt,nxunits,ntunits,nformat,nwriteres,nbintype
     . ,npt1last,npt2last,ncubic,ncubics,ntau,linfile,indx,ndim
     . ,loutroot
      common/r8/data,utjd,taumin,sigmai,permax,utjd1,utjd2,xmin,xmax
     . ,tmin,tmax,utjdlast,tausec,taumax,taulog,root2,tauday,tauyear
     . ,prtl,secyear,utmean,addvar,tauensure,tdiffmin
