c      $Id: dp.h,v 1.2 2002/03/02 19:32:18 david Exp $
        common/dp/ pepoch,ct,f0,f1,p0,p1,p2,f2,f3,f4(9),
     +    dmcof(NDMCOFMAX)

