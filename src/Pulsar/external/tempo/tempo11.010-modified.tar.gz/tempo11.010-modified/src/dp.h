c      $Id: dp.h,v 1.1 1998/01/19 21:57:27 david Exp $
	common/dp/ pepoch,ct,f0,f1,p0,p1,p2,f2,f3,f4(9),dmcof(9)
