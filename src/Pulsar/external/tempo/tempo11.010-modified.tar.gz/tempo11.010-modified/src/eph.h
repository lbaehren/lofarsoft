c      $Id: eph.h,v 1.1 1998/01/19 21:57:29 david Exp $
	character*280 ephdir,ephfile(NEPHMAX)

        common/ephfile/ ephdir,ephfile,kephem,nephem

