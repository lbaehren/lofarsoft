c      $Id: trnsfr.h,v 1.1 1998/01/19 21:57:47 david Exp $

        logical ut1flag
	common /trnsfr/ frq,be(3),px,dtdpx,dtdpmrv,dtdppng,etatdm,
     +     aa_q(3),aa_m(3),dpara,nddm,ut1flag
