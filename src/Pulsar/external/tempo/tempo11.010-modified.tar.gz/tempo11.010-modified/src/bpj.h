       real*8 bpjep(NBPJMX), bpjph(NBPJMX), bpja1(NBPJMX), 
     +    bpjec(NBPJMX), bpjom(NBPJMX), bpjpb(NBPJMX)
       common/bpj/bpjep,bpjph,bpja1,bpjec,bpjom,bpjpb,nbpj
