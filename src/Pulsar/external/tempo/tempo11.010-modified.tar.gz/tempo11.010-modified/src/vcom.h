c      $Id: vcom.h,v 1.1 1998/01/19 21:57:49 david Exp $
	logical lresid1
	common/vcom/lresid1
