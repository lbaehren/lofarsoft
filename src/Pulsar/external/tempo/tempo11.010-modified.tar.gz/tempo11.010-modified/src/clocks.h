c      $Id: clocks.h,v 1.1 1998/01/19 21:57:26 david Exp $
        character clkfile(NCLKMAX)*280, clklbl(0:NCLKMAX)*12,clkdir*280
	integer ckflag(NPT)

	common/clocks/ tdate(NPT),ckcorr(NPT),jsite(NPT),ndate,nclk,
     +    tbipm(NPT),bipm(NPT),utcclk(NPT),tutc(NPT),ckflag
        common/clkfile/clkdir,clkfile,clklbl
