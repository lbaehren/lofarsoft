c NOTE: this code isn't presently used.
c	$Id: ut1.h,v 1.2 1998/03/15 13:49:18 david Exp $
	common/ut1/kind,int,units,mjd1,mjd2,nvtot,iut(NUTMAX)
