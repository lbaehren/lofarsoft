c      $Id: dp.h,v 1.3 2006/07/28 15:19:53 david Exp $
        common/dp/ pepoch,ct,f0,f1,p0,p1,p2,f2,f3,f4(9),
     +    dmcof(NDMCOFMAX),dmvar1,dmvar2

