c      $Id: glitch.h,v 1.2 1998/03/11 14:45:54 david Exp $
	real*8 glph(NGLT), glf0(NGLT), glf1(NGLT),
     :      glf0d(NGLT),gltd(NGLT),glepoch(NGLT)
	common/glitch/glph,glf0,glf1,glf0d,gltd,glepoch,ngl
