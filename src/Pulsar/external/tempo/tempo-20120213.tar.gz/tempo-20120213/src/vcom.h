c      $Id: vcom.h,v 1.2 2010/03/19 18:32:45 demorest Exp $
	logical lresid1,ldesign
	common/vcom/lresid1,ldesign
