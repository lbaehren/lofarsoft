c      $Id: bcom.h,v 1.1 1998/01/19 21:57:20 david Exp $
	common/bcom/ p0firs,sigma1,asig,ct1,ctmax
