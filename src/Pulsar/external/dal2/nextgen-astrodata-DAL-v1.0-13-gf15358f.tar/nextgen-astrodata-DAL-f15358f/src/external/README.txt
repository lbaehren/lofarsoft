This directory contains files copied from packages we use, which are annoying to locate automatically and are not expected to change often. It's a definite TODO to eliminate all of them and really locate their properly installed versions.

