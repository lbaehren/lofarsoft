This directory contains example classes for extending the functionality for each file/group/dataset.

Most of these classes are yet barely tested, so user beware.
