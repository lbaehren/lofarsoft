/* Template for a tempo2 plugin */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "../tempo2.h"
#include <cpgplot.h>
#include <time.h>

#define MAXSTRING 255

using namespace std;

void help(); // display help

extern "C" int graphicalInterface (int argc, char *argv[], pulsar *psr, int *npsr){

  char parFile[1][MAX_FILELEN];
  char timFile[1][MAX_FILELEN];
  char outfile[MAXSTRING];
  int outtype = 0; // if 1 then save output TOAs and phases in the file
  FILE *out;

  int i, k, event;   // generic counters
  int par_file = 0;  // 1 if par-file is set
  int tim_file = 0;  // 1 if tim-file is set

  longdouble lasttime, tzrmjd_bary;
  double lastpos[3];
  
  double tmin, tmax;
  double *times; 
  float *phase, *phase2;
  double intpart;
  
  char gr[100]="/xs";  // default graphical output is xwindow
  float fontsize;
  int nbins = 20;           // default number of bins for the output phase histogram
  int graph = 1;  // if 0, no output graph
  int nobs;       // number of toas
  
  *npsr = 1;  /* For a graphical interface that only shows results for one pulsar */

  // Parsing command line
  for (i=2; i<argc; i++) {
    if (strcmp(argv[i],"-par")==0) {
       par_file = 1;
       strcpy(parFile[0],argv[i+1]);
    } else if (strcmp(argv[i],"-tim")==0) { 
       tim_file = 1; 
       strcpy(timFile[0],argv[i+1]); 
    } else if (strcmp(argv[i],"-output")==0) { 
       outtype = 1; 
       strcpy(outfile,argv[i+1]);
    } else if (strcmp(argv[i],"-grdev")==0) {
       strcpy(gr,argv[i+1]);
       if (strcmp(gr,"null")==0) graph = 0;
    } else if (strcmp(argv[i],"-bins")==0) {
       sscanf(argv[i+1],"%d",&nbins);
    } else if (strcmp(argv[i],"-h")==0) {
       help();
       exit(0);
    }
  } // for

  if (!par_file) {
   printf ("No par-file is set!\n");
   exit(0);
  }

  if (!tim_file) {
   printf ("No tim-file is set!\n");
   exit(0);
  }

  if (outtype == 1) {
   out = fopen(outfile,"w");
   if (out == NULL) { perror("fopen"); exit (1); }
  }

  printf("\n");
  printf("-----------------------------------------------------\n");
  printf("Output interface:    BaryPhase\n");
  printf("Author:              J.P.W. Verbiest\n");
  printf("Updated:             Vlad Kondratiev (March 20, 2010)\n");
  printf("Version:             1.1\n");
  printf("-----------------------------------------------------\n");
  printf("\n");
  

  // Load the parameters
  readParfile(psr, parFile, timFile, *npsr); 
  // Load the arrival times
  readTimfile(psr,timFile,*npsr);
    
  if (psr[0].tzrsite[0] == '@') {
   tzrmjd_bary = psr[0].param[param_tzrmjd].val[0];
  } else {
   psr[0].obsn[0].sat = psr[0].param[param_tzrmjd].val[0];
   psr[0].obsn[0].freq = psr[0].param[param_tzrfrq].val[0];
   strcpy(psr[0].obsn[0].telID, psr[0].tzrsite); 
   psr[0].obsn[0].deleted = 0;
   psr[0].obsn[0].nFlags = 0;
   psr[0].obsn[0].delayCorr = 1;
   psr[0].obsn[0].clockCorr = 1;

   // Form barycentric TZR
   formBatsAll(psr, *npsr);
   tzrmjd_bary = psr[0].obsn[0].bat;
  }

  // Load the parameters
  readParfile(psr, parFile, timFile, *npsr); 
  // Load the arrival times
  readTimfile(psr, timFile, *npsr);
  
  for(i=1; i<psr[0].nobs; i++){
    psr[0].obsn[i].deleted = 0;
    psr[0].obsn[i].nFlags = 0;
    psr[0].obsn[i].delayCorr = 1; // Correct delays for event i
    psr[0].obsn[i].clockCorr = 1; // Also make clock correction TT -> TDB
  }
  
  // save the first TOA (it will be replaced with the fake one (TZRMJD) go
  // get reference phase. Will be recovered later
  lasttime = psr[0].obsn[psr[0].nobs-1].sat;
  for (k=0; k<3; k++) lastpos[k] = psr[0].obsn[psr[0].nobs-1].observatory_earth[k];

  for (i=psr[0].nobs-1; i>0; i--) {
    psr[0].obsn[i].sat = psr[0].obsn[i-1].sat;
    for (k=0; k<3; k++) psr[0].obsn[i].observatory_earth[k] = psr[0].obsn[i-1].observatory_earth[k];
  }

  // Stick in a fake TOA to get a ref phase
  psr[0].obsn[0].sat = tzrmjd_bary;
  psr[0].obsn[0].freq = 0.;
  psr[0].obsn[0].deleted = 0;
  psr[0].obsn[0].nFlags = 0;
  psr[0].obsn[0].delayCorr = 0;
  psr[0].obsn[0].clockCorr = 0;
  
  // get barycentric arrival times
  formBatsAll(psr, *npsr);
  
  times = (double *)calloc(psr[0].nobs, sizeof(double));
  phase = (float *)calloc(psr[0].nobs, sizeof(float));
  if (!times || !phase) { perror("calloc times or phase"); exit (1); }
  if (graph != 0) {
    phase2 = (float *)calloc(2 * psr[0].nobs, sizeof(float));
    if (!phase2) { perror("calloc phase2"); exit (1); }
  }
  
  // get event phases
  formResiduals(psr, *npsr, 0);
  
  event = 0;
  tmin = psr[0].obsn[1].bat;
  tmax = tmin;

  if (outtype == 1) fprintf (out, "# TOA#\t\t SAT\t\t\t BAT\t\t Phase\t\t\t Phase (int part)\n");
   
  for (i=1; i<psr[0].nobs; i++) {
   phase[event] = modf(psr[0].obsn[i].phase, &intpart);
   if (phase[event] < 0.) phase[event]++;

   times[event] = psr[0].obsn[i].bat;
   if (times[event] > tmax) tmax = times[event];
   if (times[event] < tmin) tmin = times[event];
   if (outtype == 1) fprintf(out, "%d\t %22.17Lg\t %22.17Lg\t %12.10lg\t\t %.0lf\n", event, psr[0].obsn[i].sat, psr[0].obsn[i].bat, phase[event], intpart);
   event++;
  }
  
  psr[0].obsn[1].sat = lasttime;
  for (k=0; k<3; k++) psr[0].obsn[1].observatory_earth[k] = lastpos[k];
  formBatsAll(psr, *npsr);
  formResiduals(psr,*npsr, 0);
  
  phase[event] = modf(psr[0].obsn[1].phase, &intpart);
  if (phase[event] < 0.) phase[event]++;
  times[event] = psr[0].obsn[1].bat;		
  if (times[event] > tmax) tmax = times[event];
  if (times[event] < tmin) tmin = times[event];
  if (outtype == 1) fprintf(out, "%d\t %22.17Lg\t %22.17Lg\t %12.10lg\t\t %.0lf\n", event, psr[0].obsn[1].sat, psr[0].obsn[1].bat, phase[event], intpart);   
  
  if (outtype == 1) fclose(out);
    
  // Graphics output
  if (graph != 0) {
    
   nobs = psr[0].nobs;
   // Phase2 = Phase plotted on 2 rotations
   for (i=0; i<nobs; i++) {
     phase2[i] = phase[i];
     phase2[i+nobs] = phase[i]+1.;
     times[i] = (float)((times[i] - tmin) * 1440.);
   }

   float xmoy[2], ymoy[2];
   xmoy[0] = 0., xmoy[1] = 2.;
   ymoy[0] = (float)nobs/(float)nbins;
   ymoy[1] = ymoy[0];

   // Initialization
   cpgbeg(0,gr,1,1);
   cpgsubp(2,1);

   // Invert foreground and background: black on white
   cpgscr(0,1,1,1); 
   cpgscr(1,0,0,0);	

   fontsize = 1.2;

        // First panel : phase histogram
        cpgsci(1);
        cpghist(2 * nobs, phase2, 0., 2., nbins*2, 4);

        cpgsci(1);
        cpgsch(fontsize);		
        cpglab("Phase", "Number of events", psr[0].name);

        cpgsls(2);
        cpgline(2, xmoy, ymoy);
        cpgsls(1);

        // Second panel : time vs phase
        cpgsci(1);

        cpgenv(0., 1., 0, (tmax-tmin)*1440., 0, 0);
        for (i=0; i<nobs; i++) cpgpt1 (phase[i], times[i], 17);

        cpgsci(1);
        cpgsch(fontsize);	
        cpglab("Phase", "Observation time (min)", timFile[0]);

	cpgiden();
	
  } // if (graph != 0)

  printf("Done with %s\n",psr[0].name);

  free (times);
  free (phase);
  if (graph != 0) free (phase2);
  
  return 0;
}

/* Display help */
void help(){
  printf("=====================================================================================\n");
  printf("\t BaryPhase - a TEMPO2 graphical plugin\n");
  printf("\t To convert the Site-Arrival-Times from a tim file to \n");
  printf("\t Barycentric-Arrival-Times and get events phases at Barycenter\n");
  printf("\n USAGE: tempo2 -gr BaryPhase -par par.par -tim tim.tim\n");
  printf("\n OPTIONS:\n");
  printf("\t -output: specifies output file containing sats, bats, and phases\n");
  printf("\t -grdev <dev>: graphical device, default = /xwindow. If dev = null, no output graph\n");
  printf("\t -bins N: number of bins for phase histogram, default = 20\n");
  printf("\t -h: this help\n");
  printf("=====================================================================================\n");
}
