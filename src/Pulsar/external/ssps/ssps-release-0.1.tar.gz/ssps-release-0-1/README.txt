==========================
Simple Single Pulse Search
==========================

The Simple Single Pulse Search package is pure python. It depends on Scipy 
for fitting (http://www.scipy.org/), Numpy for handling timeseries 
data (http://numpy.scipy.org/) and ElementTree 
(http://effbot.org/zone/element-index.htm) for plotting. The latter is needed 
only for Python versions older than 2.5. To install ssps either set
the PYTHONPATH environment variable to include a directory that contains the
ssps directory from this tarball (recommended for development of the library 
itself) or run the command `python setup.py install` from the root directory of
the installation tarball (that will install it to the site-packages directory of
your Python installation).

The documentation is written in so-called reStructuredText and included with 
this tarball in the docs directory. Using Sphinx (http://sphinx.pocoo.org/) this
reStructuredText can be turned into nice indexed HTML (viewable with a 
webbrowser). If you have Sphinx installed change to the docs directory and run
the following command `make html` to create the HTML files. The HTML files will
then appear in a new directory _build/html/ inside of the docs directory.

After installing it is possible to test your install by changing to the tests
directory included in the tarball and to run the command `python test.py` to
test the basics and `python gbt.py` to test the plotting (look in the output
subdirectory of the tests directory for .xml files that can be viewed as graphs
in modern browsers with SVG support).


Thijs Coenen (2009-2010)