import os, sys
from ssps.presto.files.inf import inf_reader, inf_writer

TEST_DIR = os.path.split(os.path.abspath(sys.argv[0]))[0]
DATA_DIR = os.path.join(TEST_DIR, 'testdata')
OUTPUT_DIR = os.path.join(TEST_DIR, 'output')


metadata = inf_reader(os.path.join(DATA_DIR, 
    'GBT350drift_54253_2359-0646_DM995.00.inf'))
inf_writer(os.path.join(OUTPUT_DIR, 'INFTEST_OUTPUT.inf'), metadata)
