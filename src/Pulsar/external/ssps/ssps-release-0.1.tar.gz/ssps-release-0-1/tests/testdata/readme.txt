Test data sets in this directory are from the Green Bank Telescope 350 MHz 
driftscan pulsar survey. With this data I can test that ssps is working as 
intended.


GBT350drift_54253_2359-0646
    Data set containing no pulsar or excessive RFI.
decimated
    Data set derived from GBT350drift_54253_2359-0646, but with fewer DM trials,
    for quicker testing.

GBT350drift_54253_2011-0644
    Data set containing bad RFI.

GBT350drift_54298_1840+0857
    Data set containing repeating pulses which should have a 'real' DM versus
    SNR profile. (A pulsar redetection in this survey.)

GBT350drift_54299_2045+0856
    Data set containing a pulsar with not very strong single pulses.