# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains a set of PRESTO/pulsar data specific plot objects.
'''
from __future__ import division
import random

from ssps.plotting.util import transform
from ssps.plotting.util import map
from ssps.plotting.util import ranges
from ssps.plotting.svg import base
from xml.sax.saxutils import escape

try:
    import xml.etree.cElementTree as ET
except ImportError:
    try:
        import xml.etree.ElementTree as ET
    except ImportError:
        import elementtree.ElementTree as ET

# ------------------------------------------------------------------------------
# -- Diagnostic plot of single pulse candidates in time DM plane ---------------

class GroupedPlotArea(base.PlotArea2d):
    '''
    Plotting code for GroupedPlot, don't instantiate directly. Use GroupedPlot.
    '''
    def __init__(self, pd, groups, bin_interval, bin_width, dm_interval, 
        divider_bin_interval, *args, **kwargs):
        super(GroupedPlotArea, self).__init__()
        self.groups = groups
        self.bin_width = bin_width
        self.bin_interval = bin_interval
        self.presto_dir = pd
        self.divider_bin_interval = divider_bin_interval
        self.dm_interval = dm_interval
        # Use ColorMap specified by the 'colormap' keyword argument, default to
        # using a red to blue gradient. (The colormap shows the width of a 
        # pulse.)
        self.colormap = kwargs.get('colormap', map.ColorMap([0, 30], 
            [1, 0, 0], [0, 0, 1]))
        # Use the ValueMap specified by the valuemap keyword argument, default
        # to using a range of length values [5, 20] for the length of the lines
        # that show the detections.
        # TODO rename self.radiusmap to something more appropriate
        self.radiusmap = kwargs.get('valuemap', map.ValueMap([5, 20], 5, 20))
        
        self.set_x_interval(interval = bin_interval)
        self.set_y_interval(interval = dm_interval)

    def draw_candidate(self, root_element, candidate):
        '''
        Draw a Candidate on DM time plane. Don't call directly.
        '''
        delay = self.presto_dir.dm2delay[candidate.dm]
        c = ET.SubElement(root_element, 'line')
        downsample_factor = self.presto_dir.dm2downsample[candidate.dm]
                
        c.set('x1', '%.2f' % 
            (self.x_transform(candidate.sample * downsample_factor + delay) - 
            (self.radiusmap(candidate.sigma) / 2)))
        c.set('x2', '%.2f' % 
            (self.x_transform(candidate.sample * downsample_factor + delay) + 
            (self.radiusmap(candidate.sigma) / 2)))
        c.set('y1', '%.2f' % self.y_transform(candidate.dm))
        c.set('y2', '%.2f' % self.y_transform(candidate.dm))
        c.set('stroke', self.colormap(candidate.downfact))
        c.set('fill', 'none')
        c.set('stroke-width', '0.5')

    
    def draw_group_members(self, root_element, group):
        '''
        Draw CandidateGroup's member, unless too many. Don't call directly.
        '''
        group.candidates.sort(key = lambda x : x.sigma)
        svg_g = ET.SubElement(root_element, 'g')
        if not len(group.candidates) > 1000:
            for c in group.candidates:
                # Check that a detection is within the sample range of graph.
                if self.dm_interval[0] <= c.dm <= self.dm_interval[1]:
                    # Calculate the range of samples that a candidate covers
                    # taking into account, downsampling, delay compensation and
                    # smoothing. This needs to be kept in sync with the 
                    # calculation that happens in the function:
                    # ssps.group.groups.group_presto_data
                    c_min_sample = c.sample * self.presto_dir.dm2downsample[c.dm] + \
                        self.presto_dir.dm2delay[c.dm]
                    c_max_sample = (c.sample + c.downfact) * self.presto_dir.dm2downsample[c.dm] \
                        - 1 + self.presto_dir.dm2delay[c.dm]
                    if c_max_sample >= self.bin_interval[0] and c_min_sample <= self.bin_interval[1]:
                        self.draw_candidate(svg_g, c)

        else:
            # If more than a thousand detection fall within one group it is 
            # drawn only as a box with a cross through it.
            
            min_sample = group.min_sample
            max_sample = group.max_sample
            
            if min_sample < self.bin_interval[0]: 
                min_sample = self.bin_interval[0]
            if max_sample > self.bin_interval[1]:
                max_sample = self.bin_interval[1]
            
            min_dm = group.min_dm
            max_dm = group.max_dm
            
            if max_dm > self.dm_interval[1]: max_dm = self.dm_interval[1]
            if min_dm < self.dm_interval[0]: min_dm = self.dm_interval[0]
            
            l1 = ET.SubElement(svg_g, 'line')
            l1.set('x1', '%.2f' % self.x_transform(min_sample))
            l1.set('y1', '%.2f' % self.y_transform(max_dm))
            l1.set('x2', '%.2f' % self.x_transform(max_sample))
            l1.set('y2', '%.2f' % self.y_transform(min_dm))
            l1.set('stroke', 'black')

            l2 = ET.SubElement(svg_g, 'line')
            l2.set('x1', '%.2f' % self.x_transform(min_sample))
            l2.set('y1', '%.2f' % self.y_transform(min_dm))
            l2.set('x2', '%.2f' % self.x_transform(max_sample))
            l2.set('y2', '%.2f' % self.y_transform(max_dm))
            l2.set('stroke', 'black')

    def draw_group_box(self, root_element, group):
        '''
        Draw CandidateGroup bounding box on time-DM plane. Don't call directly.
        
        Note : if the CandidateGroup has a .link attribute, a clickable link 
        will be added to the SVG file. This function assumes the .link attribute
        is a string representing the target location for the link. 
        '''
        # Check for the presence of a .link attribute and if present add an xml
        # link to the plot.

        min_sample = group.min_sample
        max_sample = group.max_sample
        
        if min_sample < self.bin_interval[0]: 
            min_sample = self.bin_interval[0]
        if max_sample > self.bin_interval[1]:
            max_sample = self.bin_interval[1]
        
        min_dm = group.min_dm
        max_dm = group.max_dm
        
        if max_dm > self.dm_interval[1]: max_dm = self.dm_interval[1]
        if min_dm < self.dm_interval[0]: min_dm = self.dm_interval[0]

        try:
            link = getattr(group, 'link')
        except AttributeError:
            pass
        else:
            root_element = ET.SubElement(root_element, 'a')
            root_element.set('xlink:href', link)
        # Draw bounding box.
        box = ET.SubElement(root_element, 'rect')
        box.set('stroke', 'black')
        # To make the bounding box clickable fill the box completely with a
        # transparent color (otherwise only the edge would be clickable).
        box.set('fill', 'white')
        box.set('fill-opacity', '0.0')
        box.set('x', '%.2f' % self.x_transform(min_sample))
        box.set('y', '%.2f' % self.y_transform(max_dm))
        box.set('width', '%.2f' % (self.x_transform(max_sample) - 
            self.x_transform(min_sample)))
        box.set('height', '%.2f' % (self.y_transform(min_dm) - 
            self.y_transform(max_dm)))

    def draw(self, root_element):
        '''
        Draw the GroupedPlot. (Single pulse candidates on the time DM plane.)
        '''
        # Draw gray lines separating the different downsamplings. First find 
        # where the changes in downsampling are:
        dms = self.presto_dir.dm2file.keys()
        dms.sort()
        changes_at_dm = []
        dsf = self.presto_dir.dm2downsample[0]
        for dm in dms:
            if self.presto_dir.dm2downsample[dm] > dsf:
                changes_at_dm.append(dm)
                dsf = self.presto_dir.dm2downsample[dm]
        # Now draw dividing lines between the downsampling factors.
        # TODO : add text describing the downsample factor.
        for dm in changes_at_dm:
            if self.dm_interval[0] <= dm <= self.dm_interval[1]:
                l = ET.SubElement(root_element, 'line')
                l.set('x1', '%.2f' % 
                    self.x_transform(self.divider_bin_interval[0]))
                l.set('y1', '%.2f' % self.y_transform(dm))
                l.set('x2', '%.2f' % 
                    self.x_transform(self.divider_bin_interval[1]))
                l.set('y2', '%.2f' % self.y_transform(dm))
                l.set('stroke', 'gray')
        # Draw the rest (first the individual Candidates) ...
        for g in self.groups:
            self.draw_group_members(root_element, g)
        # ... and then the bounding boxes on top of that.
        for g in self.groups:
            self.draw_group_box(root_element, g)
        n_candidates = sum((len(x.candidates) for x in self.groups))


class GroupedPlot(base.Graph2d):
    '''
    GroupedPlot shows single pulse candidates on time DM plane.
    
    The data for this plot is a list of CandidateGroup instances, each of which
    has a bounding box on time DM plane, which is drawn. The single pulse 
    candidates (Candidate instances) are drawn as little bars in a color that 
    corresponds to their width (downfact attribute) in time and length 
    corresponding to their detection signal to noise (sigma attribute). It is 
    possible to link the CandidateGroup bounding box to another plot by setting
    a .link attribute on the CandidateGroup --- that link target is then used by
    the GroupedPlot's drawing code to make a clickable SVG link to it.

    Drawing code for GroupedPlot is contained in the GroupedPlotArea class.
    '''
    def __init__(self, presto_dir, groups, bin_interval, dm_interval,
        *args, **kwargs):
        super(GroupedPlot, self).__init__()

        bin_width = presto_dir.dm2metadata[0].bin_width
        stretched_dm_interval = ranges.stretch_input_range(dm_interval, 1.05)
        stretched_bin_interval = ranges.stretch_input_range(bin_interval, 1.05)
        
        self.set_dimensions(x_offset = 0, y_offset = 0, width = 800, height = 500)
        self.set_left_axis(interval = stretched_dm_interval, label = 'DM (pc cm^-3)')
        self.set_right_axis(interval = stretched_dm_interval)

        self.set_bottom_axis(interval = stretched_bin_interval)#, label = 'Bins')
        self.set_top_axis(interval = [bin_width * stretched_bin_interval[0], 
            bin_width * stretched_bin_interval[1]], label = 'Time (s)')
        
        # TODO : check logic here - we have some problems right now.
        g2 = []
        for g in groups:
            if g.max_sample >= bin_interval[0] and g.min_sample <= bin_interval[1]:
                if g.max_dm  >= dm_interval[0] and g.min_dm <= dm_interval[1]:
                    g2.append(g)
        
        # Set the correct payload (i.e. plotting code):
        self.set_payload(GroupedPlotArea(presto_dir, g2, stretched_bin_interval,
            bin_width, stretched_dm_interval, bin_interval))

# ------------------------------------------------------------------------------
# -- Vertical color bar (for legends) ------------------------------------------

class VerticalColorGradientLegendArea(base.PlotArea2d):
    '''
    Plotting code for VerticalColorGradientLegend --- use that class instead.
    '''
    def __init__(self, colormap):
        super(VerticalColorGradientLegendArea, self).__init__()
        self.colormap = colormap
        self.set_y_interval(interval = colormap.input_range)
        self.set_x_interval(interval = [0, 1])
    
    def draw(self, root_element):
        '''Draw a vertical color gradient.'''
        n_steps = 100
        y_range = self.colormap.input_range[1] - self.colormap.input_range[0]
        y_step = y_range / n_steps 
        for i in range(n_steps):
            y_begin = self.colormap.input_range[0] + i * y_step
            y_end = self.colormap.input_range[0] + (i+1) * y_step
            color = self.colormap(y_begin)
            
            bar = ET.SubElement(root_element, 'rect',
                x = '%.2f' % self.x_transform(0),
                width = '%.2f' % (self.x_transform(1) - self.x_transform(0)),
                y = '%.2f' % self.y_transform(y_end),
                height = '%.2f' % (self.y_transform(y_begin) - 
                    self.y_transform(y_end)), 
                fill = self.colormap(y_begin),
            )


class VerticalColorGradientLegend(base.Graph2d):
    '''
    Draw a vertical gradient with its values along side as a legend.
    
    Note: current implementation does not deal with logarithmic axes.
    '''
    def __init__(self, colormap):
        super(VerticalColorGradientLegend, self).__init__()

        self.set_right_axis(interval = colormap.input_range, label = 'value')
        self.payload = VerticalColorGradientLegendArea(colormap)

# ------------------------------------------------------------------------------
# -- Boxed text SVG link -------------------------------------------------------

class SVGLink(object):
    '''Class that draws a linkable box with text on a SVG canvas.'''
    def __init__(self, href, text):
        self.x_offset = 0
        self.y_offset = 0
        self.width = 100
        self.height = 30
        
        self.href = href
        self.text = text

    def set_dimensions(self, *args, **kwargs):
        '''Set the dimensions of the TextBox.
        
        Note : text might overflow.'''
        self.x_offset = kwargs.get('x_offset', self.x_offset)
        self.y_offset = kwargs.get('y_offset', self.y_offset)
        self.width = kwargs.get('width', self.width)
        self.height = kwargs.get('height', self.height)
    
    def draw(self, root_element):
        '''Draw SVGLink on SVG canvas.'''
        a = ET.SubElement(root_element, 'a')
        a.set('xlink:href', self.href)
        
        if self.text:
            label = ET.SubElement(a, 'text')
            label.set('font-size', '15')
            label.set('text-anchor', 'middle')
            label.set('x', '%.2f' % ((self.width / 2) + self.x_offset))
            label.set('y', '%.2f' % ((self.height / 2) + self.y_offset))
            label.set('fill', 'blue')
            label.text = escape(self.text)
        
        box = ET.SubElement(a, 'rect',
            fill = 'white',
            stroke = 'blue',
            x = '%.2f' % self.x_offset,
            y = '%.2f' % self.y_offset,
            width = '%.2f' % self.width,
            height = '%.2f' % self.height,
        )
        box.set('fill-opacity', '0')

# ------------------------------------------------------------------------------
# -- Boxed SVG text ------------------------------------------------------------

class TextBox(object):
    '''Class that draws a box with text on a SVG canvas.'''
    def __init__(self, text):
        self.x_offset = 0
        self.y_offset = 0
        self.width = 100
        self.height = 30
        
        self.text = text

    def set_dimensions(self, *args, **kwargs):
        '''Set the dimensions of the TextBox.
        
        Note : text might overflow.'''
        self.x_offset = kwargs.get('x_offset', self.x_offset)
        self.y_offset = kwargs.get('y_offset', self.y_offset)
        self.width = kwargs.get('width', self.width)
        self.height = kwargs.get('height', self.height)
    
    def draw(self, root_element):
        '''Draw the TextBox on the CANVAS canvas.'''
        label = ET.SubElement(root_element, 'text')
        label.set('font-size', '15')
        label.set('text-anchor', 'left')
        label.set('x', '%.2f' % (self.x_offset + 15))
        label.set('y', '%.2f' % ((self.height / 2) + self.y_offset))
        label.text = escape(self.text)
        
        box = ET.SubElement(root_element, 'rect',
            fill = 'white',
            stroke = 'black',
            x = '%.2f' % self.x_offset,
            y = '%.2f' % self.y_offset,
            width = '%.2f' % self.width,
            height = '%.2f' % self.height,
        )
        box.set('fill-opacity', '0')        

# ------------------------------------------------------------------------------
# -- Plot of a candidate groups signal-to-noise versus dispersion measure ------

def no_doubles(candidate_group):
    '''
    Remove candidates with same DM from CandidateGroup's SNR versus DM curve.
    
    Note : helper function used by CandidateGroupSNRvsDMArea instances. For more
    information see CandidateGroupSNRvsDM class.
    '''
    tmp = {}
    for candidate in candidate_group.candidates:
        try:
            other = tmp[candidate.dm]
        except KeyError:
            tmp[candidate.dm] = candidate
        else:
            if candidate.sigma > other.sigma:
                tmp[candidate.dm] = candidate
    return [c for c in tmp.itervalues()]


class CandidateGroupSNRvsDMArea(base.PlotArea2d):
    '''CandidateGroupSNRvsDM helper class.'''
    def __init__(self, candidate_group):
        super(CandidateGroupSNRvsDMArea, self).__init__()
        filtered_candidates = no_doubles(candidate_group)
        filtered_candidates.sort(key = lambda c : c.dm)
        self.data = [(c.dm, c.sigma) for c in filtered_candidates]

    def draw(self, root_element):
        '''Draw CandidateGroup SNR versus DM curve on root_element.'''
        for i in range(len(self.data) -1):
            x1, y1 = self.data[i]
            x2, y2 = self.data[i+1]
            ET.SubElement(root_element, 'line',
                x1 = '%.2f' % self.x_transform(x1),
                y1 = '%.2f' % self.y_transform(y1), 
                x2 = '%.2f' % self.x_transform(x2),
                y2 = '%.2f' % self.y_transform(y2),
                stroke = 'gray'
            )


class CandidateGroupSNRvsDM(base.Graph2d):
    '''Scatter plot of SNR versus DM for a group of candidates.'''
    def __init__(self, candidate_group):
        # TODO : consider using generator expression ?
        super(CandidateGroupSNRvsDM, self).__init__()
        snr_interval = (min((c.sigma for c in candidate_group.candidates)), 
            max((c.sigma for c in candidate_group.candidates)))
        dm_interval = (min((c.dm for c in candidate_group.candidates)), 
            max((c.dm for c in candidate_group.candidates)))
        self.set_left_axis(interval = snr_interval, label = 'SNR')
        self.set_right_axis(interval = snr_interval)
        self.set_top_axis(interval = dm_interval)
        self.set_bottom_axis(interval = dm_interval, label = 'DM (pc cm^-3)')
        
        tmp = CandidateGroupSNRvsDMArea(candidate_group)
        dm_width = dm_interval[1] - dm_interval[0]
        snr_width = snr_interval[1] - snr_interval[0]
        tmp.set_x_interval(interval = (dm_interval[0] - 0.1 * dm_width, 
            dm_interval[1] + 0.1 * dm_width))
        tmp.set_y_interval(interval = (snr_interval[0] - 0.1 * snr_width, 
            snr_interval[1] + 0.1 * snr_width))
        self.set_payload(tmp)

# ------------------------------------------------------------------------------
# -- 

class DMHistogram(base.BaseHistogramV):
    def __init__(self, presto_dir, candidates, dm_interval, sample_interval):
        bins_as_dict = {}
        dms = set()
        for dm in presto_dir.dm2file.keys():
            if dm_interval[0] <= dm <= dm_interval[1]:
                dms.add(dm)
        for k in dms:
            bins_as_dict[k] = 0
        for candidate in candidates:
            # Add error checking here (in case someone was stupid enough to call
            # this function with non matching dms and candidates.) (TODO)
            if not candidate.dm in dms:
                continue
            if not candidate.sample * presto_dir.dm2downsample[candidate.dm] >= sample_interval[0]:
                continue
            if not candidate.sample * presto_dir.dm2downsample[candidate.dm] <= sample_interval[1]:
                continue
            bins_as_dict[candidate.dm] += 1
        dms = list(dms)
        dms.sort()
        
        # The following slightly ugly loop creates the bins datastructure that
        # BaseHistogram expects. There are some assumptions made about the width
        # of each bin in DM.
        # TODO : add some checking of the number of bins (should be at least 2
        # to not crash on the following loop).
        for i, value in enumerate(dms):
            if i == 0:
                # First bin is taken to be as wide as the distance in DM between
                # the first and the second bin. 
                w = dms[1] - dms[0]
                l = [[dms[0] - w / 2, dms[0] + w / 2, bins_as_dict[dms[0]]]]
            elif i == len(dms) - 1:
                # Last bin is taken to be as wide as the distance in DM between
                # the last and the second to last bin. 
                w = dms[-1] - dms[-2]
                l.append([dms[-1] - w / 2,
                    dms[-1] + w/2, bins_as_dict[dms[-1]]])
            else:
                l.append([(dms[i] + dms[i-1])/2, 
                    (dms[i] + dms[i+1])/2, bins_as_dict[dms[i]]])
            
        super(DMHistogram, self).__init__(l)

class GroupedDMHistogram(DMHistogram):
    def __init__(self, presto_dir, groups, dm_interval, sample_interval):
        candidates = []
        for g in groups:
            candidates.extend(g.candidates)
        super(GroupedDMHistogram, self).__init__(presto_dir, candidates, dm_interval, sample_interval)
        self.set_bottom_axis(label = 'N detections')
        self.set_left_axis(label=None)

# ------------------------------------------------------------------------------
# -- 

class SNRvsDMHistogramArea(base.BaseHistogramV):
    def __init__(self, presto_dir, candidates, dm_interval, sample_interval):
        bins_as_dict = {}
        dms = set()
        for dm in presto_dir.dm2file.keys():
            if dm_interval[0] <= dm <= dm_interval[1]:
                dms.add(dm)
        for k in dms:
            bins_as_dict[k] = 0
        for candidate in candidates:
            # Add error checking here (in case someone was stupid enough to call
            # this function with non matching dms and candidates.) (TODO)
            if not candidate.dm in dms:
                continue
            if not candidate.sample * presto_dir.dm2downsample[candidate.dm] >= sample_interval[0]:
                continue
            if not candidate.sample * presto_dir.dm2downsample[candidate.dm] <= sample_interval[1]:
                continue
            bins_as_dict[candidate.dm] += candidate.sigma
        dms = list(dms)
        dms.sort()
        
        # The following slightly ugly loop creates the bins datastructure that
        # BaseHistogram expects. There are some assumptions made about the width
        # of each bin in DM.
        # TODO : add some checking of the number of bins (should be at least 2
        # to not crash on the following loop).
        for i, value in enumerate(dms):
            if i == 0:
                # First bin is taken to be as wide as the distance in DM between
                # the first and the second bin. 
                w = dms[1] - dms[0]
                l = [[dms[0] - w / 2, dms[0] + w / 2, bins_as_dict[dms[0]]]]
            elif i == len(dms) - 1:
                # Last bin is taken to be as wide as the distance in DM between
                # the last and the second to last bin. 
                w = dms[-1] - dms[-2]
                l.append([dms[-1] - w / 2,
                    dms[-1] + w/2, bins_as_dict[dms[-1]]])
            else:
                l.append([(dms[i] + dms[i-1])/2, 
                    (dms[i] + dms[i+1])/2, bins_as_dict[dms[i]]])
            
        super(SNRvsDMHistogramArea, self).__init__(l)

class SNRvsDMHistogram(SNRvsDMHistogramArea):
    def __init__(self, presto_dir, groups, dm_interval, sample_interval):
        candidates = []
        for g in groups:
            candidates.extend(g.candidates)
        super(SNRvsDMHistogram, self).__init__(presto_dir, candidates, dm_interval, sample_interval)
        self.set_bottom_axis(label = 'Total SNR')
        self.set_left_axis(label = None)

        
# ------------------------------------------------------------------------------
# -- 

class CandidateSNRScatterPlotArea(base.PlotArea2d):
    '''Helper class for CandidateSNRScatterPlot.'''
    def __init__(self, candidates):
        super(CandidateSNRScatterPlotArea, self).__init__()
        self.candidates = candidates
        
    def draw(self, root_element):
        for candidate in self.candidates:
            c = ET.SubElement(root_element, 'circle')
            c.set('cx', '%.2f' % self.x_transform(candidate.dm))
            c.set('cy', '%.2f' % self.y_transform(candidate.sigma))
            c.set('r', '2')
            c.set('fill', 'black')
        

class CandidateSNRScatterPlot(base.Graph2d):
    def __init__(self, groups, *args, **kwargs):
        super(CandidateSNRScatterPlot, self).__init__()

        candidates = []
        for g in groups:
            candidates.extend(g.candidates)

        # TODO : FIX HARDCODED SNR RANGE
        snr_interval = (min(c.sigma for c in candidates), max(c.sigma for c in candidates))
        self.set_left_axis(label = 'SNR', interval = snr_interval)
        self.set_right_axis(interval = snr_interval)
        # TODO : FIX HARDCODED DM RANGE
        dm_interval = (min(c.dm for c in candidates), max(c.dm for c in candidates))
        self.set_bottom_axis(label = 'DM', interval = dm_interval)
        self.set_top_axis(interval = dm_interval)
        
        g = CandidateSNRScatterPlotArea(candidates)
        g.set_x_interval(interval = dm_interval)
        g.set_y_interval(interval = snr_interval)
        self.set_payload(g)


class GroupedSNRPlot(CandidateSNRScatterPlot):
    # Adapts the ClassicCandidateSNRPLot for use with CandidateGroups
    def __init__(self, groups, *args, **kwargs):
        candidates = []
        for g in groups:
            candidates.extend(g.candidates)
        super(GroupedSNRPlot, self).__init__(candidates, *args, **kwargs)


# ------------------------------------------------------------------------------
# -- Timeseries plots (to plot chunks of .dat files) ---------------------------

class TimeSeriesPlotArea(base.PlotArea2d):
    def __init__(self, array, stretch_x, stretch_y):
        '''Plotting code for TimeSeriesPlot class, use that in stead.'''
        super(TimeSeriesPlotArea, self).__init__()
        self.array = array
        
        # be sure to stretch the plotted ranges by the same amount as the axes
        # were stretched
        tmp = ranges.stretch_input_range((0, len(self.array) - 1), stretch_x)
        self.set_x_interval(interval = tmp)
        
        tmp = ranges.stretch_input_range((min(array),  max(array)), stretch_y)
        self.set_y_interval(interval = tmp)
        
    def draw(self, root_element):
        '''Draw timeseries on SVG element root_element.'''
        for i in range(len(self.array) -1):
            ET.SubElement(root_element, 'line',
                x1 = '%.2f' % self.x_transform(i),
                x2 = '%.2f' % self.x_transform(i + 1), 
                y1 = '%.2f' % self.y_transform(self.array[i]),
                y2 = '%.2f' % self.y_transform(self.array[i + 1]),
                stroke = 'gray'
            )

class TimeSeriesPlot(base.Graph2d):
    def __init__(self, array, min_sample, max_sample, bin_width):
        '''
        Timeseries plot class.
        
        Given an array of 'y values' (the array parameter), the plot will run
        from min_sample to max_sample and each bin has a width of bin_width.
        This class uses TimeSeriesPlotArea class instances for plotting.
        '''
        # Factors by which to stretch the ranges of plotted values a bit (to 
        # give the plots some breathing room); purely for looks.
        stretch_x = 1.05
        stretch_y = 1.1
        
        super(TimeSeriesPlot, self).__init__()
        self.set_dimensions(width = 600, height = 400)
        self.bin_width = bin_width

        # Set the vertical axes, and stretch the plotted ranges a bit.
        value_interval = (min(array), max(array))
        value_interval = ranges.stretch_input_range(value_interval, stretch_y)
        self.set_left_axis(interval = value_interval, label = 'Raw value')
        self.set_right_axis(interval = value_interval)

        # Set up and stretch the bottom axis a bit
        sample_interval = (min_sample, max_sample)
        sample_interval = ranges.stretch_input_range(sample_interval, stretch_x)
        self.set_bottom_axis(interval = sample_interval, label = 'Bins')

        # Have the top axis show time
        time_interval = (sample_interval[0] * bin_width, 
            sample_interval[1] * bin_width)
        self.set_top_axis(interval = time_interval, label = 'Time (s)')

        self.payload = TimeSeriesPlotArea(array, stretch_x, stretch_y)

# ------------------------------------------------------------------------------
# -- Graph of SNR summed over DM -----------------------------------------------

class SummedSNR(base.BaseHistogram):
    def __init__(self, presto_dir, groups, sample_interval, dm_interval, *args, **kwargs):
        min_sample, max_sample = sample_interval
        stretch_x = 1.05
        snr_bins = [0 for i in range(max_sample - min_sample + 1)]

        dms = set()
        for dm in presto_dir.dm2file.keys():
            if dm_interval[0] <= dm <= dm_interval[1]:
                dms.add(dm)
        
        
        for g in groups:
            for c in g.candidates:
                if not c.dm in dms:
                    continue
                # think about downsampling (presto_dir.dm2downsample and c.downfact)
                # think about samples (c.sample)
                # think about snr (c.sigma)
                # think about delay compensation (presto_dir.dm2delay)
                # Do all calculations on undownsampled data (like DM = 0 data)
                
                first_sample = (c.sample + presto_dir.dm2delay[c.dm]) * presto_dir.dm2downsample[c.dm]
                last_sample = (c.sample + presto_dir.dm2delay[c.dm] + c.downfact) * presto_dir.dm2downsample[c.dm]
                
                n_bins = last_sample - first_sample 
                for idx in range(first_sample, last_sample):
                    if min_sample <= idx <= max_sample:
                        snr_bins[idx - min_sample] += c.sigma / n_bins
        bins = []
        for i, snr in enumerate(snr_bins):
            bin_width = presto_dir.dm2metadata[0].bin_width
            bin = (i * bin_width, (i + 1) * bin_width, snr_bins[i])
            bins.append(bin)

        super(SummedSNR, self).__init__(bins, *args, **kwargs)
        stretched_bin_interval = ranges.stretch_input_range((min_sample, max_sample), stretch_x)
        self.set_bottom_axis(label = 'Bins', interval = stretched_bin_interval)
        self.set_top_axis(label = None, interval = stretched_bin_interval)
        self.set_left_axis(label = 'Value', interval = ranges.stretch_input_range((0, max(snr_bins)), 1.05))

class SummedSNROneDownfact(base.BaseHistogram):
    def __init__(self, presto_dir, groups, min_sample, max_sample, dm_interval, downfact, *args, **kwargs):
        # TODO check this code carefully for off-by-ones
        stretch_x = 1.05
        snr_bins = [0 for i in range(max_sample - min_sample + 1)]

        dms = set()
        for dm in presto_dir.dm2file.keys():
            if dm_interval[0] <= dm <= dm_interval[1]:
                dms.add(dm)
        
        
        for g in groups:
            for c in g.candidates:
                if not c.dm in dms:
                    continue
                if not c.downfact == downfact:
                    continue
                # think about downsampling (presto_dir.dm2downsample and c.downfact)
                # think about samples (c.sample)
                # think about snr (c.sigma)
                # think about delay compensation (presto_dir.dm2delay)
                # Do all calculations on undownsampled data (like DM = 0 data)
                
                first_sample = (c.sample + presto_dir.dm2delay[c.dm]) * presto_dir.dm2downsample[c.dm]
                last_sample = (c.sample + presto_dir.dm2delay[c.dm] + c.downfact) * presto_dir.dm2downsample[c.dm]
                
                for idx in range(first_sample, last_sample):
                    if min_sample <= idx <= max_sample:
                        snr_bins[idx - min_sample] += c.sigma
                
        bins = []
        for i, snr in enumerate(snr_bins):
            bin_width = presto_dir.dm2metadata[0].bin_width
            bin = (i * bin_width, (i + 1) * bin_width, snr_bins[i])
            bins.append(bin)

        super(SummedSNROneDownfact, self).__init__(bins, *args, **kwargs)
        stretched_bin_interval = ranges.stretch_input_range((min_sample, max_sample), stretch_x)
        self.set_bottom_axis(label = 'Bins', interval = stretched_bin_interval)
        self.set_top_axis(label = None, interval = stretched_bin_interval)
        self.set_left_axis(label = 'Value', interval = ranges.stretch_input_range((0, max(snr_bins)), 1.05))

# ------------------------------------------------------------------------------
# -- DM Pointer clas -----------------------------------------------------------

class DMPointerVArea(base.PlotArea2d):
    def __init__(self, dm_interval, dm_pointers):
        super(DMPointerVArea, self).__init__()
        self.dm_interval = dm_interval
        self.dm_pointers = dm_pointers

        self.set_x_interval(interval = (0, 1))
        self.set_y_interval(interval = dm_interval)

    def draw(self, root_element):
        for dm in self.dm_pointers:
            if self.dm_interval[0] <= dm <= self.dm_interval:
                pointer = ET.SubElement(root_element, 'polygon')
                vertices = [
                    (self.x_transform(0)+5, self.y_transform(dm)),
                    (self.x_transform(0)+15, self.y_transform(dm)+10),
                    (self.x_transform(0)+15, self.y_transform(dm)-10),
                ]
                pointer.set('points', ''.join('%.2f,%.2f ' % (x, y) for x, y in vertices))
                pointer.set('stroke', 'black')
                pointer.set('fill', 'yellow')
                pointer.set('class', 'POINTER')

class DMPointerV(base.Graph2d):
    """Draw pointers to interesting DMs."""
    def __init__(self, dm_interval, dm_pointers = None, *args, **kwargs):
        super(DMPointerV, self).__init__()
        if not dm_pointers:
            dm_pointers = []
        stretch_y = 1.05        
        dm_interval = ranges.stretch_input_range(dm_interval, stretch_y)
        g = DMPointerVArea(dm_interval, dm_pointers)
        self.set_payload(g)



if __name__ == '__main__':
    print __doc__
    