# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains some functions that deal with input_ranges in of plots.
'''
from __future__ import division
import math

def make_input_range_safe(input_range):
    '''
    Given a input_range returns a safe input_range.

    Fixes the case where input_range has input_range[0] == input_range[1] or
    where input_range[0] < input_range[1].

    >>> from ssps.plotting.svg.base import make_input_range_safe
    >>> make_input_range_safe((0,0))
    (-0.10000000000000001, 0.10000000000000001)
    >>> make_input_range_safe((1,1))
    (0.90000000000000002, 1.1000000000000001)
    >>> make_input_range_safe((1, 0))
    (0, 1)
    '''
    # TODO : see whether the doctest should be adapted to allow for small 
    # discrepancies because of rounding of python floats.
    if input_range[0] == input_range[1]:
        if input_range[0] == 0:
            # Can't take the log10 of zero (so it is a special case):
            input_range = (-0.1, 0.1)
        else:
            # Set input_range to appropriate values:
            p = int(math.log10(abs(input_range[0])))
            delta = pow(10, p - 1)
            input_range = (input_range[0] - delta, input_range[1] + delta)
    elif input_range[0] > input_range[1]:
        input_range = (input_range[1], input_range[0])
    else:
        # The default case:
        input_range = input_range
    return input_range

def stretch_input_range(input_range, factor = 1.1):
    input_range = make_input_range_safe(input_range)
    tmp = (input_range[1] - input_range[0]) * factor
    return (input_range[1] - tmp, input_range[0] + tmp)
    