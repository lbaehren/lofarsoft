# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group,
# 2009-2010.
"""
This module contains the single pulse candidate grouping algorithm. 
"""

from __future__ import division

import os
import sys
import re
import time

from ssps.presto.files import singlepulse
from ssps.presto.files import inf
from ssps.settings import DM_FUDGE


# ------------------------------------------------------------------------------
# -- Two grouping algorithm implementations ------------------------------------


def group_sequentially(candidate_groups_tmp, candidate_groups_in):
    '''
    Candidate grouping algorithm that takes two lists of CandidateGroups.
    
    This function returns a list of CandidateGroups and is function is used 
    to perform grouping on a per DM basis.

    Note: assumption is that the first list, candidate_groups_tmp, is properly
    grouped already (i.e. no overlaps remaining between its CandidateGroups). 
    The other list just needs to be a list of CandidateGroups.
    '''
    # Sort incoming CandidateGroups by time (otherwise there is no guarantee 
    # that it is safe during grouping to ignore CandidateGroups that have a much
    # earlier time than the CandidateGroup under consideration).
    candidate_groups_in.sort(key = lambda c : c.min_sample)
    candidate_groups_tmp.sort(key = lambda c : c.min_sample)
    
    # Output list of CandidateGroups:
    candidate_groups_out = []

    while candidate_groups_in:
        cg1 = candidate_groups_in.pop(0)
        # CandidateGroups that intersect cg1 need to be merged with it,
        # their indices go onto the to_merge list.
        to_merge = []
        
        # The new CandidateGroup cg1 needs to be inserted into the 
        # candidate_groups_tmp list somewhere. The following 2 variables keep
        # track of where and whether the position for inserting is found.
        insert_at = 0
        insertion_point_found = False
        
        for i in range(len(candidate_groups_tmp)):
            # Check for intersection between cg1 and the elements of the 
            # candidate_groups_tmp list.
            if cg1.intersects(candidate_groups_tmp[i]):
                to_merge.append(i)

            # Keep track of where the new CandidateGroup (cg1) needs to be
            # inserted in such a way as to keep candidate_groups_tmp sorted for
            # min_sample.
            if candidate_groups_tmp[i].min_sample > cg1.min_sample:
                if insertion_point_found == False:
                    # We just found the first candidate group that comes later
                    # than cg1. So cg1 needs to be inserted in front of it.
                    insert_at = i
                    insertion_point_found = True
            
            # The following check is only safe if candidate_groups_tmp is kept 
            # in sorted order always. This check saves a lot of 
            # CandidateGroup.instersects calls (which are time consuming).
            if cg1.max_sample < candidate_groups_tmp[i].min_sample:
                break
                                
        # Merge all the intersected groups with the new candidate and
        # let the old unmerged group go out of scope.
        to_merge.reverse()
        for i in to_merge:
            cg2 = candidate_groups_tmp.pop(i)
            cg1.merge(cg2) # cg2 goes out of scope ... (eventually)
            
            # The following corrects for the case where a candidate group is 
            # removed from the list before the position that was found as the
            # insertion point for the new candidate group (cg1).
            if i < insert_at: insert_at = i

        # Move the new CandidateGroup to candidate_groups_tmp. If an 
        # insertion point was found, move cg1 there. Otherwise append cg1.
        if insertion_point_found:
            candidate_groups_tmp.insert(insert_at, cg1)
        else:
            candidate_groups_tmp.append(cg1)

        # Find all the 'finished' candidate groups, collect their indices
        # on the to_freeze list. Finished in this context means there is no
        # way that they can change anymore.
        to_freeze = []
        for i in range(len(candidate_groups_tmp)):
            # The following is only safe when the incoming data is 
            # properly sorted!
            if candidate_groups_tmp[i].max_sample < cg1.min_sample:
                to_freeze.append(i)
        to_freeze.reverse()

        # Move the finished candidate groups to the output list.
        for i in to_freeze:
            cg3 = candidate_groups_tmp.pop(i)
            candidate_groups_out.append(cg3)    

    # Add any groups still on the temporary list to the output list as 
    # well.
    candidate_groups_out.extend(candidate_groups_tmp)
    return candidate_groups_out


def group_in_one_go(candidate_groups_in):
    '''
    Grouping algorithm working on CandidateGroup instances. 
    
    This function takes a list of CandidateGroup instances and returns a list of
    CandidateGroup instances after grouping. This function is used to group 
    the list of CandidateGroup instances candidate_groups_in in 1 go (not on a 
    per DM basis, for that see the group_sequentially function in this module).
    '''
    # Sorting for min_sample is important since it allows me to
    # later make assumptions about the min_sample of following 
    # candidate groups. 
    candidate_groups_in.sort(key = lambda c : c.min_sample)
    candidate_groups_tmp.sort(key = lambda c : c.min_sample)

    # Temporary list of CandidateGroup instances whilst the algorithm is running:
    candidate_groups_tmp = []
    # Output list of CandidateGroups:
    candidate_groups_out = []

    while candidate_groups_in:
        cg1 = candidate_groups_in.pop(0)
        # CandidateGroup s that intersect cg1 need to be merged with it,
        # their indices go onto the to_merge list.
        to_merge = []
        for i in range(len(candidate_groups_tmp)):
            if cg1.intersects(candidate_groups_tmp[i]):
                to_merge.append(i)
            # The following check is only safe if candidate_groups_tmp is kept 
            # in sorted order always. (Sorted for min_sample.)
            if cg1.max_sample < candidate_groups_tmp[i].min_sample:
                break
        to_merge.reverse()
        # Merge all the intersected groups with the new candidate and
        # let the old unmerged group go out of scope.
        for i in to_merge:
            cg2 = candidate_groups_tmp.pop(i)
            cg1.merge(cg2) # cg2 goes out of scope ... (eventually)

        # Move the new CandidateGroup to the list of candidate groups.
        # By inserting at the position of the first CandidateGroup that was
        # merged, the list remains sorted for min_sample - thus allowing me
        candidate_groups_tmp.insert(to_merge[-1], cg1)
        # Find all the finished candidate groups, collect their indices
        # on the to_freeze list.
        to_freeze = []
        for i in range(len(candidate_groups_tmp)):
            # The following is only safe when the incoming data is 
            # properly sorted!
            if candidate_groups_tmp[i].max_sample < cg1.min_sample:
                to_freeze.append(i)
        to_freeze.reverse()

        # Move the finished candidate groups to the output list.
        for i in to_freeze:
            cg3 = candidate_groups_tmp.pop(i)
            candidate_groups_out.append(cg3)

    # Add any groups still on the temporary list to the output list as 
    # well.
    candidate_groups_out.extend(candidate_groups_tmp)
    return candidate_groups_out


def group_presto_data(presto_dir, DMs_adjacent = 16, delta_sample = 16, 
    dms = None):
    '''
    Find groups of single pulse candidates in a PRESTO data set.
    
    This function takes a PRESTODir instance (describing the data set under 
    consideration), an integer (DMs_adjacent) describing how many trial DMs and 
    an integer (delta_sample) describing the number of samples (in time) next to
    a CandidateGroup should still be considered overlapping. The dms parameter 
    let's the user specify only a subset of all trial DMs to be used.
    
    Note : this function is meant to be used on PRESTO data that has a DM = 0
    trial DM and intact metadata.
    '''
    # Hard coded margins around a candidate
    delta_dm = 0.2
    if not delta_sample:
        delta_sample = 16
    
    # Look at which DMs should be grouped, defaults to grouping everything. If 
    # you only want part of the DM trials to be used, specify them as a list of
    # floats for the dms parameter.
    if not dms:
        dms = presto_dir.dm2file.keys()
    dms.sort()
    # Grab the length of the timeseries at zero dm to be able to calculate the
    # downsample factors for all the other DM trials:
    
    singlepulse_file = presto_dir.get_filename(0, 'singlepulse')
    inf_file = presto_dir.get_filename(0, 'inf')
    metadata = inf.inf_reader(inf_file)
    assert metadata.dm == 0
    n_samples_zero_dm = metadata.n_bins

    # Initialize the output list of CandidateGroups:
    busy = []
    frozen = []
    old_downsample_factor = 1
    # Run grouping algorithm per DM trial:
    for i, dm in enumerate(dms):
        # Read candidates and metadata for the current DM trial:
        singlepulse_file = presto_dir.get_filename(dm, 'singlepulse')

        candidates = singlepulse.singlepulse_reader(singlepulse_file)
        metadata = presto_dir.dm2metadata[dm]

        # Find the downsample factor for the current DM trial:
        downsample_factor = presto_dir.dm2downsample[dm]
        candidate_groups = []
        n_dm_trials = len(dms)
        # Set the size in DM of the area that gets searched for other Candidates
        if DMs_adjacent:
            i1 = i - DMs_adjacent 
            i2 = i + DMs_adjacent
            if i1 < 0: i1 = 0
            if i2 >= n_dm_trials: i2 = -1
            min_dm = dms[i1] - DM_FUDGE
            max_dm = dms[i2] + DM_FUDGE
        else:
            min_dm = dm - delta_dm - DM_FUDGE
            max_dm = dm + delta_dm + DM_FUDGE
        # Make CandidateGroups out of the Candidates for this DM:
        for c in candidates:
            min_sample = c.sample * downsample_factor - delta_sample + \
                presto_dir.dm2delay[dm]
            max_sample = (c.sample + c.downfact) * downsample_factor - 1 + \
                delta_sample + presto_dir.dm2delay[dm]
            candidate_groups.append(CandidateGroup(c, min_sample, max_sample, 
                min_dm, max_dm))

        # Remove groups that cannot match DM wise. (As a speed up, since these
        # groups need not be checked for intersections anymore, regardless of
        # the time that they occurr at.
        cant_match = []
        for i in range(len(busy)):
            if busy[i].max_dm < min_dm: cant_match.append(i)
        cant_match.reverse()
        for i in cant_match:
            cg = busy.pop(i)
            frozen.append(cg)

        # Call the grouping function:        
        busy = group_sequentially(busy, candidate_groups)
        old_downsample_factor = downsample_factor

    frozen.extend(busy)
    return frozen


# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------

class CandidateGroup(object):
    '''
    This class represents a group of singlepulse detections. 

    >>> from ssps.presto.files.singlepulse import Candidate
    >>> from ssps.group.groups import CandidateGroup
    >>> cg1 = CandidateGroup(Candidate(0, 0, 10, 10, 1), 9, 11, 0, 1)
    >>> cg2 = CandidateGroup(Candidate(0, 0, 11, 11, 1), 10, 12, 0, 1)
    >>> cg3 = CandidateGroup(Candidate(0, 0, 14, 14, 1), 13, 15, 0, 1)

    CandidateGroup instances can be checked for overlap in the time-DM plane. 
    (There are several member functions that perform overlap tests, use the 
    .intersects(self, other) method).
    
    >>> cg1.intersects(cg2)
    True
    >>> cg2.intersects(cg1)
    True
    >>> cg1.intersects(cg3)
    False
    
    To add extra Candidate instances to a CandidateGroup one needs to create 
    a CandidateGroup for that instance and merge it.
    
    >>> len(cg1.candidates)
    1
    >>> cg1.merge(cg3)
    >>> len(cg1.candidates)
    2
    '''
    def __init__(self, candidate, min_sample, max_sample, min_dm, max_dm):
        """
        Create a CandidateGroup and set its bounding box.
        """
        bound = (min_sample, max_sample, min_dm, max_dm)
        self.candidates = [candidate]
        self.candidate_bounds = [bound]
        self.min_sample = min_sample
        self.max_sample = max_sample
        self.min_dm = min_dm
        self.max_dm = max_dm
        
        # Filters tag the candidate groups, when plotting candidate groups 
        # the tags are used as class svg attributes that a stylesheet can use
        # to change their appearance.
        self.tags = set()

    def intersects_cheap(self, other):
        """
        Intersect 2 CandidateGroups, checks only the CandidateGroup bounds.

        """
        if self.max_sample >= other.min_sample and self.min_sample <= other.max_sample:
            return self.max_dm >= other.min_dm and self.min_dm <= other.max_dm
        return False

    def intersects_expensive(self, other):
        """
        Intersect 2 CandidateGroups, checking the individual Candidate's bounds.
        """
        for bound1 in self.candidate_bounds:
            for bound2 in other.candidate_bounds:
                if bound1[0] <= bound2[1] and bound1[1] >= bound2[0]:
                    if bound1[2] <= bound2[3] and bound1[3] >= bound2[2]:
                        return True
        return False

    def intersects(self, other):
        """
        Intersect 2 CandidateGroups, checking the individual Candidate's bounds.
        
        This method only performs the expensive check when the CandidateGroup's 
        bounds intersect.
        """
        if not self.intersects_cheap(other):
            return False
        return self.intersects_expensive(other)

    def merge(self, other):
        """
        Merge 2 candidate groups (whilst keeping the bounds up to date).
        
        NOTE: the other object gets deleted!
        """
        if other.min_sample < self.min_sample:
            self.min_sample = other.min_sample
        if other.max_sample > self.max_sample:
            self.max_sample = other.max_sample
        if other.min_dm < self.min_dm:
            self.min_dm = other.min_dm
        if other.max_dm > self.max_dm:
            self.max_dm = other.max_dm
        self.candidates.extend(other.candidates)
        self.candidate_bounds.extend(other.candidate_bounds)
        
        del other

    @property
    def snr(self):
        return sum(c.dm for c in self.candidates)

if __name__ == '__main__':
    print __doc__