# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group,
# 2009-2010.
