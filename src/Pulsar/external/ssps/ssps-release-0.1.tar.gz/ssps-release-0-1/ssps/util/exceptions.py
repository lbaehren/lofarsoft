# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.

# This file collects all the exceptions thrown by ssps.

class RefuseWrite(Exception):
    pass

class SanityCheckFailed(Exception):
    pass

