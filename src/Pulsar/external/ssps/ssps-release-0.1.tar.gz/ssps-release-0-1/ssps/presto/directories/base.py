# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains functionality to describe PRESTO data sets. Currently it is
tested only for sinlge pulse data sets. For now everything in this module 
assumes the presence of dedispersion trials.
'''
from __future__ import division
import re
import os
import logging
from ssps.presto.files.inf import inf_reader


FILE_PATTERN = r'^_DM(?P<dm>(\d+\.\d+))\.(?P<extension>(\S+))'
FILE_RE = re.compile(FILE_PATTERN)


class PRESTODir(object):
    '''Object holding information on a directory of singlepulse detections.
    
    Initializate a PRESTODir object with the directory (path) and base name
    of all the files in the data set (basename). By default this function
    looks for .inf, .singlepulse and .dat files. If any of those files is 
    missing for a trial DM it is ignored. Furthermore there must be a DM = 0
    trial dispersion. 
    
    Note : It is assumed that the data on disk isn't changed between 
    creating a PRESTODir instance and the moment it is used.
    '''

    def __init__(self, path, basename, look_for=['inf', 'singlepulse', 'dat']):
        self.path = path
        self.basename = basename
        self.dm2file = self.find_files(look_for)
        logging.debug('Found %d trial dispersions.' % len(self.dm2file.keys()))
        self.dm2metadata = self.read_metadata()
        logging.debug('Read %d .inf files.' % len(self.dm2metadata.keys()))
        self.dm2downsample = self.calculate_downsampling()
        logging.debug('Calculated %d downsample factors.' % 
            len(self.dm2downsample.keys()))
        self.dm2delay = self.calculate_physical_delays()
	
    def find_files(self, look_for):
        '''Look for all files that match path and basename of this instance.'''
        files = os.listdir(self.path)
        logging.debug('There are %d entries in directory %s' % (len(files), 
            self.path))
        basename_length = len(self.basename)

        # Look for all filesnames that match the present data set. Figure out
        # which files are present per dm.
        dm2file = {}
        for f in files:
            if not f.startswith(self.basename): continue
            tmp = f[basename_length:]
            m = FILE_RE.match(tmp)
            if not m: continue
            try:
                dm = float(m.group('dm'))
            except ValueError:
                continue			
            try:
                dm2file[dm].add(m.group('extension'))
            except KeyError:
                dm2file[dm] = set([m.group('extension')])
                # The square brackets are in the previous line because the set 
                # should have m.group('extension') as 1 thing not a set of 
                # single characters (the default for a string).

        # Ensure that all filetypes that are needed per dm are in fact present:
        dms = dm2file.keys()
        for dm in dms:
            present_files = dm2file[dm]
            for suffix in look_for:
                if not suffix in present_files: 
                    del dm2file[dm]
                    break

        return dm2file

    def calculate_physical_delays(self, dms = None):
        '''Calculates the delays for each trial disperion based on metadata.
        
        Note : This function assumes that the metadata is intact and correct.
        '''
        if not dms:
            dms = self.dm2file.keys()
        dm2delay = {}

        # Note : the bandwidth in PRESTO .inf files is in MHz
        bottom_of_band = self.dm2metadata[0].low_channel_central_freq - \
            0.5 * self.dm2metadata[0].channel_bandwidth
        top_of_band = bottom_of_band + self.dm2metadata[0].n_channels * \
            self.dm2metadata[0].channel_bandwidth

        # Thanks to Eduardo Rubio Herrera for helping me with this!
        for dm in dms:
            delay = 4.1e-3 * ((1000/bottom_of_band)**2 - (1000/top_of_band)**2) * dm / 2
            dm2delay[dm] = int(delay / (self.dm2metadata[0].bin_width * self.dm2downsample[dm]))
        return dm2delay

    def read_metadata(self):
        '''Read all the available metadata for the present data set.
        
        Note : if a .inf file for a certain trial dispersion turns out 
        unreadable, that trial dispersion is ignored.'''
        dms = self.dm2file.keys()
        dm2metadata = {}
        for dm in dms:
            inf_file = self.get_filename(dm, 'inf')
            try:
                metadata = inf_reader(os.path.join(self.path, inf_file))
            except IOError, e:
                # Apparently file could not be read, ignore it for further 
                # processing.
                del self.dm2file[dm]
            else:
                dm2metadata[dm] = metadata

        return dm2metadata
	
    def calculate_downsampling(self):
        '''Calculate the downsampling factor for all the timeseries.
        
        Note : This function assumes that the metadata is intact and correct.
        Further assumes that a DM = 0 trial dispersion is present and that it
        has the lowest downsampling.
        '''
        dms = self.dm2file.keys()
        if not 0 in dms:
            raise Exception('No DM = 0 data available.')

        dm2downsample = {}
        n_bins_at_zero_dm = self.dm2metadata[0].n_bins
        for dm in dms:
            downsampling = n_bins_at_zero_dm // self.dm2metadata[dm].n_bins
            # TODO : consider adding a check for non integer downsamplings
            dm2downsample[dm] = downsampling

        return dm2downsample
	
    def get_filename(self, dm, extension):
        '''Construct the full filename for a data file in the observation.
        
        Note : checks that the asked for file was present when the PRESTO 
        directory was scanned and that the trial dispersion that it belongs to
        had all needed files present.
        '''
        # DM SAMPLING PRECISION ASSUMPTION HERE
        if not extension in self.dm2file[dm]:
            raise Exception('There is no file with extension %s for dm of %.2f' % (extension, dm))
        file = '%s_DM%.2f.%s' % (self.basename, dm, extension)
        return os.path.join(self.path, file)

if __name__ == '__main__':
    pd = PRESTODir('/Users/dev/Documents/lofar/dataset-001', 'test1')
    print 'Found %d trial dispersions.' % len(pd.dm2file.keys())
    print 'Downsampling factors in this dataset:', \
        list(set(pd.dm2downsample.values()))