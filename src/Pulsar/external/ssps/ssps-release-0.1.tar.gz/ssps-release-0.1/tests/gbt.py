# To rewrite this script to the new grouping code I will first only deal with
# the zero delay case. Then when that works I will have to dive into the 
# plotting code.
'''
Test datareduction pipeline. Starts out reading from a single pulse data from a 
directory. Writes a bunch of plots and files with stats to the output directory.

Assumptions:
-PRESTO style .singlepulse and .inf files for every DM trial
-DM = 0 .singlepulse and .inf file are available and have the same length as an
    un dedispersed timeseries. The length of the timeseries at this DM is used
    to calculate the downsampling factor for all the other DM trials.
-The DM quoted in the filename of the .singlepulse and .inf files are in fact 
    the DM of the DM trial they represent. I use these DM values to build a 
    mapping from DM to the files that go with it.
'''

from __future__ import division

import optparse
import os
import sys
import tarfile

import numpy

from pprint import pprint

# ssps imports needed for grouping:
from ssps.presto.files import inf
from ssps.group.groups import group_presto_data
from ssps.presto.directories.base import PRESTODir
# ssps imports needed for plotting:
from ssps.plotting.svg.base import SVGCanvas
from ssps.plotting.svg.presto import CandidateGroupSNRvsDM
# import the newer version of the diagnostic plot (the one that does deal with
# delay compensation)
from ssps.plotting.svg.presto import GroupedPlot, GroupedDMHistogram, SNRvsDMHistogram, SummedSNR
from ssps.plotting.svg.presto import VerticalColorGradientLegend
from ssps.plotting.svg.presto import SVGLink, TextBox, TimeSeriesPlot
from ssps.plotting.util.map import ColorMap
# ssps imports needed to do the calculate the statistics for a dataset:
from ssps.group.stats import calculate_stats, write_stats, find_peak


PLOT_TIME_INTERVAL = 60 # in seconds


TEST_DIR = os.path.split(os.path.abspath(sys.argv[0]))[0]
DATA_DIR = os.path.join(TEST_DIR, 'testdata')
TEMP_DIR = os.path.join(TEST_DIR, 'tmp')
OUTPUT_DIR = os.path.join(TEST_DIR, 'output')



def plot_chunks(presto_dir, plot_time_interval):
    '''
    Cut dataset (pointed to by presto_dir) in chunks of plot_time_interval size.
    
    Returns a list of intervals in un-downsampled timeseries bins.
    
    Assumptions:
    
    * All metadata is intact.
    * DM = 0 data is available and represents the undownsampled timeseries.
    '''
    samples_per_plot = int(plot_time_interval / \
        presto_dir.dm2metadata[0].bin_width)
    dms = presto_dir.dm2file.keys()
    
    # Find the total length of data that needs to be plotted in time - express
    # it in undownsampled bins (like the grouping code does).
    min_delay = presto_dir.dm2delay[0] # Remember : DM=0 has downsampling of 1
    for dm in dms:
        if presto_dir.dm2delay[dm] * presto_dir.dm2downsample[dm] < min_delay:
            min_delay = presto_dir.dm2delay[dm] * presto_dir.dm2downsample[dm]
    # Now find the largest delay.
    max_delay = min_delay
    for dm in dms:
        if presto_dir.dm2delay[dm] * presto_dir.dm2downsample[dm] > max_delay:
            max_delay = presto_dir.dm2delay[dm] * presto_dir.dm2downsample[dm]
    
    min_sample = min_delay
    max_sample = presto_dir.dm2metadata[0].n_bins + max_delay
    
    # Find the intervals to be plotted (again, all this in undownsampled samples
    # like the grouping code).
    n_plots = (max_sample - min_sample) / samples_per_plot
    if not int(n_plots) == n_plots:
        n_plots = int(n_plots) + 1
    chunks = [(samples_per_plot * i, samples_per_plot * (i + 1) - 1) \
        for i in range(n_plots)]
    
    return chunks


if __name__ == '__main__':
    parser = optparse.OptionParser()
    parser.add_option('-F', action='store_true', dest='full')
    parser.add_option('-S', action='store_true', dest='slow')
    parser.add_option('-P', action='store_true', dest='pulsar')
    parser.add_option('-N', action='store_true', dest='nodelete')
    options, args = parser.parse_args()

    if options.full:
        print 'Running with dataset containing nothing of interest.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2359-0646_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2359-0646_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2359-0646'
    elif options.slow:
        print 'Running with dataset containing a lot of bad RFI.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2011-0644_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2011-0644_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2011-0644'
    elif options.pulsar:
        print 'Running with dataset containing a pulsar.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54298_1840+0857_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54298_1840+0857_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54298_1840+0857'        
    else:
        print 'Running with fast small dataset.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'decimated_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'decimated_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2359-0646'

    if not options.nodelete:
        # Clean out the temporary files from the temporary directory and the old 
        # output from the output directory. Possible race conditions here, 
        # assumption is that only this script is running!
        print 'Cleaning up after last run, might take a while.'
        for f in os.listdir(TEMP_DIR): os.remove(os.path.join(TEMP_DIR,f))
        for f in os.listdir(OUTPUT_DIR): os.remove(os.path.join(OUTPUT_DIR,f))
        
        # Extract the single pulse data from the gzipped tar archives to the 
        # tmp directory:
        print 'Untarring testdata, might take a while.'
        for f in singlepulse_tar.getmembers():
            singlepulse_tar.extract(f, TEMP_DIR)
        for f in inf_tar.getmembers():
            inf_tar.extract(f, TEMP_DIR)

        singlepulse_tar.close()
        inf_tar.close()

    # Look for data files and run grouping algorithm on that data.
    print 'Looking for datafiles.'
    pd = PRESTODir(TEMP_DIR, basename, ['inf', 'singlepulse'])
    print 'Looking for groups.'
    grouped = group_presto_data(pd, DMs_adjacent = 4, delta_sample = 4)
    grouped.sort(key = lambda x : x.max_sample)

    print 'Plotting results to SVG.'
    # Cut the data set in chunks by time and plot them to SVG files.
    grouped.sort(key = lambda x: x.min_sample)

    chunks = plot_chunks(pd, PLOT_TIME_INTERVAL)
    for i, interval in enumerate(chunks):
        min_sample, max_sample = interval
        print '    Plotting %d out of % d' % (i + 1, len(chunks))
        
        min_dm = 0
        max_dm = 1000
        
        plotfile = os.path.join(OUTPUT_DIR, 'singlepulse_candidates_%04d.xml'%i)
        cv = SVGCanvas(1200, 700)
        gp = GroupedPlot(pd, grouped, [min_sample, max_sample], (min_dm, max_dm))
        gp.set_dimensions(y_offset = 50)
        cv.add_figure(gp)
        # first right side panel main diagnostic
        gh = GroupedDMHistogram(pd, grouped, (min_dm, max_dm), (min_sample, max_sample))
        gh.set_dimensions(x_offset = 700, y_offset = 50, width = 250, height = 500)
        cv.add_figure(gh)
        # second right side panel main diagnostic
        snrdmh = SNRvsDMHistogram(pd, grouped, (min_dm, max_dm), (min_sample, max_sample))
        snrdmh.set_dimensions(x_offset = 850, y_offset = 50, width = 250, height = 500)
        cv.add_figure(snrdmh)

        # bottom panel for main diagnostic
        ssnr = SummedSNR(pd, grouped, (min_sample, max_sample), (min_dm, max_dm))
        ssnr.set_dimensions(y_offset = 450, width = 800, height = 250)
        cv.add_figure(ssnr)


        
        tb = TextBox('Dataset : %s' % (os.path.join(TEMP_DIR, basename) + ' *'))
        tb.set_dimensions(x_offset = 50, y_offset = 10, width = 1000)
        cv.add_figure(tb)
        
        if i != 0:
            l = SVGLink('singlepulse_candidates_%04d.xml' % (i - 1), 'Previous')
            l.set_dimensions(x_offset = 800, y_offset = 570)
            cv.add_figure(l)
        if i < len(chunks) - 1:
            l = SVGLink('singlepulse_candidates_%04d.xml' % (i + 1), 'Next')
            l.set_dimensions(x_offset = 900, y_offset = 570)
            cv.add_figure(l)
        cv.dump(plotfile)

