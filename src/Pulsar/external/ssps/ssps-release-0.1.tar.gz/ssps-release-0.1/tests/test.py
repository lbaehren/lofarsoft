'''
Script that reads data from the testdata directory, unpacks it in the tmp
directory, runs the grouping code and then creates a new set of files in the
output directory. Then it groups that data in the output directory and checks
whether the second run gave the same results. This is a check on the reading
and writing parts of the ssps library.
'''
#
# When this script works using the current code I will start refactoring and
# at each step use the script to check whether the new code still works. 
from __future__ import division

import os
import sys
import shutil
import tarfile
import optparse

from ssps.presto.directories.singlepulse import singlepulse_dir_from_template
from ssps.presto.directories.singlepulse import singlepulse_dir_data_writer

from ssps.group.groups import group_presto_data
from ssps.presto.directories.base import PRESTODir

TEST_DIR = os.path.split(os.path.abspath(sys.argv[0]))[0]
DATA_DIR = os.path.join(TEST_DIR, 'testdata')
TEMP_DIR = os.path.join(TEST_DIR, 'tmp')
OUTPUT_DIR = os.path.join(TEST_DIR, 'output')

def stat_helper(candidate_groups):
    '''
    Helper function that creates a histogram from the CandidateGroup sizes and
    the calculates the total number of candiates in the CandidateGroups.
    '''
    size_histogram = {}
    n_candidates = 0
    for cg in candidate_groups:
        L = len(cg.candidates)
        n_candidates += L
        try:
            size_histogram[L] += 1
        except (KeyError), e:
            size_histogram[L] = 1
    return size_histogram, n_candidates

    
if __name__ == '__main__':
    parser = optparse.OptionParser()
    parser.add_option('-F', action='store_true', dest='full')
    parser.add_option('-S', action='store_true', dest='slow')
    parser.add_option('-P', action='store_true', dest='pulsar')
    parser.add_option('-N', action='store_true', dest='nodelete')
    options, args = parser.parse_args()

    if options.full:
        print 'Running with dataset containing nothing of interest.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2359-0646_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2359-0646_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2359-0646'
    elif options.slow:
        print 'Running with dataset containing a lot of bad RFI.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2011-0644_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54253_2011-0644_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2011-0644'
    elif options.pulsar:
        print 'Running with dataset containing a pulsar.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54298_1840+0857_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'GBT350drift_54298_1840+0857_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54298_1840+0857'        
    else:
        print 'Running with fast small dataset.'
        singlepulse_tar = tarfile.open(os.path.join(DATA_DIR, 
            'decimated_singlepulse.tgz'), 'r:gz')
        inf_tar = tarfile.open(os.path.join(DATA_DIR, 
            'decimated_inf.tgz'), 'r:gz')
        basename = 'GBT350drift_54253_2359-0646'

    if not options.nodelete:
        # Clean out the temporary files from the temporary directory and the old 
        # output from the output directory. Possible race conditions here, 
        # assumption is that only this script is running!
        print 'Cleaning up after last run, might take a while.'
        for f in os.listdir(TEMP_DIR): os.remove(os.path.join(TEMP_DIR,f))
        for f in os.listdir(OUTPUT_DIR): os.remove(os.path.join(OUTPUT_DIR,f))
        
        # Extract the single pulse data from the gzipped tar archives to the 
        # tmp directory:
        print 'Untarring testdata, might take a while.'
        for f in singlepulse_tar.getmembers():
            singlepulse_tar.extract(f, TEMP_DIR)
        for f in inf_tar.getmembers():
            inf_tar.extract(f, TEMP_DIR)

        singlepulse_tar.close()
        inf_tar.close()

    # Run the single pulse grouping code on the files in the temporary 
    # directory:
    print 'Preparing for grouping run in temporary directory.'
    pd = PRESTODir(TEMP_DIR, basename, ['inf', 'singlepulse'])
    # Run the single pulse grouping code on the files in the temporary 
    # directory:
    print 'Running grouping algorithm.'
    grouped = group_presto_data(pd, DMs_adjacent = 16, delta_sample = 16)

    hist1, n1 = stat_helper(grouped)
    
    # Merge all the candidate groups' contents
    candidates = []
    for g in grouped:
        candidates.extend([c for c in g.candidates])
    

    # Copy over all the inf file from the temp directory to the output directory
    new_basename = 'NEW'
    singlepulse_dir_from_template(TEMP_DIR, basename, 
        OUTPUT_DIR, new_basename)
    # write out all the dm trials to the OUTPUT_DIR
    singlepulse_dir_data_writer(OUTPUT_DIR, new_basename, 
        candidates)

    print 'Preparing for grouping run in temporary directory.'
    pd_2 = PRESTODir(OUTPUT_DIR, new_basename, ['inf', 'singlepulse'])
    # Run the single pulse grouping code on the files in the temporary 
    # directory:
    print 'Running grouping algorithm.'
    grouped_2 = group_presto_data(pd_2, DMs_adjacent = 16, delta_sample = 16)

    
    hist2, n2 = stat_helper(grouped_2)
    
    if hist1 == hist2:
        print 'Grouping 2 times gave the same results. (GOOD)'
    else:
        print 'Grouping 2 times did _not_ give the same results. (BAD)'
    
    if n2 == n1:
        print 'No singlepulse candidates were lost during conversion. (GOOD)'
    if n2 < n1:
        print 'Singlepulse candidates were lost during conversion. (BAD)'
    if n2 > n1:
        print 'Singlepulse candidates were created during conversion. (BAD)'
    
    print hist1, '\n', hist2
