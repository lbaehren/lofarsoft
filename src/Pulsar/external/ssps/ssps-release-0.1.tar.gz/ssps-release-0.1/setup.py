#!/usr/bin/env python
# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.

from distutils.core import setup

setup(name='ssps',
	version=0.1,
	description='Simple Single Pulse Search',
	author='Thijs Coenen',
	author_email='tcoenenbackup@gmail.com',
	packages=[
		'ssps', 
		'ssps.group', 
		'ssps.plotting',
		'ssps.plotting.svg',
		'ssps.plotting.util',
		'ssps.presto',
		'ssps.presto.files',
		'ssps.presto.directories',
		'ssps.util'],
	scripts = [],
	)
