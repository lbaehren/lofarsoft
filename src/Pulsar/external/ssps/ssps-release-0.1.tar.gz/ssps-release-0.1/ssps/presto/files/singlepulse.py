# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains functions to deal with PRESTO .singlepulse files and a
class to represent single pulse detection candidates.
''' 

_PRESTO_SINGLEPULSE_HEADER = '# DM      Sigma      Time (s)     Sample    Downfact\n'

class Candidate(object):
    '''Single pulse detection candidate class.
    
    A candidate detection sits on the time-DM plane. The time of the detection
    is given both by the sample and time attributes (internally ssps only uses
    the sample attribute). The dispersion measure of the detection is given by
    the dm attribute. The sigma attribute is the signal-to-noise ratio at which
    the single pulse is detected and the downfact attribute describes the width
    of the tophat function with which the timeseries was convolved (effectively
    the width of the pulse).
    '''
    __slots__ = ['dm', 'sigma', 'time', 'sample', 'downfact']
    
    def __init__(self, dm, sigma, time, sample, downfact):
        self.dm = dm
        self.sigma = sigma
        self.time = time
        self.sample = sample
        self.downfact = downfact
        
    @classmethod
    def from_singlepulse_line(cls, line):
        '''Convert a PRESTO .singlepulse file line to a Candidate.
        
        Note : raises a ValueError if the conversion fails.
        '''
        chunks = line.split()
        try:
            dm = float(chunks[0])
            sigma = float(chunks[1])
            time = float(chunks[2])
            sample = int(chunks[3])
            downfact = int(chunks[4])
        except (ValueError, IndexError), e:
            raise ValueError
        else:
            return cls(dm, sigma, time, sample, downfact)

    def __str__(self):
        '''Convert an ssps Candidate to .singlepulse file representation.'''
        # DM SAMPLING PRECISION ASSUMPTION HERE
        return '%(dm)7.2f %(sigma)7.2f %(time)13.6f %(sample)10d     %(downfact)3d\n' % {
            'dm' : self.dm,
            'sigma' : self.sigma,
            'time' : self.time,
            'sample' : self.sample,
            'downfact' : self.downfact,
        }
        
def singlepulse_reader(in_file):
    '''
    Read a PRESTO .singlepulse file, return a list of Candidate instances.
    '''
    n_succes = 0
    n_errors = 0

    candidates_out = []

    try:
        f = open(in_file, 'r')
        try:
            for line in f:
                try:
                    candidate = Candidate.from_singlepulse_line(line)
                except ValueError:
                    n_errors += 1
                else:
                    n_succes += 1
                    candidates_out.append(candidate)
            if n_errors > 1:
                log_msg = 'Read %s, it contains %d candidates and %d errors' % \
                    (in_file, in_file, n_errors)
                logging.debug(log_msg)
        finally:
            f.close()            
    except IOError:
        pass
    return candidates_out

def singlepulse_writer(out_file, candidates):
    '''
    Write a PRESTO .singlepulse file given a list of Candidate instances.
    '''
    try:
        fd = open(out_file, 'w')
        try:
            fd.write(_PRESTO_SINGLEPULSE_HEADER)
            for candidate in candidates:
                fd.write(str(candidate))
        finally:
            fd.close()
    except IOError:
        pass

if __name__ == '__main__':
    print 'This module is not supposed to be run stand alone'
    