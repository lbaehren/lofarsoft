# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains functions to deal with directories of PRESTO singlepulse
data. Specifically how to write them given an example data set and a list of
single pulse detections (ssps.presto.files.singlepulse.Candidate instances).
'''
import os
import re
import shutil

from ssps.presto.files.singlepulse import singlepulse_writer
from ssps.presto.files.inf import inf_reader, inf_writer

def singlepulse_dir_from_template(in_path, in_basename, out_path, out_basename):
    '''
    Function creates an empty singlepulse data directory following a template.
    
    This function creates all the .inf files that a singlepulse data directory
    needs, it does so by copying/adapting an existing .inf files from a template
    directory and creating empty .singlepulse files for all the DMs (for which 
    there are .inf files). Run this function before you write the singlepulse
    candidate files because this function will blindly overwrite! --- for now.
    
    Note: the empty .singlepulse files are a way of making the directory safe
    for the PRESTO single_pulse_search.py script.
    '''
    # Set up the regexp that the .inf files need to match.
    pattern = r'(?P<basename>.*)_DM(?P<dm>(\d+\.\d+))\.inf$'    
    regexp = re.compile(pattern)

    for f in os.listdir(in_path):
        # Find the relevant metadata files (.inf files):
        m = regexp.match(f)
        if m:
            # Copy over metadata:
            if in_basename == out_basename:
                # No change needed to metadata, just copy over the file.
                shutil.copy(os.path.join(in_path, f), out_path)
            else:
                # New basename, need to change the metadata to match:
                metadata = inf_reader(os.path.join(in_path, f))
                suffix_less_file = os.path.join(out_path, '%s_DM%s' % ( \
                    out_basename, m.group('dm')))
                metadata.data_file = suffix_less_file
                inf_file = '%s_DM%s.inf' % (out_basename, m.group('dm'))
                inf_writer(os.path.join(out_path, inf_file), metadata)
            
            
            singlepulse_file = '%s_DM%s.singlepulse' % (out_basename, 
                m.group('dm'))
            f = open(os.path.join(out_path, singlepulse_file), 'w')
            f.close()

def singlepulse_dir_data_writer(out_path, out_basename, candidates):
    '''
    Write singlepulse candidate files given a list of candidates.
    
    This function naively writes .singlepulse files for all the DMs that have 
    candidates. For the PRESTO single_pulse_search.py plots you will also need
    to have metadata files (the .inf files with the same base name).
    '''

    # Sort candidates by DM:
    sorted_candidates = {}
    for c in candidates:
        try:
            sorted_candidates[c.dm].append(c)
        except (KeyError), e:
            sorted_candidates[c.dm] = [c]
    
    # Write the .singlepulse files:
    for dm, candidates in sorted_candidates.items():
        candidates.sort(key = lambda x: x.sample)
        # DM SAMPLING PRECISION ASSUMPTION HERE        
        singlepulse_file = '%s_DM%.2f.singlepulse' % (out_basename, dm)
        singlepulse_writer(os.path.join(out_path, singlepulse_file), candidates)
    
    
