# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.

# Central settings file.
# Settings relevant to PRESTO file handling

DM_FUDGE = 1e-5
