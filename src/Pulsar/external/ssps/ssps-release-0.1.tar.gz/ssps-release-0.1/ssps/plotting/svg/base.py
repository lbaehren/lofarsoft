# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
from ssps.plotting.util import transform
from ssps.plotting.util.ranges import make_input_range_safe
from ssps.plotting.util.ranges import stretch_input_range

from ssps.plotting.svg import axis

try:
    import xml.etree.cElementTree as ET
except ImportError:
    try:
        import xml.etree.ElementTree as ET
    except ImportError:
        import elementtree.ElementTree as ET

class SVGCanvas(object):
    """Serves as the root of a SVG ElementTree, can dump to file like object."""
    def __init__(self, width, height):
        """Set the size of the SVG canvas."""
        self.width = width
        self.height = height
        root = ET.Element('svg')
        root.set('xmlns', 'http://www.w3.org/2000/svg')
        root.set('xmlns:xlink', 'http://www.w3.org/1999/xlink')
        root.set('height', str(self.height))
        root.set('width', str(self.width))
        root.set('version', "1.1")
        root.append(ET.Comment('Created by ssps tools.'))
        self.root = root
        self.graphs = []
    
    def add_figure(self, figure):
        """Function to add figures to the SVG canvas."""
        self.graphs.append(figure)
    
    def dump(self, file_like_object):
        """Dump SVG to file_like_object."""
        for g in self.graphs:
            g.draw(self.root)
        tree = ET.ElementTree(self.root)
        tree.write(file_like_object)


class PlotArea2d(object):
    def __init__(self):
        self.x_offset = 0
        self.y_offset = 0
        self.width = 100
        self.height = 100
        self.x_interval = ((0, 100), False)
        self.y_interval = ((0, 100), False)

    def set_dimensions(self, *args, **kwargs):
        self.x_offset = kwargs.get('x_offset', self.x_offset)
        self.y_offset = kwargs.get('y_offset', self.y_offset)
        self.width = kwargs.get('width', self.width)
        self.height = kwargs.get('height', self.height)
        
    def set_x_interval(self, *args, **kwargs):
        try:
            interval = kwargs['interval']
        except KeyError:
            raise
        else:
            log = kwargs.get('log', False)
        self.x_interval = (interval, log)
        
    def set_y_interval(self, *args, **kwargs):
        try:
            interval = kwargs['interval']
        except KeyError:
            raise
        else:
            log = kwargs.get('log', False)
        self.y_interval = (interval, log)

    def set_transforms(self):
        # This sets the correct transforms
        interval, log = self.x_interval
        if not log:
            self.x_transform = transform.make_linear_transform1d(
                [self.x_offset, self.x_offset + self.width],
                interval,
                False
            )
        else:
            self.x_transform = transform.make_logarithmic_transform1d(
                [self.x_offset, self.x_offset + self.width],
                interval,
                False
            )

        interval, log = self.y_interval
        if not log:            
            self.y_transform = transform.make_linear_transform1d(
                [self.y_offset, self.y_offset + self.height],
                interval,
                True
            )
        else:
            self.y_transform = transform.make_logarithmic_transform1d(
                [self.y_offset, self.y_offset + self.height],
                interval,
                True
            )
        

    def draw(self, root_element):
        # Override this in subclasses
        box = ET.SubElement(root_element, 'rect')
        box.set('fill', 'yellow')
        box.set('x', '%.2f' % self.x_offset)
        box.set('y', '%.2f' % self.y_offset)
        box.set('width', '%.2f' % self.width)
        box.set('height', '%.2f' % self.height)
        text = ET.SubElement(root_element, 'text')
        text.text = 'No drawing routine provided.'
        text.set('font-size', '15')
        text.set('x', '%.2f' % (self.x_offset + self.width / 2))
        text.set('y', '%.2f' % (self.y_offset + self.height / 2))
        text.set('text-anchor', 'middle')



class Graph2d(object):
    def __init__(self):
        self.width = 300
        self.height = 00
        self.x_offset = 0
        self.y_offset = 0
        
        self.title = None
        self.top_axis = None
        self.right_axis = None
        self.bottom_axis = None
        self.left_axis = None
        self.payload = None

    def set_dimensions(self, *args, **kwargs):
        self.x_offset = kwargs.get('x_offset', self.x_offset)
        self.y_offset = kwargs.get('y_offset', self.y_offset)
        self.width = kwargs.get('width', self.width)
        self.height = kwargs.get('height', self.height)
        
    def set_title(self, title):
        self.title = title

    def set_left_axis(self, *args, **kwargs):
        if self.left_axis:
            interval = kwargs.get('interval', self.left_axis[0])
            label = kwargs.get('label', self.left_axis[1])
            log = kwargs.get('log', self.left_axis[2])
            tickmarks = kwargs.get('tickmarks', self.left_axis[3])
        else:
            interval = kwargs.get('interval', [0, 10])
            label = kwargs.get('label', None)
            log = kwargs.get('log', False)
            tickmarks = kwargs.get('tickmarks', None)
        
        self.left_axis = (interval, label, log, tickmarks)
        
    def set_right_axis(self, *args, **kwargs):
        if self.right_axis:
            interval = kwargs.get('interval', self.right_axis[0])
            label = kwargs.get('label', self.right_axis[1])
            log = kwargs.get('log', self.right_axis[2])            
            tickmarks = kwargs.get('tickmarks', self.right_axis[3])
        else:
            interval = kwargs.get('interval', [0, 10])
            label = kwargs.get('label', None)
            log = kwargs.get('log', False)
            tickmarks = kwargs.get('tickmarks', None)
        
        self.right_axis = (interval, label, log, tickmarks)

    def set_top_axis(self, *args, **kwargs):
        if self.top_axis:
            interval = kwargs.get('interval', self.top_axis[0])
            label = kwargs.get('label', self.top_axis[1])
            log = kwargs.get('log', self.top_axis[2])
            tickmarks = kwargs.get('tickmarks', self.top_axis[3])
            
        else:
            interval = kwargs.get('interval', [0, 10])
            label = kwargs.get('label', None)
            log = kwargs.get('log', False)
            tickmarks = kwargs.get('tickmarks', None)            
        
        self.top_axis = (interval, label, log, tickmarks)

    def set_bottom_axis(self, *args, **kwargs):
        if self.bottom_axis:
            interval = kwargs.get('interval', self.bottom_axis[0])
            label = kwargs.get('label', self.bottom_axis[1])
            log = kwargs.get('log', self.bottom_axis[2])
            tickmarks = kwargs.get('tickmarks', self.bottom_axis[3])
        else:
            interval = kwargs.get('interval', [0, 10])
            label = kwargs.get('label', None)
            log = kwargs.get('log', False)
            tickmarks = kwargs.get('tickmarks', None)
        
        self.bottom_axis = (interval, label, log, tickmarks)

    def set_payload(self, plotarea):
        self.payload = plotarea

    def draw(self, root_element):
        # This deals with area taken away from the main graph by the various
        # axes that might be present. 
        # TODO : Needs to be adapted to allow the graphs to have a title.
        TOP_AXIS_HEIGHT = 50
        LEFT_AXIS_WIDTH = 50
        RIGHT_AXIS_WIDTH = 50
        BOTTOM_AXIS_HEIGHT = 50
        
        TOP_AXIS_WIDTH = self.width - LEFT_AXIS_WIDTH - RIGHT_AXIS_WIDTH
        BOTTOM_AXIS_WIDTH = TOP_AXIS_WIDTH
        
        LEFT_AXIS_HEIGHT = self.height - TOP_AXIS_HEIGHT - BOTTOM_AXIS_HEIGHT
        RIGHT_AXIS_HEIGHT = LEFT_AXIS_HEIGHT
        
        if self.payload:
            self.payload.set_dimensions(
                x_offset = self.x_offset + LEFT_AXIS_WIDTH,
                y_offset = self.y_offset + TOP_AXIS_HEIGHT,
                width = TOP_AXIS_WIDTH,
                height = LEFT_AXIS_HEIGHT,
            )
            self.payload.set_transforms()
            self.payload.draw(root_element)

        # Now create and draw the axes : 
        la = axis.LeftAxis(self.x_offset, self.y_offset + TOP_AXIS_HEIGHT,
            LEFT_AXIS_HEIGHT, self.left_axis)
        la.draw(root_element)

        ta = axis.TopAxis(self.x_offset + LEFT_AXIS_WIDTH, 
                self.y_offset, TOP_AXIS_WIDTH, self.top_axis)

        ta.draw(root_element)

        ra = axis.RightAxis(self.x_offset + self.width - RIGHT_AXIS_WIDTH, 
            self.y_offset + TOP_AXIS_HEIGHT, RIGHT_AXIS_HEIGHT, self.right_axis)
        ra.draw(root_element)

        ba = axis.BottomAxis(self.x_offset + LEFT_AXIS_WIDTH, 
            self.y_offset + TOP_AXIS_HEIGHT + LEFT_AXIS_HEIGHT, BOTTOM_AXIS_WIDTH, self.bottom_axis)
        ba.draw(root_element)


# ------------------------------------------------------------------------------
# -- Histogram plotting base classes -------------------------------------------

def clean_up(bins):
    out = []
    new_bin = bins[0]
    for bin in bins:
        if new_bin[2] == bin[2]:
            new_bin = (new_bin[0], bin[1], new_bin[2])
        else:
            out.append(new_bin)
            new_bin = bin
    out.append(new_bin)
    return out
    
class BaseHistogramArea(PlotArea2d):
    def __init__(self, bins):
        super(BaseHistogramArea, self).__init__()
        self.bins = clean_up(bins) # layout of self.bins : [(x1, x2, val), ...]
        
        stretch_x = 1.05
        stretch_y = 1.05
        
        bin_interval = (bins[0][0], bins[-1][1])
        bin_interval = stretch_input_range(bin_interval, stretch_x)
        self.set_x_interval(interval = bin_interval)

        value_interval = stretch_input_range((0, max(x[2] for x in bins)), stretch_y)        
        self.set_y_interval(interval = value_interval)

    def draw(self, root_element):
        pl = ET.SubElement(root_element, 'polyline')
        pl.set('stroke', 'black')
        pl.set('fill', 'none')
        points = []
        for bin in self.bins:
            points.append("%.2f,%.2f %.2f,%.2f" % (
                    self.x_transform(bin[0]), self.y_transform(bin[2]),
                    self.x_transform(bin[1]), self.y_transform(bin[2])
            ))
        # This is not nice:
        pl.set('points', ' '.join(points))


class BaseHistogram(Graph2d):
    """Histogram with bins along x axis."""
    def __init__(self, bins = []):
        super(BaseHistogram, self).__init__()
        self.set_bottom_axis(interval = (bins[0][0], bins[-1][1]), label = 'bin')
        self.set_top_axis(interval = (bins[0][0], bins[-1][1]))
        value_interval = (0, 1.1 * max(x[2] for x in bins))
        self.set_left_axis(interval = value_interval, label = 'value')
        self.set_right_axis(interval = value_interval)
        g = BaseHistogramArea(bins)
        self.set_payload(g)

# ------------------------------------------------------------------------------
# -- vertical histogram base class ---------------------------------------------

class BaseHistogramVArea(PlotArea2d):
    def __init__(self, bins, value_interval, bin_interval):
        super(BaseHistogramVArea, self).__init__()
        self.bins = clean_up(bins) # layout of self.bins : [(x1, x2, val), ...]
        self.set_x_interval(interval = value_interval)
        self.set_y_interval(interval = bin_interval)

    def draw(self, root_element):
        pl = ET.SubElement(root_element, 'polyline')
        pl.set('stroke', 'black')
        pl.set('fill', 'none')
        points = []
        for bin in self.bins:
            points.append("%.2f,%.2f %.2f,%.2f" % (
                    self.x_transform(bin[2]), self.y_transform(bin[0]),
                    self.x_transform(bin[2]), self.y_transform(bin[1])
            ))
        # This is not nice:
        pl.set('points', ' '.join(points))


class BaseHistogramV(Graph2d):
    """Histogram with bins along y axis."""
    def __init__(self, bins = []):
        super(BaseHistogramV, self).__init__()
        stretch_x = 1.05
        stretch_y = 1.05
        
        bin_interval = (bins[0][0], bins[-1][1])
        bin_interval = stretch_input_range(bin_interval, stretch_y)
        self.set_left_axis(interval = bin_interval, label = 'bin')
        self.set_right_axis(interval = bin_interval)
        
        value_interval = (0, max(x[2] for x in bins))
        value_interval = stretch_input_range(value_interval, stretch_x)
        self.set_bottom_axis(interval = value_interval, label = 'value')
        self.set_top_axis(interval = value_interval)
        
        g = BaseHistogramVArea(bins, value_interval, bin_interval)
        self.set_payload(g)

# ------------------------------------------------------------------------------


class BaseLinePlotArea(PlotArea2d):
    def __init__(self, lines, x_interval, y_interval):
        super(BaseLinePlotArea, self).__init__()
        self.lines = lines # layout [[(x1, y1), (x2, y2), ...], ...]
        self.set_x_interval(x_interval)
        self.set_y_interval(y_interval)
        
    def draw(self, root_element):
        for line in self.lines:
            pl = ET.SubElement(root_element, 'polyline')
            pl.set('stroke', 'black')
            pl.set('fill', 'none')
            points = []
            for x, y in line:
                points.append("%.2f,%.2f" % (
                        self.x_transform(x), self.y_transform(y),
                ))
            # This is not nice:
            pl.set('points', ' '.join(points))


class BaseLinePlot(Graph2d):
    def __init__(self, lines, *args, **kwargs):
        super(BaseLinePlot, self).__init__(*args, **kwargs)

        # The following deals with the case that there is no range of values
        # for one of the variables.
        smallest_x = min([l[0][0] for l in lines])
        largest_x = max([l[-1][0] for l in lines])
        smallest_y = min([min((x[1] for x in line)) for line in lines])
        largest_y = max([max((x[1] for x in line)) for line in lines])
        
        # Find the intervals that contain all points.
        safe_interval_x = stretch_input_range((smallest_x, largest_x), 1.1)
        safe_interval_y = stretch_input_range((smallest_y, largest_y), 1.1)

        # Default labeling for axes.
        self.set_top_axis(interval = safe_interval_x)
        self.set_bottom_axis(interval = safe_interval_x)
        self.set_left_axis(interval = safe_interval_y)
        self.set_right_axis(interval = safe_interval_y)
        
        # Add the object that does the actual plotting.
        g = BaseLinePlotArea(lines, safe_interval_x, safe_interval_y)        
        self.set_payload(g)
