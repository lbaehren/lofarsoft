# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
from __future__ import division
from ssps.plotting.util import color

class ValueMap(object):
    """Maps a input value to an output within some range."""
    
    def __init__(self, input_range, begin_value, end_value):
        self.input_range = input_range
        self.begin_value = begin_value
        self.end_value = end_value
    
    def __call__(self, value):
        if value < self.input_range[0]: return self.begin_value
        if value > self.input_range[1]: return self.end_value
        
        d = (value - self.input_range[0]) / (self.input_range[1] - self.input_range[0])
        return d * (self.end_value - self.begin_value) + self.begin_value

        
class ColorMap(object):
    """Maps a input value to an output RGB color along a gradient."""

    def __init__(self, input_range, rgb_begin, rgb_end):
        # Does not precalculate the colormap, might become slow ...
        self.input_range = input_range
        self.rgb_begin = rgb_begin
        self.rgb_end = rgb_end
        self.hsl_begin = color.rgb2hsl(*rgb_begin)
        self.hsl_end = color.rgb2hsl(*rgb_end)
        
    def __call__(self, value):
        # returns a RGB hex string #012345
        if value < self.input_range[0]: 
            tmp = '#%02x%02x%02x' % (int(self.rgb_begin[0] * 255), int(self.rgb_begin[1] * 255), int(self.rgb_begin[2] * 255))
            return tmp
        if value > self.input_range[1]:
            tmp = '#%02x%02x%02x' % (int(self.rgb_begin[0] * 255), int(self.rgb_begin[1] * 255), int(self.rgb_begin[2] * 255))
            return tmp
        
        d = (value - self.input_range[0]) / (self.input_range[1] - 
            self.input_range[0])
        hue = (self.hsl_end[0] - self.hsl_begin[0]) * d + self.hsl_begin[0]
        saturation = (self.hsl_end[1] - self.hsl_begin[1]) * d + self.hsl_begin[1]
        lightness = (self.hsl_end[2] - self.hsl_begin[2]) * d + self.hsl_begin[2]
        
        red, green, blue = color.hsl2rgb(hue, saturation, lightness)
        return '#%02x%02x%02x' % (int(red * 255), int(green * 255), int(blue * 255))
