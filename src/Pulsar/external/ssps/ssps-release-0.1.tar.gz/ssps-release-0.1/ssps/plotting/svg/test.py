# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.

'''
This module contains basic testing code for the ssps plotting functionality.
'''

import random

from ssps.plotting.util import transform
from ssps.plotting.util import map
from ssps.plotting.svg import base
from ssps.plotting.svg import presto


try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET


# ------------------------------------------------------------------------------
# -- Example Graph2d subclass + PlotArea2d subclass ----------------------------

# A plot consists of a set of axes and a actual plot area, all contained in an
# instance of Graph2d. By making subclasses of Graph2d one can automate some
# of the setting of axes etc. Subclasses of PlotArea2d contain the drawing 
# logic for the data area.


class TestArea(base.PlotArea2d):
    '''
    Example scatter plot drawing code, needs to be wrapped by a Graph2d subclass
    '''
    def __init__(self, n = 100, *args, **kwargs):
        # Prepare data / store data.
        super(TestArea, self).__init__()
        self.data = [(random.random() * 99 + 1, random.random() * 99 + 1) for i in xrange(n)]
        self.set_x_interval(interval = [1, 100], log = True)
        self.set_y_interval(interval = [1, 100])

    def draw(self, root_element):
        # Do actual drawing.
        for x, y in self.data:
            root_element.append(ET.Element('circle',
                cx = '%.2f' % self.x_transform(x),
                cy = '%.2f' % self.y_transform(y),
                r = '5',
                stroke = 'black',
                fill = 'none'
            ))


class TestGraph(base.Graph2d):
    '''
    Example scatter plot. The actual drawing is in class TestArea.
    '''
    def __init__(self, n = 100):
        # Initialize baseclass, does a lot of boring work for you:
        super(TestGraph, self).__init__()
        # Set the the size of the plot and the range of the axis:
        self.set_dimensions(x_offset = 0, y_offset = 0, width = 400, height = 400)
        self.set_left_axis(interval = [1, 100], label = 'Random variable Y')
        self.set_right_axis(interval = [1, 100])
        self.set_top_axis(interval = [1, 100])
        self.set_bottom_axis(interval = [1, 100], label = 'Random variable X', log = True)
        # Hook up drawing code (PlotArea2d subclass) to this graph:
        t = TestArea(n)
        self.set_payload(t)


# ------------------------------------------------------------------------------
# -- Example Histogram ---------------------------------------------------------


class TestHistogram(base.BaseHistogram):
    '''
    Example histogram.
    '''
    def __init__(self):
        bins = [(i, i + 1, random.randint(0, 10)) for i in range(20)]
        super(TestHistogram, self).__init__(bins)
        self.set_dimensions(x_offset = 400, y_offset = 0, width = 400, height = 400)

class TestGradient(presto.VerticalColorGradientLegend):
    def __init__(self):
        colormap = map.ColorMap([0, 100], (0, 0, 1), (1, 0, 0))
        super(TestGradient, self).__init__(colormap)
        self.set_dimensions(x_offset = 820, y_offset = 30, width = 120, height = 340)

if __name__ == '__main__':
    import sys
    
    c = base.SVGCanvas(1000, 600)
    c.add_figure(TestGraph(100))
    c.add_figure(TestHistogram())
    svglink = presto.SVGLink('http://slashdot.org', 'SLASHDOT')
    svglink.set_dimensions(x_offset = 50, y_offset = 400, width = 100, height = 30)
    c.add_figure(svglink)
    tg = TestGradient()
    c.add_figure(tg)
    
    f = open('newout.xml', 'w')
    c.dump(sys.stdout)
    f.close()
    
