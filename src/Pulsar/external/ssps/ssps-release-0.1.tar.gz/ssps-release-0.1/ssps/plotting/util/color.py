# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
from __future__ import division

"""Module with functions to convert back and forth between the RGB and HSL 
colorspaces.

"""

# Based on conversion described the Wikipedia entry for HSL and HSV
# http://en.wikipedia.org/wiki/HSL_and_HSV and the first entry from Google
# search results on HSL to RGB http://130.113.54.154/~monger/hsl-rgb.html 
# (per july 2009). Apperently making color gradients is best done in HSL or HSV
# color spaces (as opposed to doing it in RGB colorspace).

def rgb2hsl(red, green, blue):
    """Convert a color from RGB to HSL colorspace.
    
    The red, green and blue color components must be in [0,1] range. Output hue 
    will be in [0, 360) range, ligthness and saturation are in the range [0, 1].
    
    """
    
    assert 0 <= red <= 1
    assert 0 <= green <= 1
    assert 0 <= blue <= 1
    
    M = max(red, green, blue)
    m = min(red, green, blue)
    
    if M == m:
        hue = 0
    elif M == red:
        hue = (60 * (green - blue) / (M - m)) % 360
    elif M == green:
        hue = 60 * (blue - red) / (M - m) + 120
    elif M == blue:
        hue = 60 * (red - green) / (M - m) + 240
    
    lightness = (M + m) / 2

    if M == m:
        saturation = 0
    elif lightness <= 0.5:
        saturation = (M - m) / (M + m)
    else:
        saturation = (M - m) / (2 - M - m)

    return hue, saturation, lightness

def _hsl2rgb_helper(temp_component, p, q):
    # Helper function that goes with hsl2rgb (defined below).
    if temp_component < 0:
        temp_component += 1
    elif temp_component > 1:
        temp_component -= 1
    
    if temp_component < (1 / 6):
        return p + (q - p) * 6 * temp_component
    elif (1 / 6) <= temp_component < (1 / 2):
        return q
    elif (1 / 2) <= temp_component < (2 / 3):
        return p + (q - p) * 6 * ((2 / 3) - temp_component)
    else:
        return p

def hsl2rgb(hue, saturation, lightness):
    """Convert a color from HSL to RGB colorspace.
    
    The hue is in [0, 360) range, ligthness and saturation are in the range 
    [0, 1]. Ouput red, green and blue color components will be in [0,1] range.
    
    """
    if saturation == 0:
        return lightness, lightness, lightness

    if lightness < 0.5:
        q = lightness * (1 + saturation)
    else:
        q = lightness + saturation - (lightness * saturation)
    
    p = 2 * lightness - q
    
    normalized_hue = hue / 360
    temp_red = normalized_hue + (1 / 3)
    temp_green = normalized_hue
    temp_blue = normalized_hue - (1 / 3)
    
    red = _hsl2rgb_helper(temp_red, p, q)
    green = _hsl2rgb_helper(temp_green, p, q)
    blue = _hsl2rgb_helper(temp_blue, p, q)
    
    return red, green, blue

        
if __name__ == '__main__':
    # TODO : move this to use unittest (i.e. do testing properly)
    import random
    
    delta = 10e-10
    
    for i in range(1000000):
        r, g, b = (random.random(), random.random(), random.random())
        tr, tg, tb = hsl2rgb(*rgb2hsl(r, g, b))
#        print "-" * 10
        
        assert r - tr < delta
        assert g - tg < delta
        assert b - tb < delta
    
    print 'Tests run, no problems encountered.'
    
    