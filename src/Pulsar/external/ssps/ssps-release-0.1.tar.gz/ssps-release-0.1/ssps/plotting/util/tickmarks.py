# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module deals with tickmarks.
'''
from __future__ import division
import math

# First determine (or get) the number of tickmarks and the range over which
# the tickmarks need to be produced. 

def tickmarks_per_axis(size):
    '''Calculate number of tickmarks based on size of axis.'''
    n = size // 35 # Assumes : font-size 12
    if n < 2:
        n = 2
    elif n > 10:
        n = 10
    return n

def make_tickmarks(input_range, n_tickmarks = 10):
    assert n_tickmarks > 1
    x1, x2 = input_range
    try:
        assert x2 > x1
    except:
        print input_range, x1, x2
    # This deals with the linear case. Will return a list of tickmark positions,
    # of at least two elements. Will not return tickmarks that are outside of 
    # the input range. Possible distances between tickmarks 1, 2, 5 times some 
    # power of ten.
    
    dx = x2 - x1
    
    best_tickmarks = []
    
    for POT in [0, -1, -2]:
        # oom_dx <- read as 'order of magnitude of the length of interval dx'
        oom_dx = 10 ** (int(math.log10(dx)) + POT)
        for scale in [5, 2, 1]:
            stepsize = oom_dx * scale

            if x1 % stepsize == 0:
                first_tickmark = x1
            else:
                if x1 > 0:
                    first_tickmark = (int(x1 / stepsize) + 1) * stepsize
                else:
                    first_tickmark = int(x1 / stepsize) * stepsize

        
            if x2 % stepsize == 0:
                last_tickmark = x2
            else:
                if x2 < 0:
                    last_tickmark = (int(x2 / stepsize) + 1) * stepsize
                else:
                    last_tickmark = int(x2 / stepsize) * stepsize
        
            n = int((last_tickmark - first_tickmark) / stepsize) + 1
            
            if n > 1 and n > n_tickmarks:
                break
            else:
                best_tickmarks = [first_tickmark + i * stepsize for i in range(n)]

    return best_tickmarks

def logarithmic_tickmarks(input_range, n_tickmarks = 10):
    # For now only major tickmarks
    assert 0 < input_range[0] 
    assert 0 < input_range[1]
    assert input_range[0] < input_range[1]
#    assert 0 < input_range[0] < input_range[1]
    x1 = math.log10(input_range[0])
    x2 = math.log10(input_range[1])
    
    dx = x2 - x1
    
    best_tickmarks = []
    # TODO : go over variable naming and make it conform to expectations better
    # since this is a bit of a cut and paste job.
    for POT in [0, -1, -2]:
        # oom_dx <- read as 'order of magnitude of the length of interval dx'
        stepsize = 10 ** (int(math.log10(dx)) + POT)

        if x1 % stepsize == 0:
            first_tickmark = x1
        else:
            if x1 > 0:
                first_tickmark = (int(x1 / stepsize) + 1) * stepsize
            else:
                first_tickmark = int(x1 / stepsize) * stepsize

    
        if x2 % stepsize == 0:
            last_tickmark = x2
        else:
            if x2 < 0:
                last_tickmark = (int(x2 / stepsize) + 1) * stepsize
            else:
                last_tickmark = int(x2 / stepsize) * stepsize
    
        n = int((last_tickmark - first_tickmark) / stepsize) + 1
        
        if n > 1 and n > n_tickmarks:
            break
        else:
            best_tickmarks = [10 ** (first_tickmark + i * stepsize) for i in range(n)]

        if n > 1 and 3 * n > n_tickmarks:
            break
        else:
            best_tickmarks = [] 

            for i in range(n):
                for scale in [1, 2, 5]:
                    nt = scale * (10 ** (first_tickmark + i * stepsize))
                    if nt <= input_range[1]:
                        best_tickmarks.append(nt)
            
            
            best_tickmarks.sort()

    return best_tickmarks


if __name__ == '__main__':
    print make_tickmarks(1003, 1300., 12)