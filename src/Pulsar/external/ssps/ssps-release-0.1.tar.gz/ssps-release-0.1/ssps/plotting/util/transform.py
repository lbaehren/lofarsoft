# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
from __future__ import division
import math

def make_linear_transform1d(target_range, input_range, invert = False):
    """Create a linear transformation function.
    
    The linear transform created by this function makes everyting in input_range
    fit within target_range. 
    
    Arguments:
    target_range -- tuple or list containing 2 numbers [begin, end] describing 
        the desired range of output values.
    input_range -- tuple or list containing 2 numbers [begin, end] describing 
        the range of input values.
    invert -- if True the beginning of the input range will be mapped to the end
        of the target range and the end to the beginning. (Useful when 
        coordinate system is upside down).
    """
    scale = (target_range[1] - target_range[0]) / (input_range[1] - input_range[0])
    input_shift = input_range[0]
    output_shift = target_range[0]
    max = target_range[1]
    if invert:
        def function(x):
            return max - (x - input_shift) * scale
    else:
        def function(x):
            return (x - input_shift) * scale + output_shift
    return function

def make_logarithmic_transform1d(target_range, input_range, invert = False):
    """Create a logarithmic transformation function. Experimental...
    """
    assert 0 < input_range[0] < input_range[1]
    input_range = [math.log10(input_range[0]), math.log10(input_range[1])]
    
    scale = (target_range[1] - target_range[0]) / (input_range[1] - input_range[0])
    input_shift = input_range[0]
    output_shift = target_range[0]
    max = target_range[1]
    if invert:
        def function(x):
            x = math.log10(x)
            return max - (x - input_shift) * scale
    else:
        def function(x):
            x = math.log10(x)
            return (x - input_shift) * scale + output_shift
    return function
