# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains the implementation of axis drawing for SVG plots. This 
module is for internal use of ssps plotting functionality. 
'''
from __future__ import division

import copy
import random
from math import log10
from xml.sax.saxutils import escape
from xml.sax.saxutils import quoteattr

from ssps.plotting.util.tickmarks import make_tickmarks, logarithmic_tickmarks
from ssps.plotting.util.tickmarks import tickmarks_per_axis

from ssps.plotting.util import transform
from ssps.plotting.util.ranges import make_input_range_safe

try:
    import xml.etree.cElementTree as ET
except ImportError:
    try:
        import xml.etree.ElementTree as ET
    except ImportError:
        import elementtree.ElementTree as ET
    
FONT_SIZE = '12'

class YAxis(object):
    '''Base class for vertical axes in plots.'''
    def __init__(self, x_offset, y_offset, height, axis_description):
        # Note that x_offset, y_offset and height are 'plot coordinates', whilst 
        # input_range is in 'data coordinates'.
        self.x_offset = x_offset
        self.y_offset = y_offset
        self.height = height

        if axis_description:
            input_range, label, log, tickmarks = axis_description
            

            # Check input_range (and fix if problematic).
            self.input_range = make_input_range_safe(input_range)

            # Set the axis label:
            self.label = label
            
            # Store whether the axis is logarithmic:
            self.log = log

            # Set tickmarks:
            if tickmarks:
                self.tickmarks = tickmarks
            else:
                if log:
                    self.tickmarks = logarithmic_tickmarks(self.input_range, tickmarks_per_axis(self.height))
                else:
                    self.tickmarks = make_tickmarks(self.input_range, tickmarks_per_axis(self.height))

            # Set the appropriate transform:
            if not self.log:
                self.y_transform = transform.make_linear_transform1d(
                    (y_offset, y_offset + height), self.input_range, True)
            else:
                self.y_transform = transform.make_logarithmic_transform1d(
                    (y_offset, y_offset + height), self.input_range, True,)
        else:
            self.input_range = None
            self.label = None
            self.log = None
            self.tickmarks = None


class LeftAxis(YAxis):
    '''Class for axis at the left side of a plot.
    
    Inherits from YAxis, can draw both empty (no tickmarks and labels) and full 
    version (tickmarks, label, etc.) of the left side axis.
    '''

    def draw(self, root_element):
        '''Draw axis to element tree style root_element.'''
        if not self.input_range:
            self.draw_empty(root_element)
        else:
            self.draw_full(root_element)

    def draw_empty(self, root_element):
        '''Draw empty axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        root_element.append(ET.Element('line',
            x1 = '%.2f' % (self.x_offset + 50),
            y1 = '%.2f' % self.y_offset,
            x2 = '%.2f' % (self.x_offset + 50),
            y2 = '%.2f' % (self.y_offset + self.height),
            stroke = 'black',
        ))

    def draw_full(self, root_element):
        '''Draw full axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        x_offset = self.x_offset
        y_offset = self.y_offset
                
        line = ET.SubElement(root_element, 'line')
        line.set('x1', '%.2f' % (x_offset + 50))
        line.set('y1', '%.2f' % y_offset)
        line.set('x2', '%.2f' % (x_offset + 50))
        line.set('y2', '%.2f' % (y_offset + self.height))
        line.set('stroke', 'black')
        
        for tickmark in self.tickmarks:
            y = self.y_transform(tickmark)
            tick = ET.SubElement(root_element, 'line')
            tick.set('x1', '%.2f' % (x_offset + 50))
            tick.set('y1', '%.2f' % y)
            tick.set('x2', '%.2f' % (x_offset + 60))
            tick.set('y2', '%.2f' % y)
            tick.set('stroke', 'black')
            
            if self.label:
                x = x_offset + 35
                y = self.y_transform(tickmark)
                
                ticklabel = ET.SubElement(root_element, 'text')
                ticklabel.set('font-size', FONT_SIZE)
                ticklabel.set('text-anchor', 'middle')
                ticklabel.set('x', '%.2f' % x),
                ticklabel.set('y', '%.2f' % y)
                ticklabel.set('transform', 'rotate(-90 %.2f %.2f)' % (x, y))
                ticklabel.text = str(tickmark) # TODO : make a function to get an appropriate string representation of a tickmark

        if self.label:
            x = x_offset + 20
            y = y_offset + self.height / 2 

            label = ET.SubElement(root_element, 'text')
            label.set('font-size', FONT_SIZE)
            label.set('text-anchor', 'middle')
            label.set('x', '%.2f' % x)
            label.set('y', '%.2f' % y)
            label.set('transform', 'rotate(-90 %.2f %.2f)' % (x, y))
            label.text = escape(self.label)


class RightAxis(YAxis):
    '''Class for axis at the right side of a plot.
    
    Inherits from YAxis, can draw both empty (no tickmarks and labels) and full 
    version (tickmarks, label, etc.) of the right side axis.
    '''

    def draw(self, root_element):
        '''Draw axis to element tree style root_element.'''
        if not self.input_range:
            self.draw_empty(root_element)
        else:
            self.draw_full(root_element)
    
    def draw_empty(self, root_element):
        '''Draw empty axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        root_element.append(ET.Element('line',
            x1 = '%.2f' % self.x_offset,
            y1 = '%.2f' % self.y_offset,
            x2 = '%.2f' % self.x_offset,
            y2 = '%.2f' % (self.y_offset + self.height),
            stroke = 'black',
        ))
        
    def draw_full(self, root_element):
        '''Draw full axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        x_offset = self.x_offset
        y_offset = self.y_offset
        
        line = ET.SubElement(root_element, 'line')
        line.set('x1', '%.2f' % x_offset)
        line.set('y1', '%.2f' % y_offset)
        line.set('x2', '%.2f' % x_offset)
        line.set('y2', '%.2f' % (y_offset + self.height))
        line.set('stroke','black')
        
        for tickmark in self.tickmarks:
            tick = ET.SubElement(root_element, 'line')
            tick.set('x1', '%.2f' % (x_offset - 10))
            tick.set('y1', '%.2f' % self.y_transform(tickmark))
            tick.set('x2', '%.2f' % x_offset)
            tick.set('y2', '%.2f' % self.y_transform(tickmark))
            tick.set('stroke', 'black')
            
            if self.label:
                x = x_offset + 15
                y = self.y_transform(tickmark)
                ticklabel = ET.SubElement(root_element, 'text')
                ticklabel.set('font-size', FONT_SIZE)
                ticklabel.set('text-anchor', 'middle')
                ticklabel.set('x', '%.2f' % x),
                ticklabel.set('y', '%.2f' % y)
                ticklabel.set('transform', 'rotate(90 %.2f %.2f)' % (x, y))
                ticklabel.text = str(tickmark) # TODO : make a function to get an appropriate string representation of a tickmark

        if self.label:
            x = x_offset + 30
            y = y_offset + self.height / 2
            label = ET.SubElement(root_element, 'text')
            label.set('font-size', FONT_SIZE)
            label.set('text-anchor', 'middle')
            label.set('x', '%.2f' % x)
            label.set('y', '%.2f' % y)
            label.set('transform', 'rotate(90 %.2f %.2f)' % (x, y))
            label.text = escape(self.label)


class XAxis(object):
    '''Base class for horizontal axes in plots.'''
    def __init__(self, x_offset, y_offset, width, axis_description):
        # Note that x_offset, y_offset and height are 'plot coordinates', whilst 
        # input_range is in 'data coordinates'.
        self.x_offset = x_offset
        self.y_offset = y_offset
        self.width = width

        if axis_description:
            input_range, label, log, tickmarks = axis_description

            # Check input_range (and fix if problematic).
            self.input_range = make_input_range_safe(input_range)

            # Store the axis label:
            self.label = label
            
            # Store whether the axis is logarithmic:
            self.log = log

            # Set tickmarks:
            if tickmarks:
                self.tickmarks = tickmarks
            else:
                if log:
                    self.tickmarks = logarithmic_tickmarks(self.input_range, tickmarks_per_axis(self.width))
                else:
                    self.tickmarks = make_tickmarks(self.input_range, tickmarks_per_axis(self.width))

            # Set the appropriate transforms:
            if not log:
                self.x_transform = transform.make_linear_transform1d(
                    (x_offset, x_offset + width), self.input_range, False)
            else:
                self.x_transform = transform.make_logarithmic_transform1d(
                    (x_offset, x_offset + width), self.input_range, False)
        else:
            self.input_range = None
            self.label = None
            self.log = None
            self.tickmarks = None            


class BottomAxis(XAxis):
    '''Class for axis at the bottom of a plot.
    
    Inherits from XAxis, can draw both empty (no tickmarks and labels) and full 
    version (tickmarks, label, etc.) of the bottom axis.
    '''
    def draw(self, root_element):
        '''Draw axis to element tree style root_element.'''
        if self.input_range:
            self.draw_full(root_element)
        else:
            self.draw_empty(root_element)
        
    def draw_empty(self, root_element):
        '''Draw empty axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        root_element.append(ET.Element('line',
            x1 = '%.2f' % self.x_offset,
            y1 = '%.2f' % self.y_offset,
            x2 = '%.2f' % (self.x_offset + self.width),
            y2 = '%.2f' % self.y_offset,
            stroke = 'black',
        ))        
        
    def draw_full(self, root_element):
        '''Draw full axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        x_offset = self.x_offset
        y_offset = self.y_offset
        
        line = ET.SubElement(root_element, 'line')
        line.set('x1', '%.2f' % x_offset)
        line.set('y1', '%.2f' % y_offset)
        line.set('x2', '%.2f' % (x_offset + self.width))
        line.set('y2', '%.2f' % y_offset)
        line.set('stroke', 'black')

        for tickmark in self.tickmarks:
            x = self.x_transform(tickmark)
            tick = ET.SubElement(root_element, 'line')
            tick.set('x1', '%.2f' % x)
            tick.set('y1', '%.2f' % (y_offset - 10))
            tick.set('x2', '%.2f' % x)
            tick.set('y2', '%.2f' % y_offset)
            tick.set('stroke', 'black')
            
            if self.label:
                tick_label = ET.SubElement(root_element, 'text')
                tick_label.set('font-size', FONT_SIZE)
                tick_label.set('text-anchor', 'middle')
                tick_label.set('x', '%.2f' % x)
                tick_label.set('y', '%.2f' % (y_offset + 15))
                tick_label.text = str(tickmark)
        
        if self.label:
            label = ET.SubElement(root_element, 'text')
            label.set('font-size', FONT_SIZE)
            label.set('text-anchor', 'middle')
            label.set('x', '%.2f' % (x_offset + self.width / 2))
            label.set('y', '%.2f' % (y_offset + 30))
            label.text = escape(self.label)
            

class TopAxis(XAxis):        
    '''Class for axis at the top of a plot.
    
    Inherits from XAxis, can draw both empty (no tickmarks and labels) and full 
    version (tickmarks, label, etc.) of the top axis.
    '''

    def draw(self, root_element):
        '''Draw axis to element tree style root_element.'''
        if self.input_range:
            self.draw_full(root_element)
        else:
            self.draw_empty(root_element)

    def draw_empty(self, root_element):
        '''Draw empty axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        root_element.append(ET.Element('line',
            x1 = '%.2f' % self.x_offset,
            y1 = '%.2f' % (self.y_offset + 50),
            x2 = '%.2f' % (self.x_offset + self.width),
            y2 = '%.2f' % (self.y_offset + 50),
            stroke = 'black',
        ))        
        
    def draw_full(self, root_element):
        '''Draw full axis to element tree style root_element.
        
        Note don't call from outside, use draw member function instead.'''
        x_offset = self.x_offset
        y_offset = self.y_offset
        
        line = ET.SubElement(root_element, 'line')
        line.set('x1', '%.2f' % x_offset)
        line.set('y1', '%.2f' % (y_offset + 50))
        line.set('x2', '%.2f' % (x_offset + self.width))
        line.set('y2', '%.2f' % (y_offset + 50))
        line.set('stroke', 'black')

        for tickmark in self.tickmarks:
            x = self.x_transform(tickmark)
            tick = ET.SubElement(root_element, 'line')
            tick.set('x1', '%.2f' % x)
            tick.set('y1', '%.2f' % (y_offset + 60))
            tick.set('x2', '%.2f' % x)
            tick.set('y2', '%.2f' % (y_offset + 50))
            tick.set('stroke', 'black')
            
            if self.label:
                tick_label = ET.SubElement(root_element, 'text')
                tick_label.set('font-size', FONT_SIZE)
                tick_label.set('text-anchor', 'middle')
                tick_label.set('x', '%.2f' % x)
                tick_label.set('y', '%.2f' % (y_offset + 35))
                tick_label.text = str(tickmark)
        
        if self.label:
            label = ET.SubElement(root_element, 'text')
            label.set('font-size', FONT_SIZE)
            label.set('text-anchor', 'middle')
            label.set('x', '%.2f' % (x_offset + self.width / 2))
            label.set('y', '%.2f' % (y_offset + 20))
            label.text = escape(self.label)


if __name__ == '__main__':
    print "don't run standalone"