# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group,
# 2009-2010.
'''
This module contains a script that calculates some statistics for grouped single
pulse candidates and saves them to a simple text file.

Note this module is a quick draft.
'''
from __future__ import division
import os

import numpy, math

from ssps.group.fitting import fit_non_interactive, smear_3

MIN_GROUPSIZE = 5
MIN_FITSIZE = 20

def find_peak(candidate_group):
    '''Return peak SNR, DM, sample and downfact for a CandidateGroup'''
    best = candidate_group.candidates[0]
    
    for c in candidate_group.candidates:
        if c.sigma > best.sigma:
            best = c
    
    return best.sigma, best.dm, best.sample, best.downfact

def perform_fit(candidate_group, sigma, dm):
    # here be dragons!
    dm_list = [c.dm for c in candidate_group.candidates]
    snr_list = [c.sigma for c in candidate_group.candidates]
    X = numpy.array(dm_list)
    Y = numpy.array(snr_list)
    initial_guess = [sigma, dm, 0.1]

    fit_parameters, succes = fit_non_interactive(smear_3, initial_guess, X, Y, 1)
    return fit_parameters


def calculate_stats(candidate_groups):
    '''Calculate stats for CandidateGroup instances.'''
    output = []
    group_sizes  = {}
    for cg in candidate_groups:
        n_candidates = len(cg.candidates)
        try:
            group_sizes[n_candidates] += 1
        except KeyError, e:
            group_sizes[n_candidates] = 1
        
        if n_candidates < MIN_GROUPSIZE: continue
        
        peak_snr, peak_dm, peak_sample, peak_width = find_peak(cg)
        stats = {'peak_snr' : peak_snr, 'peak_dm' : peak_dm, 
            'peak_sample' : peak_sample, 'peak_width' : peak_width,
            'n_candidates' : n_candidates,}

        if n_candidates >= MIN_FITSIZE:
            fitted_peak_snr, fitted_peak_dm, fitted_peak_width = perform_fit(cg, peak_snr, peak_dm)
            stats['fitted_peak_snr'] = fitted_peak_snr
            stats['fitted_peak_dm'] = fitted_peak_dm
            stats['fitted_peak_width'] = fitted_peak_width
#            pass # call fitting routines here

        output.append(stats)
    return output, group_sizes


def stats_header(columns):
    '''Makes an appropriate header.'''
    line = ['#']
    tmp = [k for k in columns]
    line.extend(tmp)
    line.append('\n')
    return '\t'.join(line)

def parse_stats_header(line):
    columns = []
    if not line[0] == '#':
        raise Exeption('header not in expected format')
    tmp = line.split('\t')
    tmp = tmp[1:]
    for x in tmp:
        columns.append(x.strip())
    return columns

def stats_line(stats, columns):
    '''Converts a dictionary of stats to a line of text'''
    line = []
    for key in columns:
        if stats.has_key(key):
            line.append(str(stats[key]))
        else:
            line.append('None')
    line.append('\n')
    line_string = '\t'.join(line)
    return line_string

def parse_stats_line(line, columns):
    stats = {}
    tmp = line.split('\t')
    if not len(tmp) == len(columns):
        raise Exeption('Statistics file is corrupt.')
    for key, x in zip(columns, tmp):
        if x.strip() == 'None':
            stats[key] = None
        else:
            # TODO make file format smarter so that i can have different things
            # from floats as stats.
            stats[key] = float(x.strip())
    return stats


def write_stats(path, file, stats_list, columns = None):
    if not columns:
        columns = stats_list[0].keys()
    try:
        out_file = open(os.path.join(path, file), 'w')
        try:
            # write header to file:
            out_file.write(stats_header(columns))
            # write individual group's statistics to file:
            for stats in stats_list:
                out_file.write(stats_line(stats, columns))
        finally:
            out_file.close()
    except IOError:
        print 'writing stats to file failed'

def stats_reader(path, file):
    stats_list = []
    try:
        inf_file =  open(os.path.join(path, file), 'r')
        try:
            for i, line in enumerate(inf_file):
                if i == 0:
                    columns = parse_header(line)
                else:
                    stats = parse_line(line, columns)
                stats_list.append(stats)
        finally:
            in_file.close()
    except IOError:
        print 'reading stats from file failed'
    return stats_list
    

if __name__ == '__main__':
    print __doc__