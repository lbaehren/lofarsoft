# By Thijs Coenen for my PhD research with the LOFAR Pulsar Working Group.
# 2009-2010.
'''
This module contains filter functions that (try to) use the shape of the DM-SNR
profile to distinguish between dispersed and undispersed pulses.
'''
from __future__ import division

import numpy, math
from scipy.optimize import leastsq
from scipy.special import erf

import ssps.settings

dm_fudge = 1e-5

def smear_3(pars, x):
    center = pars[0]
    width = pars[1]
    height = pars[2]
    if x.shape:
        y = numpy.ones(x.shape)
        good_idx = abs(x - center) > ssps.settings.DM_FUDGE
        y[good_idx] = (math.sqrt(math.pi) / 2) * (width / (x[good_idx] - center)) * erf((x[good_idx] - center)/width)
    else:
        if x == 0:
            y = 1
        else:
            y = (math.sqrt(math.pi) / 2) * (width / (x-center)) * erf((x-center)/width)
    return y * height

def smear_2(pars, x):
    center = pars[0]
    width = pars[1]
    if x.shape:
        y = numpy.ones(x.shape)
        good_idx = abs(x - center) > ssps.settings.DM_FUDGE
        y[good_idx] = (math.sqrt(math.pi) / 2) * (width / (x[good_idx] - center)) * erf((x[good_idx] - center)/width)
    else:
        if x == 0:
            y = 1
        else:
            y = (math.sqrt(math.pi) / 2) * (width / (x-center)) * erf((x-center)/width)
    return y + pars[2]


def fit_non_interactive(func, initial_guess, x, y, sigma):
    '''
    Fit function func and return fitted parameters and reduced chi square of the
    fit.
    '''
    error_function = lambda parameters, x, y : (func(parameters, x) - y)
    fit_parameters, succes = leastsq(error_function, initial_guess, args=(x, y))

    try: # Hack around weird scipy behaviour
        fit_parameters.shape[0]
    except:
        fit_parameters = [fit_parameters]
        
    return fit_parameters, succes
    
    

def shape_filter(candidate_group):
    '''
    Fit DM-SNR profile 
    '''
    candidate_group.candidates.sort(key = lambda x: x.dm)
    l1 = [c.dm for c in candidate_group.candidates]
    DMs = numpy.array(l1)
    l2 = [c.sigma for c in candidate_group.candidates]
    uhSNRs = numpy.array(l2)
    
    SNRs = numpy.array(l1)
    SNRs[0] = 0.66 * uhSNRs[0] + 0.33 * uhSNRs[1]
    SNRs[-1] = 0.66 * uhSNRs[-1] + 0.33 * uhSNRs[-2]
    
    for i in range(1, len(SNRs) - 1):
        SNRs[i] = 0.25 * uhSNRs[i-1] + uhSNRs[i] + 0.25 * uhSNRs[i+1]
    
    SNRs = uhSNRs
    
    
    best_snr = SNRs[0]
    best_i = 0
    for i in range(1, len(DMs)):
        if SNRs[i] > best_snr:
            best_snr = SNRs[i]
            best_i = i
    best_dm = DMs[best_i]
    
    initial_guess = [best_dm, 0.01, best_snr]
    
    
    fit_parameters, succes = fit(smear_3, initial_guess, DMs, uhSNRs, 1)
    
    dm_close = abs(fit_parameters[0] - best_dm) < 0.2
    snr_close = abs((fit_parameters[2] - best_snr)/best_snr) < 0.2
    
    if dm_close and snr_close:
        return True
    else:
        return False