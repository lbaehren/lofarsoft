
#include <iostream>

int main()
{
  std::cerr << "Hello, World!" << std::endl;

  return 0;
}
