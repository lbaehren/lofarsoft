#! /usr/bin/env python

from pylab import *

x = [1,2,3,4]
y = [1,2,3,4]
plot(x,y)

show()

